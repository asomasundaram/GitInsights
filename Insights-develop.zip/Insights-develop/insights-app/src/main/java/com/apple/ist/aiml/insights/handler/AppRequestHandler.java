/*
 * Copyright 2023 Apple, Inc
 * Apple Internal Use Only
 */


package com.apple.ist.aiml.insights.handler;

import javax.inject.Named;


@Named
public class AppRequestHandler {
//    private static final Logger LOGGER = LoggerFactory.getLogger(AppRequestHandler.class);
//
//    private final AuthenticatedPrincipalProvider principalProvider;
//
//    public AppRequestHandler(AuthenticatedPrincipalProvider principalProvider) {
//        this.principalProvider = principalProvider;
//    }
//
//    @Autowired
//    private Environment environment;
//
//    @Inject
//    public AppRequestHandler(final AuthenticatedPrincipalProvider principalProvider) {
//        LOGGER.info("Project App Handler created");
//        this.principalProvider = principalProvider;
//    }
//
//
//    // TODO: Remove. Provided as a sample.
//    public Mono<ServerResponse> sayHello(final ServerRequest request) {
//        // TODO: Remove.  Use /user endpoint to return user data
//        return principalProvider.retrieveUser()
//                                .flatMap(user -> ServerResponse.ok()
//                                                               .contentType(APPLICATION_JSON)
//                                                               .body(Mono.fromCallable(() -> {
//                                                                   // Structured Logging example using a map
//                                                                   LOGGER.debug("This is a structured logging example. {}",
//                                                                   pairsOf("clientUser", user.getId(),
//                                                                           "method", request.methodName(),
//                                                                           "attributes", request.attributes(),
//                                                                           "queryParams", request.queryParams(),
//                                                                           "path", request.path()));
//
//                                                                   return user;
//                                                               }), User.class));
//    }
}

package com.apple.ist.aiml.insights.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AIMLInsightsResponseStatus<T> implements Serializable {

	private String id;
	private Timestamp lastModifiedTime;
	private transient T data;

	public String getId() {
		return id;
	}

	public void setId(final String id) {
		this.id = id;
	}

	public Timestamp getLastModifiedTime() {
		return lastModifiedTime;
	}

	public void setLastModifiedTime(final Timestamp lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

	public T getData() {
		return data;
	}

	public void setData(final T data) {
		this.data = data;
	}

}

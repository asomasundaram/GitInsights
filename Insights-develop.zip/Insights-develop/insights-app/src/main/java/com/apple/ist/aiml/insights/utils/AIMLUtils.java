package com.apple.ist.aiml.insights.utils;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.WordUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.apple.ist.aiml.insights.repository.bean.AIMLUserData;


public class AIMLUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(AIMLUtils.class);
	public static String convertStringToTitleCase(String input) {
		if (input.contains("_")) {
			return WordUtils.capitalizeFully(input.replace("_", " ").toLowerCase());
		} else {
			return WordUtils.capitalizeFully(input.toLowerCase());
		}
	}
	
	public static  Boolean isRecordModified(String existingPlanLastModifiedTime, String docToBeUpdatedLastModifiedTime) throws Exception {
		var flag = false;
        try {
        	Date existingPlanModifiedTime = new Date(Long.parseLong(existingPlanLastModifiedTime) );
    		Date docToBeUpdatedModifiedTime = new Date(Long.parseLong(docToBeUpdatedLastModifiedTime) );
            if (existingPlanModifiedTime.before(docToBeUpdatedModifiedTime)) {
                flag = true;
            }
        } catch (Exception e) {
        	LOGGER.error("EXCEPTION_OCCURRED_WHILE_PARSING_THE_DATE", e.getMessage());
            throw new NumberFormatException();
        }
        return flag;
		
	}

	public static AIMLUserData getApplicationRoleLevel(AIMLUserData userData, Map<String, List<String>> aimlRoles) {
		if (userData != null) {
			for (Map.Entry<String, List<String>> entry : aimlRoles.entrySet()) {
				if (entry.getValue().contains(userData.getRoleId())) {
					userData.setApplicationRoleLevel(entry.getKey());
					return userData;
				} else {
					userData.setApplicationRoleLevel(null);
				}
			}
		} else {
			userData.setApplicationRoleLevel(null);
			return userData;
		}
		return userData;
	}
}

package com.apple.ist.aiml.insights.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AIMLInsightsResponse implements Serializable {

    private List<AIMLMetadata> metaData;

}

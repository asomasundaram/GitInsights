package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;

public class AIMLSTLViewResponse implements Serializable {

    private String dsid;
    private String firstName;
    private String lastName;
    private String siteId;
    private String siteName;
    private String roleId;
    private String roleName;
    private String totalPlans;
    private String completedPlans;
    private AIMLPlanType planTypes;
    private String totalHeadCount;
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getTotalPlans() {
        return totalPlans;
    }

    public void setTotalPlans(String totalPlans) {
        this.totalPlans = totalPlans;
    }

    public String getCompletedPlans() {
        return completedPlans;
    }

    public void setCompletedPlans(String completedPlans) {
        this.completedPlans = completedPlans;
    }

    public String getDsid() {
        return dsid;
    }

    public void setDsid(String dsid) {
        this.dsid = dsid;
    }

    public AIMLPlanType getPlanTypes() {
        return planTypes;
    }

    public void setPlanTypes(AIMLPlanType planTypes) {
        this.planTypes = planTypes;
    }
    
    public String getTotalHeadCount() {
		return totalHeadCount;
	}
    
	public void setTotalHeadCount(String totalHeadCount) {
		this.totalHeadCount = totalHeadCount;
	}
}

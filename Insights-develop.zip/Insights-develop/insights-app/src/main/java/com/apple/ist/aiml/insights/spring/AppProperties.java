/*
 * Copyright 2023 Apple, Inc
 * Apple Internal Use Only
 */


package com.apple.ist.aiml.insights.spring;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@ConfigurationProperties("app")
public class AppProperties {
    private String environment;

    @Value("${idms.corp.login.url}")
    private String loginUrl;

    @Value("${idms.corp.cookie.name}")
    private String cookieName;

    @Value("${idms.corp.validate.URL}")
    private String validateUrl;

    @Value("${idms.corp.validate.requestparams}")
    private String requestParams;

    @Value("${idms.corp.validate.disableValidation}")
    private boolean disableValidation;

    @Value("${application.idms.sessionTimeout}")
    private int idmsSessionTimeout;

    @Value("${application.csrf.sessionTimeout}")
    private int csrfSessionTimeout;

    private List<String> planTypes = new ArrayList<>();

//    private Map<String, List<String>> focusMetrics = new HashMap<>();
    
    @Value("#{'${app.createPlanRoles}'.split(',')}")
	private List<String> createPlanRoles;

	@Value("#{'${app.updatePlanRoles}'.split(',')}")
	private List<String> updatePlanRoles;
	
	@Value("#{'${app.deletePlanRoles}'.split(',')}")
	private List<String> deletePlanRoles;

	@Value("${appeng.aluminum.web.authorization.token}")
	private String authorization;

	@Value("${application.clipper.subscription.id}")
	private String subscriptionId;

	@Value("${application.clipper.template.id}")
	private String templateId;
	
	@Value("${application.clipper.from.email}")
	private String fromEmail;
	
	@Value("${appeng.aluminum.web.client.services.emailservice.baseUrl}")
	private String baseUrl;

    @Value("#{'${app.exceptionAccessGroups}'.split(',')}")
    private List<String> exceptionAccessGroups;
    
    @Value("#{${app.aiml.roles}}")
    private Map<String, List<String>> aimlRoles;

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }


    public boolean isDisableValidation() {
        return disableValidation;
    }

    public void setDisableValidation(boolean disableValidation) {
        this.disableValidation = disableValidation;
    }

    public int getCsrfSessionTimeout() {
        return csrfSessionTimeout;
    }

    public void setCsrfSessionTimeout(int csrfSessionTimeout) {
        this.csrfSessionTimeout = csrfSessionTimeout;
    }

    public int getIdmsSessionTimeout() {
        return idmsSessionTimeout;
    }

    public void setIdmsSessionTimeout(int idmsSessionTimeout) {
        this.idmsSessionTimeout = idmsSessionTimeout;
    }

    public String getLoginUrl() {
        return loginUrl;
    }

    public void setLoginUrl(String loginUrl) {
        this.loginUrl = loginUrl;
    }

    public String getCookieName() {
        return cookieName;
    }

    public void setCookieName(String cookieName) {
        this.cookieName = cookieName;
    }

    public String getValidateUrl() {
        return validateUrl;
    }

    public void setValidateUrl(String validateUrl) {
        this.validateUrl = validateUrl;
    }

    public String getRequestParams() {
        return requestParams;
    }

    public List<String> getExceptionAccessGroups() {
        return exceptionAccessGroups;
    }

    public void setExceptionAccessGroups(List<String> exceptionAccessGroups) {
        this.exceptionAccessGroups = exceptionAccessGroups;
    }

    public void setRequestParams(String requestParams) {
        this.requestParams = requestParams;
    }

    public List<String> getPlanTypes() {
        return planTypes;
    }

    public void setPlanTypes(List<String> planTypes) {
        this.planTypes = planTypes;
    }
    public List<String> getCreatePlanRoles() {
		return createPlanRoles;
	}

	public void setCreatePlanRoles(List<String> createPlanRoles) {
		this.createPlanRoles = createPlanRoles;
	}

	public List<String> getUpdatePlanRoles() {
		return updatePlanRoles;
	}

	public void setUpdatePlanRoles(List<String> updatePlanRoles) {
		this.updatePlanRoles = updatePlanRoles;
	}

	public List<String> getDeletePlanRoles() {
		return deletePlanRoles;
	}

	public void setDeletePlanRoles(List<String> deletePlanRoles) {
		this.deletePlanRoles = deletePlanRoles;
	}
	
	public String getAuthorization() {
		return authorization;
	}

	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}

	public String getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(String subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}
	
	public Map<String, List<String>> getAimlRoles() {
		return aimlRoles;
	}

	public void setAimlRoles(Map<String, List<String>> aimlRoles) {
		this.aimlRoles = aimlRoles;
	}
}

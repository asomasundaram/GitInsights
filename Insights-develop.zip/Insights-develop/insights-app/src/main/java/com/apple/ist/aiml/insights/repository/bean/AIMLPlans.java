package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AIMLPlans implements Serializable {

    private String id;
    private String planDsid;
    private String planMonth;
    private String planYear;
    private String createdBy;
    private String publishedDateTime;
    private String lastModifiedBy;
    private String lastModifiedTime;
    private String planNotes;
    private String planOutput;
    private String planStartDate;
    private String planEndDate;
    private String planState;
    private String  planType;
    private Boolean isDeleted;
    private String closureRating;
    private String closureComments;
    private String planTypeReason;
    private List<AIMLBehaviors> behaviors;
    private List<AIMLTasks> tasks;
    private List<AIMLFocusAreaMetrics> focusAreaMetrics;
    private AIMLCompetencyFocus competencyFocus;

    private Metadata metadata;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPlanDsid() {
        return planDsid;
    }

    public void setPlanDsid(String planDsid) {
        this.planDsid = planDsid;
    }

    public String getPlanMonth() {
        return planMonth;
    }

    public void setPlanMonth(String planMonth) {
        this.planMonth = planMonth;
    }

    public String getPlanYear() {
        return planYear;
    }

    public void setPlanYear(String planYear) {
        this.planYear = planYear;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getPublishedDateTime() {
        return publishedDateTime;
    }

    public void setPublishedDateTime(String publishedDateTime) {
        this.publishedDateTime = publishedDateTime;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public String getLastModifiedTime() {
        return lastModifiedTime;
    }

    public void setLastModifiedTime(String lastModifiedTime) {
        this.lastModifiedTime = lastModifiedTime;
    }

    public String getPlanNotes() {
        return planNotes;
    }

    public void setPlanNotes(String planNotes) {
        this.planNotes = planNotes;
    }

    public String getPlanOutput() {
        return planOutput;
    }

    public void setPlanOutput(String planOutput) {
        this.planOutput = planOutput;
    }

    public String getPlanStartDate() {
        return planStartDate;
    }

    public void setPlanStartDate(String planStartDate) {
        this.planStartDate = planStartDate;
    }

    public String getPlanEndDate() {
        return planEndDate;
    }

    public void setPlanEndDate(String planEndDate) {
        this.planEndDate = planEndDate;
    }

    public String getPlanState() {
        return planState;
    }

    public void setPlanState(String planState) {
        this.planState = planState;
    }

    public String getPlanType() {
        return planType;
    }

    public void setPlanType(String planType) {
        this.planType = planType;
    }

    public Boolean isDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isdeleted) {
        isDeleted = isdeleted;
    }

    public String getClosureRating() {
        return closureRating;
    }

    public void setClosureRating(String closureRating) {
        this.closureRating = closureRating;
    }

    public String getClosureComments() {
        return closureComments;
    }

    public void setClosureComments(String closureComments) {
        this.closureComments = closureComments;
    }

    public String getPlanTypeReason() {
        return planTypeReason;
    }

    public void setPlanTypeReason(String planTypeReason) {
        this.planTypeReason = planTypeReason;
    }

    public List<AIMLBehaviors> getBehaviors() {
        return behaviors;
    }

    public void setBehaviors(List<AIMLBehaviors> behaviors) {
        this.behaviors = behaviors;
    }

    public List<AIMLTasks> getTasks() {
        return tasks;
    }

    public void setTasks(List<AIMLTasks> tasks) {
        this.tasks = tasks;
    }

    public List<AIMLFocusAreaMetrics> getFocusAreaMetrics() {
        return focusAreaMetrics;
    }

    public void setFocusAreaMetrics(List<AIMLFocusAreaMetrics> focusAreaMetrics) {
        this.focusAreaMetrics = focusAreaMetrics;
    }

    public AIMLCompetencyFocus getCompetencyFocus() {
        return competencyFocus;
    }

    public void setCompetencyFocus(AIMLCompetencyFocus competencyFocus) {
        this.competencyFocus = competencyFocus;
    }

    public Metadata getMetadata() {
        return metadata;
    }

    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }
}

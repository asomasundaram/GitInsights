package com.apple.ist.aiml.insights.exception;

public class EmailNotificationException extends Exception {

    private static final long serialVersionUID = -7583714349103680213L;

    public EmailNotificationException(final String errorMessage) {
        super(errorMessage);
    }

    public EmailNotificationException(final String errorMessage, final Throwable exception) {
        super(errorMessage, exception);
    }

    public EmailNotificationException(final Throwable exception) {
        super(exception);
    }
}


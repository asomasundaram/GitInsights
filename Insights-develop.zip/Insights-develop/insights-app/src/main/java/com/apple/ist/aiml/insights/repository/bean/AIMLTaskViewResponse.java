package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;

public class AIMLTaskViewResponse implements Serializable {

    private String planId;
    private String planMonth;
    private String planYear;
    private String planState;
    private String planStartDate;
    private String planEndDate;
    private String publishedDateTime;
    private String planType;
    private String taskId;
    private String taskDescription;
    private String taskCode;
    private String taskStatus;
    private String taskOwnerDsid;
    private String taskDueDate;
    private String taskOwnerFirstName;
    private String taskOwnerLastName;

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public String getPlanMonth() {
        return planMonth;
    }

    public void setPlanMonth(String planMonth) {
        this.planMonth = planMonth;
    }

    public String getPlanYear() {
        return planYear;
    }

    public void setPlanYear(String planYear) {
        this.planYear = planYear;
    }

    public String getPlanState() {
        return planState;
    }

    public void setPlanState(String planState) {
        this.planState = planState;
    }

    public String getPlanStartDate() {
        return planStartDate;
    }

    public void setPlanStartDate(String planStartDate) {
        this.planStartDate = planStartDate;
    }

    public String getPlanEndDate() {
        return planEndDate;
    }

    public void setPlanEndDate(String planEndDate) {
        this.planEndDate = planEndDate;
    }

    public String getPublishedDateTime() {
        return publishedDateTime;
    }

    public void setPublishedDateTime(String publishedDateTime) {
        this.publishedDateTime = publishedDateTime;
    }

    public String getPlanType() {
        return planType;
    }

    public void setPlanType(String planType) {
        this.planType = planType;
    }

    public String getTaskCode() {
        return taskCode;
    }

    public void setTaskCode(String taskCode) {
        this.taskCode = taskCode;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public String getTaskOwnerDsid() {
        return taskOwnerDsid;
    }

    public void setTaskOwnerDsid(String taskOwnerDsid) {
        this.taskOwnerDsid = taskOwnerDsid;
    }

    public String getTaskDueDate() {
        return taskDueDate;
    }

    public void setTaskDueDate(String taskDueDate) {
        this.taskDueDate = taskDueDate;
    }

    public String getTaskOwnerFirstName() {
        return taskOwnerFirstName;
    }

    public void setTaskOwnerFirstName(String taskOwnerFirstName) {
        this.taskOwnerFirstName = taskOwnerFirstName;
    }

    public String getTaskOwnerLastName() {
        return taskOwnerLastName;
    }

    public void setTaskOwnerLastName(String taskOwnerLastName) {
        this.taskOwnerLastName = taskOwnerLastName;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }
}

package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;
import java.util.List;

public class AIMLTaskViewRequest implements Serializable {

    List<String> dsid;

    public List<String> getDsid() {
        return dsid;
    }

    public void setDsid(List<String> dsid) {
        this.dsid = dsid;
    }
}

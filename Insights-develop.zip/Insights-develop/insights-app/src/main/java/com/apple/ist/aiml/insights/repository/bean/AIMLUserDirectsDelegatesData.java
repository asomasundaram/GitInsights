package com.apple.ist.aiml.insights.repository.bean;

import java.util.List;

public class AIMLUserDirectsDelegatesData {
    private String id;
    private String dsid;
    private String firstName;
    private String lastName;
    private String preferredName;
    private String personType;
    private String emailAddress;
    private String businessUnitId;
    private String roleId;
    private String roleName;
    private String personCategory;
    private String employeeStatus;
    private String siteId;
    private String siteName;
    private String managerDsid;
    private String delegatedManagerDsid;
    private String delegationStartDate;
    private String delegationEndDate;
    private String l1Locale;
    private String l2Locale;
    private String l3Locale;
    private String l4Locale;
    private String l5Locale;
    private String userLocale;
    private List<AIMLUserData> directs;
    private List<AIMLUserData> delegatedUserData;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDsid() {
        return dsid;
    }

    public void setDsid(String dsid) {
        this.dsid = dsid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPreferredName() {
        return preferredName;
    }

    public void setPreferredName(String preferredName) {
        this.preferredName = preferredName;
    }

    public String getPersonType() {
        return personType;
    }

    public void setPersonType(String personType) {
        this.personType = personType;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getBusinessUnitId() {
        return businessUnitId;
    }

    public void setBusinessUnitId(String businessUnitId) {
        this.businessUnitId = businessUnitId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getPersonCategory() {
        return personCategory;
    }

    public void setPersonCategory(String personCategory) {
        this.personCategory = personCategory;
    }

    public String getEmployeeStatus() {
        return employeeStatus;
    }

    public void setEmployeeStatus(String employeeStatus) {
        this.employeeStatus = employeeStatus;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getManagerDsid() {
        return managerDsid;
    }

    public void setManagerDsid(String managerDsid) {
        this.managerDsid = managerDsid;
    }

    public String getDelegatedManagerDsid() {
        return delegatedManagerDsid;
    }

    public void setDelegatedManagerDsid(String delegatedManagerDsid) {
        this.delegatedManagerDsid = delegatedManagerDsid;
    }

    public String getDelegationStartDate() {
        return delegationStartDate;
    }

    public void setDelegationStartDate(String delegationStartDate) {
        this.delegationStartDate = delegationStartDate;
    }

    public String getDelegationEndDate() {
        return delegationEndDate;
    }

    public void setDelegationEndDate(String delegationEndDate) {
        this.delegationEndDate = delegationEndDate;
    }

    public String getL1Locale() {
        return l1Locale;
    }

    public void setL1Locale(String l1Locale) {
        this.l1Locale = l1Locale;
    }

    public String getL2Locale() {
        return l2Locale;
    }

    public void setL2Locale(String l2Locale) {
        this.l2Locale = l2Locale;
    }

    public String getL3Locale() {
        return l3Locale;
    }

    public void setL3Locale(String l3Locale) {
        this.l3Locale = l3Locale;
    }

    public String getL4Locale() {
        return l4Locale;
    }

    public void setL4Locale(String l4Locale) {
        this.l4Locale = l4Locale;
    }

    public String getL5Locale() {
        return l5Locale;
    }

    public void setL5Locale(String l5Locale) {
        this.l5Locale = l5Locale;
    }

    public String getUserLocale() {
        return userLocale;
    }

    public void setUserLocale(String userLocale) {
        this.userLocale = userLocale;
    }

    public List<AIMLUserData> getDirects() {
        return directs;
    }

    public void setDirects(List<AIMLUserData> directs) {
        this.directs = directs;
    }

    public List<AIMLUserData> getDelegatedUserData() {
        return delegatedUserData;
    }

    public void setDelegatedUserData(List<AIMLUserData> delegatedUserData) {
        this.delegatedUserData = delegatedUserData;
    }
}

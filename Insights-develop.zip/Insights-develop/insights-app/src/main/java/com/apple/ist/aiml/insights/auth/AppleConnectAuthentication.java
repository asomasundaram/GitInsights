package com.apple.ist.aiml.insights.auth;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.apple.ist.aiml.insights.bean.AIMLUserLoginDetails;
import com.apple.ist.aiml.insights.constants.AIMLInsightsConstants;
import com.apple.ist.aiml.insights.service.AIMLInsightsService;
import com.apple.ist.aiml.insights.spring.AppProperties;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StopWatch;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import org.springframework.web.server.WebSession;
import reactor.core.publisher.Mono;

@Component
public class AppleConnectAuthentication implements WebFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(AppleConnectAuthentication.class);

    @Autowired
    private AppProperties properties;

    @Autowired
    private AIMLInsightsService aimlService;

    private String appleConnectAuthExpiry;

    public static Cookie getCookie(final HttpServletRequest httpRequest, final String ssoCookieName) {
        Cookie[] cookies = httpRequest.getCookies();
        Cookie cookie = null;
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                if (ssoCookieName.equals(cookies[i].getName())) {
                    cookie = cookies[i];
                    LOGGER.info("IDMS_COOKIE_DETAILS={} VALUE={}", cookies[i].getName(), cookies[i].getValue());
                    break;
                }
            }
        }
        return cookie;
    }

    private void hardcodeDefaultValuesInSession(ServerWebExchange exchange){
        Mono<WebSession> webSession = exchange.getSession();
        AIMLUserLoginDetails userDetails = new AIMLUserLoginDetails();
        userDetails.setDsid("2320433051");
        userDetails.setFirstName("Chris");
        userDetails.setLastName("Ellis");
        userDetails.setEmailAddress("test@apple.com");
        userDetails.setPreferredName("Chris");
        webSession.subscribe( session -> {
            session.getAttributes().put(AIMLInsightsConstants.FIRST_NAME, userDetails.getFirstName());
            session.getAttributes().put(AIMLInsightsConstants.LAST_NAME, userDetails.getLastName());
            session.getAttributes().put(AIMLInsightsConstants.DSID, userDetails.getDsid()); // // Assign Chris's DSID record as default
            session.getAttributes().put(AIMLInsightsConstants.EMAIL_ADDRESS, userDetails.getEmailAddress());
            session.getAttributes().put(AIMLInsightsConstants.NICK_NAME_OR_PREFERRED_NAME, userDetails.getPreferredName());
            session.getAttributes().put(AIMLInsightsConstants.APPLE_CONNECT_USER_DETAILS, userDetails);
        });
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, final WebFilterChain chain) {
        LOGGER.info("AIML_AUTH_DO_FILTER");
        Mono<String> userExpiryTime;
        try {
            if (properties.isDisableValidation()) {
                // Assign default values to disable IDMS Authentication
                hardcodeDefaultValuesInSession(exchange);
                return chain.filter(exchange);
            } else {
                final String excludeHealthCheck = "/health";
                final String excludeLogout = "/logout";
                AIMLUserLoginDetails loginUserDetails = new AIMLUserLoginDetails();
                String path = exchange.getRequest().getPath().toString();
                LOGGER.info("AIML_AUTH_INCOMING_PATH={}", path);
                if (path.contains(excludeHealthCheck) || path.contains(excludeLogout)) {
                    // Excluding IDMS check for static contents
                    LOGGER.info("AIML_AUTH_PATH_SKIPPING_IDMS_AUTHENTICATION={}", path);
                    return chain.filter(exchange);
                } else {
                    userExpiryTime = exchange.getSession().mapNotNull(s -> s.getAttribute(AIMLInsightsConstants.AIML_USER_EXPIRY_TIME));
                    LOGGER.info("userExpiryTime={} , CurrentTime={} for Path={} firstName={}", userExpiryTime, System.currentTimeMillis(), path);
                    if (appleConnectAuthExpiry != null && (System.currentTimeMillis() < Long.valueOf(appleConnectAuthExpiry))) {
                        if (System.currentTimeMillis() < Long.valueOf(appleConnectAuthExpiry)) { Mono<WebSession> webSession = exchange.getSession();
                            webSession.subscribe( ws -> {
                                ws.getAttributes().put(AIMLInsightsConstants.FIRST_NAME, ws.getAttribute(AIMLInsightsConstants.FIRST_NAME));
                                ws.getAttributes().put(AIMLInsightsConstants.LAST_NAME, ws.getAttribute(AIMLInsightsConstants.LAST_NAME));
                                ws.getAttributes().put(AIMLInsightsConstants.DSID, ws.getAttribute(AIMLInsightsConstants.DSID));
                                ws.getAttributes().put(AIMLInsightsConstants.EMAIL_ADDRESS, ws.getAttribute(AIMLInsightsConstants.EMAIL_ADDRESS));
                                ws.getAttributes().put(AIMLInsightsConstants.NICK_NAME_OR_PREFERRED_NAME,
                                        ws.getAttribute(AIMLInsightsConstants.NICK_NAME_OR_PREFERRED_NAME));
                            });
                            return chain.filter(exchange);
                        }
                    } else {
                        boolean validIDMSUser = false;
                        boolean authorizeMaestrodUser = false;
                        boolean validPersonType = false;
                        try {
                            validIDMSUser = validateIDMSCookie(exchange, loginUserDetails, path);
                        } catch (UnknownHostException e) {
                            throw new RuntimeException(e);
                        }
                        if (!validIDMSUser) {
                            // Not a valid user, redirect to IDMS Login page.
                            loginUserDetails.setErrorMessage(AIMLInsightsConstants.NOT_A_VALID_USER);
                            exchange.getAttributes().put(AIMLInsightsConstants.ERROR_MESSAGE, AIMLInsightsConstants.NOT_A_VALID_USER);
                            ServerHttpRequest httpRequest = exchange.getRequest();
                            String path11 = httpRequest.getPath().pathWithinApplication().value();
                            if ("/application".equals(httpRequest.getPath().pathWithinApplication().value())
                                || "/index.html".equals(httpRequest.getPath().pathWithinApplication().value())) {
                                ServerHttpRequest mutatedServerRequest = httpRequest.mutate().path("/idmsLogin").build();
                                exchange = exchange.mutate().request(mutatedServerRequest).build();
                            }
                            return chain.filter(exchange);
                        } else {
                            // Proceed with PersonType Check & Maestro User authorization
                            if(loginUserDetails.getPersonTypeCode().equalsIgnoreCase("1")){
                                validPersonType = true;
                            } else {
                                if(loginUserDetails.isExceptionAccessGroup()) {
                                    authorizeMaestrodUser = true; // TBD - Check if this is still required.
                                    validPersonType = true;
                                }
                            }
                            if(validPersonType && aimlService.authorizeUserMaestroData(loginUserDetails.getDsid(), loginUserDetails.getBusinessUnitId())) {
                                authorizeMaestrodUser = true;
                            }
                            if(!validPersonType && !authorizeMaestrodUser) {
                                // Unauthorized Maestro user
                                ServerHttpRequest mutatedServerRequest = exchange.getRequest().mutate().path("/unauthorized").build();
                                exchange = exchange.mutate().request(mutatedServerRequest).build();
                                return chain.filter(exchange);
                            }
                            Mono<WebSession> webSession = exchange.getSession();
                            webSession.subscribe( ws -> {
                                ws.getAttributes().put(AIMLInsightsConstants.FIRST_NAME, ws.getAttribute(AIMLInsightsConstants.FIRST_NAME));
                                ws.getAttributes().put(AIMLInsightsConstants.LAST_NAME, ws.getAttribute(AIMLInsightsConstants.LAST_NAME));
                                ws.getAttributes().put(AIMLInsightsConstants.DSID, ws.getAttribute(AIMLInsightsConstants.DSID));
                                ws.getAttributes().put(AIMLInsightsConstants.EMAIL_ADDRESS, ws.getAttribute(AIMLInsightsConstants.EMAIL_ADDRESS));
                                ws.getAttributes().put(AIMLInsightsConstants.NICK_NAME_OR_PREFERRED_NAME,
                                        ws.getAttribute(AIMLInsightsConstants.NICK_NAME_OR_PREFERRED_NAME));
                            });
                        }
                    }
                }
            }
        } catch (Exception e){
            LOGGER.error("Exception during AppleConnect Authenticaiton : {}", e.getMessage());
        }
        return chain.filter(exchange);
    }

    private String fetchAppleConnectExpiry(Mono<String> string){
        return string.subscribe( str -> {appleConnectAuthExpiry = str;} ).toString();
    }

    public boolean validateIDMSCookie(ServerWebExchange exchange,
                                  final AIMLUserLoginDetails userDetails,
                                  final String path) throws UnknownHostException {
        boolean authenticateUser = false;
        MultiValueMap<String, HttpCookie> cookies = exchange.getRequest().getCookies();
        String redirectPath = null;
        Mono<WebSession> webSession = exchange.getSession();
        if (path != null && path.contains(AIMLInsightsConstants.REDIRECTION_PATH)) {
            redirectPath = properties.getLoginUrl() + path;
        } else {
            redirectPath = properties.getLoginUrl();
        }
        if (cookies.getFirst(properties.getCookieName()) == null) {
            // Not an authorized user, To be redirected to the login page
            LOGGER.info("IDMS_COOKIE_IS_NULL_REDIRECTING_TO_IDMS_LOGIN_PAGE={}", redirectPath);
            return authenticateUser;
        } else {
            StopWatch startTime = new StopWatch("validateCookie");
            startTime.start();
            LOGGER.info("COOKIE_VALUE={}", cookies.getFirst(properties.getCookieName()).getValue());
            InetAddress ip = InetAddress.getLocalHost();
            String addr = ip.getHostAddress();
            Client client = ClientBuilder.newClient();
            WebTarget target = client.target(properties.getValidateUrl());
            Builder reqBuilder = target.request().accept(MediaType.APPLICATION_FORM_URLENCODED);
            StringBuilder sb = new StringBuilder();
            sb.append(properties.getRequestParams()).append(AIMLInsightsConstants.COOKIE).append(cookies.getFirst(properties.getCookieName()).getValue()).append(AIMLInsightsConstants.IP)
                    .append(addr);
            LOGGER.info("VALIDATE_API_REQUEST_PARAMS={}", sb);
            Response response = reqBuilder.post(Entity.entity(sb.toString(), MediaType.APPLICATION_FORM_URLENCODED));
            String result = response.readEntity(String.class);
            LOGGER.info("STATUS_CODE={} IDMS_RESPONSE={}", response.getStatus(), result);
            int status = -1;
            try (InputStream inputStream = new ByteArrayInputStream(result.getBytes(StandardCharsets.UTF_8))) {
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                if (null != bufferedReader) {
                    String data = "";
                    while ((data = bufferedReader.readLine()) != null) {
                        LOGGER.info("IDMS_RAW_DATA={}", data);
                        if (data.indexOf("=") > -1) {
                            final int index = data.indexOf(AIMLInsightsConstants.EQUALS_TO);
                            if (data.indexOf(AIMLInsightsConstants.STATUS) > -1) {
                                status = Integer.parseInt(data.substring(index + 1).trim());
                            }
                            if (status == 0) {
                                authenticateUser = true;
                                // cache AppleConnect login details in HTTPSession
                                cacheUserDetails(userDetails, exchange, data, index);
                            }
                        }
                    }
                }
                // Check if the existing IDMS cookie is valid with status code 0
                if (status != 0) {
                    LOGGER.info("IDMS_COOKIE_AVAIALBLE_BUT_NOT_VALID_OR_EXPIRED");
                    return false;
                }
            } catch (IOException e) {
                LOGGER.error("IOEXCEPTION_DURING_PARSING_IDMS_VALIDATE_DATA={}", e.getMessage());
            } catch (Exception e) {
                LOGGER.error("EXCEPTION_DURING_PARSING_IDMS_VALIDATE_DATA={}", e.getMessage());
            } finally {
                startTime.stop();
                LOGGER.info("AIML_IDMS_AUTH_TIME_TAKEN={} PATH={} NAME={}", startTime.getTotalTimeMillis(), path, userDetails.getFirstName());
            }
            if (authenticateUser) {
                LOGGER.info("SUCCESFULLY_VALIDATED_IDMS_COOKIE_AND_MAESTRO_USER");
                webSession.subscribe( session -> {
                    session.getAttributes().put(AIMLInsightsConstants.APPLE_CONNECT_USER_DETAILS, userDetails);
                    session.getAttributes().put(AIMLInsightsConstants.AIML_USER_EXPIRY_TIME, System.currentTimeMillis()
                            + properties.getIdmsSessionTimeout());
                });
                LOGGER.info("CONFIGURED_IDMS_SESSION_TIMEOUT_FOR_THE_FIRST_TIME ***************={}",
                        System.currentTimeMillis() + properties.getIdmsSessionTimeout());
            }
            return authenticateUser;
        }
    }

    private void cacheUserDetails(AIMLUserLoginDetails userDetails, ServerWebExchange exchange, String data,
                                  final int index) {

        Mono<WebSession> webSession = exchange.getSession();
        if (data.contains(AIMLInsightsConstants.PERSON_ID)) {
            String dsid = data.substring(index + 1);
            userDetails.setDsid(dsid);
            LOGGER.info("DSID={}", dsid);
            webSession.subscribe( session -> {
                session.getAttributes().put(AIMLInsightsConstants.DSID, dsid);
            });
        }

        if (data.contains(AIMLInsightsConstants.LAST_NAME)) {
            String lastName = data.substring(index + 1);
            userDetails.setLastName(lastName);
            LOGGER.info("LAST_NAME={}", lastName);
            webSession.subscribe( session -> {
                session.getAttributes().put(AIMLInsightsConstants.LAST_NAME, lastName);
            });
        }

        if (data.contains(AIMLInsightsConstants.FIRST_NAME)) {
            String firstName = data.substring(index + 1);
            userDetails.setFirstName(firstName);
            LOGGER.info("FIRST_NAME={}", firstName);
            webSession.subscribe( session -> {
                session.getAttributes().put(AIMLInsightsConstants.FIRST_NAME, firstName);
            });
        }

        if (data.contains(AIMLInsightsConstants.EMAIL_ADDRESS)) {
            String emailAddress = data.substring(index + 1);
            userDetails.setEmailAddress(emailAddress);
            LOGGER.info("EMAIL_ADDRESS={}", emailAddress);
            webSession.subscribe( session -> {
                session.getAttributes().put(AIMLInsightsConstants.EMAIL_ADDRESS, emailAddress);
            });
        }

        if (data.contains(AIMLInsightsConstants.NICK_NAME_OR_PREFERRED_NAME)) {
            String preferredName = data.substring(index + 1);
            userDetails.setPreferredName(preferredName);
            LOGGER.info("PREFERRED_NAME={}", preferredName);
            webSession.subscribe( session -> {
                session.getAttributes().put(AIMLInsightsConstants.NICK_NAME_OR_PREFERRED_NAME, preferredName);
            });
        }

        if (data.contains(AIMLInsightsConstants.PRS_TYPE_CODE)) {
            String personTypeCode = data.substring(index + 1);
            userDetails.setPersonTypeCode(personTypeCode);
            LOGGER.info("PERSON_TYPE_CODE={}", personTypeCode);
            webSession.subscribe( session -> {
                session.getAttributes().put(AIMLInsightsConstants.PRS_TYPE_CODE, personTypeCode);
            });
        }

        if (data.contains(AIMLInsightsConstants.ALL_GROUPS)) {
            String allGroups = data.substring(index + 1);
            Set<String> allGroupSet = new HashSet<>();
            if(StringUtils.isNotBlank(allGroups)){
                allGroupSet = new HashSet<String>(Arrays.asList(allGroups.split(";")));
            }
            Set<String> accessGroupSet = new HashSet<String>(properties.getExceptionAccessGroups());
            allGroupSet.retainAll(accessGroupSet);
            if(allGroupSet.size() > 0) {
                LOGGER.info("Exceptional Access Group matched");
                userDetails.setExceptionAccessGroup(true);
            } else {
                LOGGER.info("Exceptional Access Group NOT matched");
                userDetails.setExceptionAccessGroup(false);
            }
            LOGGER.info("EXCEPTION_ACCESS_GROUP={}", userDetails.isExceptionAccessGroup());
            webSession.subscribe( session -> {
                session.getAttributes().put(AIMLInsightsConstants.ALL_GROUPS, allGroups);
            });
        }
    }
}
package com.apple.ist.aiml.insights.controller;

import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import javax.inject.Singleton;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.apple.ist.aiml.insights.exception.EmailNotificationException;
import com.apple.ist.aiml.insights.handler.AIMLInsightsResponseHandler;
import com.apple.ist.aiml.insights.service.SendEmailService;

@RestController
@Singleton
public class SendEmailController {
	private static final Logger LOGGER = LoggerFactory.getLogger(SendEmailController.class);

	@Autowired
	private SendEmailService aimlService;
	@Autowired
	private AIMLInsightsResponseHandler responseHandler;

	@RequestMapping(value = "/api/v1/aiml/sendEmailNotification/{planId}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON
			+ ";charset=utf-8")
	public ResponseEntity sendEmailNotification(@PathVariable String planId)
			throws JSONException, EmailNotificationException, InterruptedException, ExecutionException {
		Instant startTime = Instant.now();
		LOGGER.info("API_Name=sendEmailNotification , METHOD=POST, PLANID={}", planId);
		ResponseEntity responseStatus = null;
		try {
			 CompletableFuture sendEmailNotification = aimlService.sendEmailNotification(planId);
			 responseStatus = responseHandler.getSuccessResponse(Response.Status.OK, sendEmailNotification.get());
		} catch (EmailNotificationException | RuntimeException e) {
			LOGGER.error("EXCEPTION_OCCURRED_SENDING_EMAIL_NOTIFICATION", e);
			responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
		} finally {
			LOGGER.info("EMAIL_NOTIFICATION_CALL_STATUS={}", responseHandler.getResponseStatus(responseStatus));
			LOGGER.info("TOTAL_TIME_TAKEN_INIT_CALL={}", Duration.between(startTime, Instant.now()).toMillis());
		}
		return responseStatus;
	}
}
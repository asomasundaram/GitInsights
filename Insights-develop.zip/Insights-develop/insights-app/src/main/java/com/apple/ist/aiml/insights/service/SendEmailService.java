package com.apple.ist.aiml.insights.service;

import java.util.concurrent.CompletableFuture;

import org.springframework.http.ResponseEntity;

import com.apple.ist.aiml.insights.exception.EmailNotificationException;

public interface SendEmailService {
	CompletableFuture sendEmailNotification(String planId) throws EmailNotificationException;
}

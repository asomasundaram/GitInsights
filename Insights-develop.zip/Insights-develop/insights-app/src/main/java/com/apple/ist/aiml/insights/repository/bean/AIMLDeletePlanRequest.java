package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;

public class AIMLDeletePlanRequest implements Serializable {
    private String id;
    private String lastModifiedBy;
    private String lastModifiedTime;
    private String closureRating;
    private String closureComments;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public String getLastModifiedTime() {
        return lastModifiedTime;
    }

    public void setLastModifiedTime(String lastModifiedTime) {
        this.lastModifiedTime = lastModifiedTime;
    }

    public String getClosureRating() {
        return closureRating;
    }

    public void setClosureRating(String closureRating) {
        this.closureRating = closureRating;
    }

    public String getClosureComments() {
        return closureComments;
    }

    public void setClosureComments(String closureComments) {
        this.closureComments = closureComments;
    }
}

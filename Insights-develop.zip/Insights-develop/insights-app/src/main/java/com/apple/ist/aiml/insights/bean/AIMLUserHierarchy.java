package com.apple.ist.aiml.insights.bean;

import com.apple.ist.aiml.insights.repository.bean.*;

import java.io.Serializable;
import java.util.List;

public class AIMLUserHierarchy implements Serializable {

    private AIMLUserData userData;
    private List<AIMLUserData> directs;

    public AIMLUserData getUserData() {
        return userData;
    }

    public void setUserData(AIMLUserData userData) {
        this.userData = userData;
    }

    public List<AIMLUserData> getDirects() {
        return directs;
    }

    public void setDirects(List<AIMLUserData> directs) {
        this.directs = directs;
    }
}

package com.apple.ist.aiml.insights.utils;

import static com.apple.ist.aiml.insights.constants.AIMLInsightsConstants.ACCEPT;
import static com.apple.ist.aiml.insights.constants.AIMLInsightsConstants.APPLICATION_JSON;
import static com.apple.ist.aiml.insights.constants.AIMLInsightsConstants.AUTHORIZATION;
import static com.apple.ist.aiml.insights.constants.AIMLInsightsConstants.CONTENT_TYPE;

import java.util.function.Consumer;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StopWatch;

import com.apple.appeng.aluminum.web.client.ServiceCaller;
import com.apple.ist.aiml.insights.bean.EmailRequest;
import com.apple.ist.aiml.insights.bean.EmailResponse;
import com.apple.ist.aiml.insights.exception.EmailNotificationException;
import com.apple.ist.aiml.insights.spring.AppProperties;

@Component
public class EmailServiceCaller {

	@Autowired
	private AppProperties properties;

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailServiceCaller.class);
	private static ServiceCaller serviceCaller;
	private static final String EMAIL_SERVICE = "emailservice" + ServiceCaller.SERVICE_CALLER_BEAN_NAME_SUFFIX;
	Integer status;

	@Inject
	public EmailServiceCaller(@Named(EMAIL_SERVICE) final ServiceCaller serviceCaller) {
		this.serviceCaller = serviceCaller;
	}

	public ResponseEntity<EmailResponse> callClipperPost(final EmailRequest userEmailRequest, final String authorization)
			throws EmailNotificationException {
		LOGGER.info("EmailServiceCaller | callClipperPost | userEmailRequest : " + userEmailRequest);
		StopWatch startTime = new StopWatch("callClipperPost");
		startTime.start();
		int count = 0;
		ResponseEntity<EmailResponse> emailResponse;
		final MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
		multiValueMap.add(CONTENT_TYPE, APPLICATION_JSON);
		multiValueMap.add(ACCEPT, APPLICATION_JSON);
		multiValueMap.add(AUTHORIZATION, authorization);
		Consumer<HttpHeaders> headerInjector = headers -> headers.addAll(multiValueMap);
		
		try {
			MediaType mediaType = MediaType.valueOf(APPLICATION_JSON);
			
			do {
				emailResponse = serviceCaller.getWebClient().post().uri(builder -> builder.path("").build())
						.headers(headerInjector).bodyValue(userEmailRequest).accept(mediaType).retrieve().toEntity(EmailResponse.class).
						toFuture().get();
				
				count++;
			} while (emailResponse.getStatusCode()!=HttpStatus.CREATED && count <= 2);
			LOGGER.info("EmailServiceCaller | callClipperPost | emailResponse : " + emailResponse);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
			throw new EmailNotificationException("Exception in callClipperPost" + e.getMessage());
		} finally {
			startTime.stop();
			LOGGER.info("CG_ADMIN_SVCS_CLIPPER_TIME_TAKEN={}", startTime.getTotalTimeMillis());
		}
		return emailResponse;
	}
	

}
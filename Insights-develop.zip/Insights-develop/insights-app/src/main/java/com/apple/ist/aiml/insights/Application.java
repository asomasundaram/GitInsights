/*
 * Copyright 2023 Apple, Inc
 * Apple Internal Use Only
 */


package com.apple.ist.aiml.insights;


import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.apple.appeng.aluminum.core.application.annotations.types.ServiceFacade;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@ServiceFacade
@SpringBootApplication(scanBasePackages = "com.apple.ist.aiml.insights")
public class Application {
    private static final Logger LOGGER = LoggerFactory.getLogger(Application.class);


    public static void main(final String... args) {
        final SpringApplication app = new SpringApplication(Application.class);
        app.run(args);
    }

    @PostConstruct
    public void init() {
        LOGGER.info("Starting up IST AIML Insights Insights App Service Facade");
    }
}

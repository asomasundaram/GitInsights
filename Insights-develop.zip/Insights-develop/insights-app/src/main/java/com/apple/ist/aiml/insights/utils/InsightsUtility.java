package com.apple.ist.aiml.insights.utils;

import com.apple.ist.aiml.insights.constants.AIMLInsightsConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.server.WebSession;

import javax.inject.Named;

@Named
public class InsightsUtility {

    public void persistRequestParamsInSession(WebSession session, String dsid, String roleId, String locale) {
        if (StringUtils.isNotBlank(dsid)) {
            session.getAttributes().put(AIMLInsightsConstants.INPUT_DSID, dsid);
        } else {
            session.getAttributes().put(AIMLInsightsConstants.INPUT_DSID, "");
        }

        if (StringUtils.isNotBlank(roleId)) {
            session.getAttributes().put(AIMLInsightsConstants.INPUT_ROLE_ID, roleId);
        } else {
            session.getAttributes().put(AIMLInsightsConstants.INPUT_ROLE_ID, "");
        }

        if (StringUtils.isNotBlank(locale)) {
            session.getAttributes().put(AIMLInsightsConstants.INPUT_LOCALE, locale);
        } else {
            session.getAttributes().put(AIMLInsightsConstants.INPUT_LOCALE, "");
        }
    }
}
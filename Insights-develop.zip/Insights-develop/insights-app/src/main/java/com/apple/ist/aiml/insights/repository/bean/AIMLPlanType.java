package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;

public class AIMLPlanType implements Serializable {

    private String aiml_planType_standard_coaching;
    private String aiml_planType_additional_development;
    private String aiml_planType_action_plan;
    private String aiml_planType_documented_coaching;
    private String aiml_planType_no_plan;

    public String getAiml_planType_standard_coaching() {
        return aiml_planType_standard_coaching;
    }

    public void setAiml_planType_standard_coaching(String aiml_planType_standard_coaching) {
        this.aiml_planType_standard_coaching = aiml_planType_standard_coaching;
    }

    public String getAiml_planType_additional_development() {
        return aiml_planType_additional_development;
    }

    public void setAiml_planType_additional_development(String aiml_planType_additional_development) {
        this.aiml_planType_additional_development = aiml_planType_additional_development;
    }

    public String getAiml_planType_action_plan() {
        return aiml_planType_action_plan;
    }

    public void setAiml_planType_action_plan(String aiml_planType_action_plan) {
        this.aiml_planType_action_plan = aiml_planType_action_plan;
    }

    public String getAiml_planType_documented_coaching() {
        return aiml_planType_documented_coaching;
    }

    public void setAiml_planType_documented_coaching(String aiml_planType_documented_coaching) {
        this.aiml_planType_documented_coaching = aiml_planType_documented_coaching;
    }

    public String getAiml_planType_no_plan() {
        return aiml_planType_no_plan;
    }

    public void setAiml_planType_no_plan(String aiml_planType_no_plan) {
        this.aiml_planType_no_plan = aiml_planType_no_plan;
    }
}

package com.apple.ist.aiml.insights.repository.bean;

import java.util.List;

public class AIMLUserDelegation {

    AIMLUserData managerData;
    List<AIMLUserData> delegatesData;

    public AIMLUserData getManagerData() {
        return managerData;
    }

    public void setManagerData(AIMLUserData managerData) {
        this.managerData = managerData;
    }

    public List<AIMLUserData> getDelegatesData() {
        return delegatesData;
    }

    public void setDelegatesData(List<AIMLUserData> delegatesData) {
        this.delegatesData = delegatesData;
    }
}

package com.apple.ist.aiml.insights.service.impl;

import static com.apple.ist.aiml.insights.constants.AIMLInsightsConstants.DEFAULT_LOCALE;
import static com.apple.ist.aiml.insights.utils.AIMLUtils.convertStringToTitleCase;

import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.apple.ist.aiml.insights.bean.EmailRequest;
import com.apple.ist.aiml.insights.bean.EmailResponse;
import com.apple.ist.aiml.insights.bean.FromEmail;
import com.apple.ist.aiml.insights.exception.AIMLInsightsException;
import com.apple.ist.aiml.insights.exception.EmailNotificationException;
import com.apple.ist.aiml.insights.handler.AIMLInsightsResponseHandler;
import com.apple.ist.aiml.insights.repository.AIMLInsightsPlanRepository;
import com.apple.ist.aiml.insights.repository.bean.AIMLBehaviors;
import com.apple.ist.aiml.insights.repository.bean.AIMLCompetency;
import com.apple.ist.aiml.insights.repository.bean.AIMLEmailResponse;
import com.apple.ist.aiml.insights.repository.bean.AIMLFocusAreaMetrics;
import com.apple.ist.aiml.insights.repository.bean.AIMLTasks;
import com.apple.ist.aiml.insights.repository.bean.AIMLUserData;
import com.apple.ist.aiml.insights.service.SendEmailService;
import com.apple.ist.aiml.insights.spring.AppProperties;
import com.apple.ist.aiml.insights.utils.EmailServiceCaller;

@Component
public class SendEmailServiceImpl implements SendEmailService {

	@Autowired
	private AppProperties properties;
	@Inject
	AIMLInsightsPlanRepository mongoRepository;
	@Autowired
	private AIMLInsightsResponseHandler responseHandler;
	@Autowired
	private EmailServiceCaller emailServiceCaller;
	@Autowired
	private AppTranslatorServiceImpl appTranslatorServiceImpl;

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailServiceCaller.class);

	@Async
	@Override
	public CompletableFuture sendEmailNotification(String planId) throws EmailNotificationException {
		ResponseEntity response = null;
		try {
			AIMLEmailResponse aimlEmailResponse = mongoRepository.fetchAIMLPlanAndUserData(planId);
			LOGGER.info("AIML_PLAN_AND_USER_RESPONSE={}", aimlEmailResponse);
			ResponseEntity<EmailResponse> emailResponse = emailServiceCaller.callClipperPost(buildEmailRequest(aimlEmailResponse),properties.getAuthorization());
			LOGGER.info("EMAIL_NOTIFICATION_RESPONSE={}", emailResponse);
			response = responseHandler.getSuccessResponse(Response.Status.OK, emailResponse);
		} catch (Exception e) {
			response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
			throw new EmailNotificationException("Exception occurred while sending email", e);
		}
		return CompletableFuture.completedFuture(response);
	}

	private EmailRequest buildEmailRequest(AIMLEmailResponse aimlEmailResponse) throws AIMLInsightsException {

		aimlEmailResponse.setPlanMonth(StringUtils.capitalize(Month.of(Integer.valueOf(aimlEmailResponse.getPlanMonth())).toString().toLowerCase()));
		aimlEmailResponse.setPlanState(convertStringToTitleCase(aimlEmailResponse.getPlanState().toLowerCase()));
		findLocale(aimlEmailResponse);
		try {
		internalizationMessageMapping(aimlEmailResponse, null);
		} catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred while processing messages from AppTranslator", e);
        }
		EmailRequest emailRequest = new EmailRequest();
		FromEmail fromEmail = new FromEmail();
		fromEmail.setName(properties.getFromEmail());
		emailRequest.setFrom(fromEmail);
		emailRequest.setSubject(buildEmailSubject(aimlEmailResponse));
		emailRequest.setSubscriptionid(properties.getSubscriptionId());
		emailRequest.setTemplateid(properties.getTemplateId());
		emailRequest.setTo(getAllEmailAddresses(aimlEmailResponse));
		emailRequest.setData(buildTaskOwnerDetails(aimlEmailResponse));
		return emailRequest;
	}

	private AIMLEmailResponse buildTaskOwnerDetails(AIMLEmailResponse aimlEmailResponse) {
		Map<String, List<AIMLUserData>> dsidByUserData = aimlEmailResponse.getTaskOwnerDetails().stream()
				.collect(Collectors.groupingBy(AIMLUserData::getDsid));
		for (AIMLTasks task : aimlEmailResponse.getTasks()) {
			AIMLUserData aimlUserData = dsidByUserData.get(task.getTaskOwner()).get(0);
			task.setTaskOwner(aimlUserData.getFirstName() + " " + aimlUserData.getLastName());
			task.setTaskStatus(convertStringToTitleCase(task.getTaskStatus()));
		}
		return aimlEmailResponse;
	}

	private String[] getAllEmailAddresses(AIMLEmailResponse aimlEmailResponse) {
		List<String> taskOwnereEmails = aimlEmailResponse.getTaskOwnerDetails().stream().map(e -> e.getEmailAddress())
				.collect(Collectors.toList());
		taskOwnereEmails.addAll(aimlEmailResponse.getUserDetails().stream().map(e -> e.getEmailAddress())
				.collect(Collectors.toList()));
		taskOwnereEmails.add(aimlEmailResponse.getCreatedByEmail());
		return Arrays.asList(taskOwnereEmails.stream().distinct().toArray()).toArray(new String[0]);
	}

	private String buildEmailSubject(AIMLEmailResponse aimlEmailResponse) {
		AIMLUserData aimlUserData = aimlEmailResponse.getUserDetails().get(0);
		return aimlUserData.getFirstName() + " " + aimlUserData.getLastName() + " : " + aimlEmailResponse.getPlanMonth() + " "
				+ aimlEmailResponse.getPlanYear() + " " + aimlEmailResponse.getPlanType();
	}

	private AIMLEmailResponse internalizationMessageMapping(AIMLEmailResponse aimlEmailResponse, String locale)
			throws AIMLInsightsException {
		
		if(locale==null) {
			locale=DEFAULT_LOCALE;
		}
		Map<String, String> messages = appTranslatorServiceImpl.loadAppTransalatorMessages(locale).getMessages();

		if (messages.get(aimlEmailResponse.getPlanType()) != null)
			aimlEmailResponse.setPlanType(messages.get(aimlEmailResponse.getPlanType()));

		for (AIMLFocusAreaMetrics focusAreaMetrics : aimlEmailResponse.getFocusAreaMetrics()) {
			if (messages.get(focusAreaMetrics.getFocusArea()) != null)
				focusAreaMetrics.setFocusArea(messages.get(focusAreaMetrics.getFocusArea()));

			ArrayList<String> arrayList = new ArrayList<>();
			for (String focusAreaMetric : focusAreaMetrics.getFocusAreaMetrics()) {
				if (messages.get(focusAreaMetric) != null) {
					arrayList.add(messages.get(focusAreaMetric));
				} else {
					arrayList.add(focusAreaMetric);
				}
			}
			focusAreaMetrics.setFocusAreaMetrics(arrayList);
		}
		
		for (AIMLBehaviors aimlBehaviors : aimlEmailResponse.getBehaviors()) {
			if (messages.get(aimlBehaviors.getBehaviorCode()) != null)
				aimlBehaviors.setBehaviorCode(messages.get(aimlBehaviors.getBehaviorCode()));
		}

		for (AIMLCompetency aimlCompetency : aimlEmailResponse.getCompetencyFocus().getCompetencies()) {
			if (messages.get(aimlCompetency.getFocusArea()) != null)
				aimlCompetency.setFocusArea(messages.get(aimlCompetency.getFocusArea()));
		}
		return aimlEmailResponse;
	}
	
	private AIMLEmailResponse findLocale(AIMLEmailResponse aimlEmailResponse) {
		AIMLUserData userData = aimlEmailResponse.getUserDetails().get(0);
		ArrayList<String> listOfLocale = new ArrayList<String>();
			listOfLocale.add(userData.getL1Locale());
			listOfLocale.add( userData.getL2Locale());
			listOfLocale.add( userData.getL3Locale());
			listOfLocale.add( userData.getL4Locale());
			listOfLocale.add( userData.getL5Locale());
		aimlEmailResponse.setLocale(listOfLocale.stream().distinct().filter(locale-> Objects.nonNull(locale) && !locale.equals("null")).collect(Collectors.toList()));
		return aimlEmailResponse;
	}
}
package com.apple.ist.aiml.insights.repository.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Metadata implements Serializable {
    private String creationRoleId;
    private String creationRoleName;

    public String getCreationRoleId() {
        return creationRoleId;
    }

    public void setCreationRoleId(String creationRoleId) {
        this.creationRoleId = creationRoleId;
    }

    public String getCreationRoleName() {
        return creationRoleName;
    }

    public void setCreationRoleName(String creationRoleName) {
        this.creationRoleName = creationRoleName;
    }
}

package com.apple.ist.aiml.insights.bean;

import java.util.Map;

public class AppTranslatorMessages {
    private String locale;
    private Map<String, String> messages;

    public Map<String, String> getMessages() {
        return messages;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public void setMessages(Map<String, String> messages) {
        this.messages = messages;
    }

    @Override
    public String toString() {
        return "AppTranslatorMessages [messages=" + messages + "]";
    }
}

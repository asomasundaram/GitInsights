package com.apple.ist.aiml.insights.exception;

import java.io.Serializable;

public class AIMLInsightsException extends Exception implements Serializable {

    public AIMLInsightsException(final String errorMessage) {
        super(errorMessage);
    }

    public AIMLInsightsException(final String errorMessage, final Throwable exception) {
        super(errorMessage, exception);
    }

    public AIMLInsightsException(final Throwable exception) {
        super(exception);
    }
}

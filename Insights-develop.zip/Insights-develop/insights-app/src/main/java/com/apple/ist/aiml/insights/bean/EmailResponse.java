package com.apple.ist.aiml.insights.bean;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class EmailResponse implements Serializable{

    private static final long serialVersionUID = 1L;
	private String message;
    private String requestid;

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

    public String getRequestid() {
        return requestid;
    }

    public void setRequestid(final String requestid) {
        this.requestid = requestid;
    }
    @Override
    public String toString() {
        return "EmailResponse :" + ReflectionToStringBuilder.toString(this);
    }
}
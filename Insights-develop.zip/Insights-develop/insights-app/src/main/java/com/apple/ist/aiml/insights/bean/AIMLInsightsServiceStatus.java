package com.apple.ist.aiml.insights.bean;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AIMLInsightsServiceStatus<T> extends AIMLInsightsResponseStatus<T> implements Serializable {

    private static final long serialVersionUID = 7306764896819489326L;
    private String status;
    private int statusCode;
    private String errorMessage;
    private Map<String, String> customErrorMessage;
    private long recordCount;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Map<String, String> getCustomErrorMessage() {
        return customErrorMessage;
    }

    public void setCustomErrorMessage(Map<String, String> customErrorMessage) {
        this.customErrorMessage = customErrorMessage;
    }

    public long getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(long recordCount) {
        this.recordCount = recordCount;
    }

}

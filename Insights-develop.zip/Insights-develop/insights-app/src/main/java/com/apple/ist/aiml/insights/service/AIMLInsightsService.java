package com.apple.ist.aiml.insights.service;

import com.apple.ist.aiml.insights.exception.AIMLInsightsException;
import com.apple.ist.aiml.insights.repository.bean.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.WebSession;

public interface AIMLInsightsService {
    ResponseEntity fetchMetaData(WebSession session) throws AIMLInsightsException;
    ResponseEntity fetchUserHierarchy(String dsid) throws AIMLInsightsException;
    ResponseEntity fetchPlans() throws AIMLInsightsException;
    ResponseEntity fetchRecentPlans(AIMLRecentPlansRequest requestDetails) throws AIMLInsightsException;
    ResponseEntity saveAIMLPlans(AIMLPlans aimlPlans) throws AIMLInsightsException;
    ResponseEntity getAIMLPlans(AIMLFetchPlanRequest requestDetails) throws AIMLInsightsException;
    ResponseEntity updateAIMLPlans(AIMLPlans plans)throws AIMLInsightsException;
    ResponseEntity deleteAIMLPlans(AIMLDeletePlanRequest deleteDetails) throws AIMLInsightsException;
    ResponseEntity getPlanAggregate(AIMLSTLViewRequest requestDetails) throws AIMLInsightsException;
    ResponseEntity getAIMLTasks(AIMLTaskViewRequest requestDetails)throws AIMLInsightsException;

    ResponseEntity getAIMLTaskAggregate(AIMLSTLViewRequest requestDetails)throws AIMLInsightsException;

    ResponseEntity updateTask(AIMLTaskUpdate requestDetails)throws AIMLInsightsException;
    boolean authorizeUserMaestroData(final String dsid, final String businessUnitId) throws AIMLInsightsException;
    public ResponseEntity fetchMaestroUserData(String dsid) throws AIMLInsightsException;

    ResponseEntity fetchDelegationUserHierarchy(String dsid)throws AIMLInsightsException;
}

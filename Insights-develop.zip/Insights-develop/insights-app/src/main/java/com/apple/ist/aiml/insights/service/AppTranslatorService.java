package com.apple.ist.aiml.insights.service;

import com.apple.ist.aiml.insights.exception.AIMLInsightsException;
import org.springframework.http.ResponseEntity;

public interface AppTranslatorService {
     ResponseEntity fetchAppTransalatorMessages (final String locale) throws AIMLInsightsException;
}

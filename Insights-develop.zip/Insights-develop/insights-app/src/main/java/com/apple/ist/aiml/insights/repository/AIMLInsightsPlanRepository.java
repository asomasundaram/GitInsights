package com.apple.ist.aiml.insights.repository;

import com.apple.ist.aiml.insights.bean.AIMLUserHierarchy;
import com.apple.ist.aiml.insights.constants.AIMLInsightsConstants;
import com.apple.ist.aiml.insights.controller.InsightsAppController;
import com.apple.ist.aiml.insights.exception.AIMLInsightsException;
import com.apple.ist.aiml.insights.repository.bean.*;
import com.apple.ist.aiml.insights.service.SendEmailService;
import com.apple.ist.aiml.insights.utils.AIMLUtils;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.bson.BsonNull;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;

import javax.inject.Inject;
import javax.inject.Named;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

import static com.mongodb.client.model.Sorts.descending;
import com.apple.ist.aiml.insights.exception.EmailNotificationException;

@Named
public class AIMLInsightsPlanRepository {
    private final MongoCollection<Document> mongoCollectionPlans;
    private final MongoCollection<Document> mongoCollectionPlanTypes;
    private final MongoCollection<Document> mongoCollectionFocusAreaMetrics;
    private final MongoCollection<Document> mongoCollectionBehaviors;
    private final MongoCollection<Document> mongoCollectionTasks;
    private final MongoCollection<Document> mongoCollectionCompetencyFocus;
    private final MongoCollection<Document> mongoCollectionMaestroUserData;
    
    @Autowired
    @Lazy
    private  SendEmailService emailService;

    private static final Logger LOGGER = LoggerFactory.getLogger(InsightsAppController.class);

    @Inject
    public AIMLInsightsPlanRepository(
            @Named("default.aimlPlans") final MongoCollection<Document> mongoCollectionPlans,
            @Named("default.aimlPlanTypes") final MongoCollection<Document> mongoCollectionPlanTypes,
            @Named("default.aimlFocusAreaMetrics") final MongoCollection<Document> mongoCollectionFocusAreaMetrics,
            @Named("default.aimlBehaviors") final MongoCollection<Document> mongoCollectionBehaviors,
            @Named("default.aimlTasks") final MongoCollection<Document> mongoCollectionTasks,
            @Named("default.aimlCompetencyFocus") final MongoCollection<Document> mongoCollectionCompetencyFocus,
            @Named("default.aimlMaestroUserData") final MongoCollection<Document> mongoCollectionMaestroUserData
    ) {
        this.mongoCollectionPlans = mongoCollectionPlans;
        this.mongoCollectionPlanTypes = mongoCollectionPlanTypes;
        this.mongoCollectionFocusAreaMetrics = mongoCollectionFocusAreaMetrics;
        this.mongoCollectionBehaviors = mongoCollectionBehaviors;
        this.mongoCollectionTasks = mongoCollectionTasks;
        this.mongoCollectionCompetencyFocus = mongoCollectionCompetencyFocus;
        this.mongoCollectionMaestroUserData = mongoCollectionMaestroUserData;
    }

    public List<AIMLPlans> fetchAIMLPlans(int businessUnitId) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchAIMLPlans()");
        List<AIMLPlans> planList = new ArrayList<>();
        try {
            Bson buFilter = Filters.eq("businessUnitId", businessUnitId);
            FindIterable<Document> document = mongoCollectionPlans.find(buFilter);
            if (document != null) {
                //document = document.sort(Sorts.ascending("typeName"));
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(document, AIMLRepositoryResponse.class,
                        "aimlPlansList");
                planList = response.getAimlPlansList();
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_AIMLPlans", e);
            throw new AIMLInsightsException("Exception occurred while fetching AIMLPlans from DB", e);
        } finally {
            LOGGER.info("Response fetchAIMLPlans={}", planList);
            LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchAIMLPlans={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return planList;
    }

    public List<AIMLPlanTypes> fetchAIMLPlanTypes(String businessUnitId) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchAIMLPlanTypes()");
        List<AIMLPlanTypes> planTypes = new ArrayList<>();
        try {
            Bson buFilter = Filters.eq("businessUnitId", businessUnitId);
            FindIterable<Document> document = mongoCollectionPlanTypes.find(buFilter);
            if (document != null) {
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(document, AIMLRepositoryResponse.class,
                        "aimlPlanTypes");
                planTypes = response.getAimlPlanTypes();
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_AIMLPlanTypes", e);
            throw new AIMLInsightsException("Exception occurred while fetching AIMLPlanTypes from DB", e);
        } finally {
            LOGGER.info("Response fetchAIMLPlanTypes={}", planTypes);
            LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchAIMLPlanTypes={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return planTypes;
    }

    public List<AIMLFocusAreaMetrics> fetchFocusAreaMetrics(String businessUnitId) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchFocusAreaMetrics()");
        List<AIMLFocusAreaMetrics> focusAreaMetricsArrayList = new ArrayList<>();
        try {
            Bson buFilter = Filters.eq("businessUnitId", businessUnitId);
            FindIterable<Document> document = mongoCollectionFocusAreaMetrics.find(buFilter);
            if (document != null) {
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(document, AIMLRepositoryResponse.class,
                        "aimlFocusAreaMetricsList");
                focusAreaMetricsArrayList = response.getAimlFocusAreaMetricsList();
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_AIMLFocusAreaMetrics", e);
            throw new AIMLInsightsException("Exception occurred while fetching AIMLFocusAreaMetrics from DB", e);
        } finally {
            LOGGER.info("Response fetchFocusAreaMetrics={}", focusAreaMetricsArrayList);
            LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchFocusAreaMetrics={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return focusAreaMetricsArrayList;
    }

    public List<AIMLBehaviors> fetchBehaviors(String businessUnitId) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchBehaviors()");
        List<AIMLBehaviors> behaviorsList = new ArrayList<>();
        try {
            Bson buFilter = Filters.eq("businessUnitId", businessUnitId);
            FindIterable<Document> document = mongoCollectionBehaviors.find(buFilter);
            if (document != null) {
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(document, AIMLRepositoryResponse.class,
                        "aimlBehaviorList");
                behaviorsList = response.getAimlBehaviorList();
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_AIMLBehaviorList", e);
            throw new AIMLInsightsException("Exception occurred while fetching AIMLBehaviors from DB", e);
        } finally {
            LOGGER.info("Response fetchBehaviors={}", behaviorsList);
            LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchBehaviors={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return behaviorsList;
    }

    public List<AIMLTasks> fetchTasks(String businessUnitId) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchTasks()");
        List<AIMLTasks> tasksList = new ArrayList<>();
        try {
            Bson buFilter = Filters.eq("businessUnitId", businessUnitId);
            FindIterable<Document> document = mongoCollectionTasks.find(buFilter);
            if (document != null) {
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(document, AIMLRepositoryResponse.class,
                        "aimlTaskList");
                tasksList = response.getAimlTaskList();
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_AIMLTasksList", e);
            throw new AIMLInsightsException("Exception occurred while fetching AIMLTasks from DB", e);
        } finally {
            LOGGER.info("Response fetchBehaviors={}", tasksList);
            LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchTasks={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return tasksList;
    }

    public AIMLUserData fetchUserData(String businessUnitId, String dsid) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchUserData() BU_ID={} DSID={}", businessUnitId, dsid);
        AIMLUserData userData = new AIMLUserData();
        try {
            Bson buFilter = Filters.eq("businessUnitId", businessUnitId);
            Bson dsidFilter = Filters.eq("dsid", dsid);
            Bson userDataFilter = Filters.and(buFilter, dsidFilter);
            Document document = mongoCollectionMaestroUserData.find(userDataFilter).first();
            if (document != null) {
                userData = MongoRepositoryUtil.getPOJOFromDocument(document, AIMLUserData.class);
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_AIML_USERDATA", e);
            throw new AIMLInsightsException("Exception occurred while fetching AIML UserData from DB", e);
        } finally {
            LOGGER.info("Response fetchUserData={}", userData);
            LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchUserData={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return userData;
    }

    public List<AIMLCompetencyFocusMetadata> fetchCompetencyFocus(String businessUnitId) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchCompetencyFocus()");
        List<AIMLCompetencyFocusMetadata> competencyFocusList = new ArrayList<>();
        AggregateIterable<Document> aggregateDocument = null;
        try {
            aggregateDocument = mongoCollectionCompetencyFocus.aggregate(Arrays.asList(new Document("$match",
                            new Document("businessUnitId", "AIML")),
                    new Document("$unwind",
                            new Document("path", "$focusList")
                                    .append("preserveNullAndEmptyArrays", true)),
                    new Document("$group",
                            new Document("_id",
                                    new Document("factorName", "$factorName")
                                            .append("categoryName", "$categoryName"))
                                    .append("focusList",
                                            new Document("$addToSet", "$focusList"))),
                    new Document("$project",
                            new Document("factorName", "$_id.factorName")
                                    .append("categoryName", "$_id.categoryName")
                                    .append("focusList", "$focusList")),
                    new Document("$group",
                            new Document("_id", "$factorName")
                                    .append("categoryName",
                                            new Document("$addToSet",
                                                    new Document("categoryName", "$categoryName")
                                                            .append("focusList", "$focusList")))),
                    new Document("$project",
                            new Document("factorName", "$_id")
                                    .append("categoryList", "$categoryName"))));
            if (aggregateDocument != null) {
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(aggregateDocument, AIMLRepositoryResponse.class,
                        "aimlCompetencyFocusList");
                competencyFocusList = response.getAimlCompetencyFocusList();
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_AIML_COMPETENCY_FOCUS", e);
            throw new AIMLInsightsException("Exception occurred while fetching AIML COMPETENCY_FOCUS from DB", e);
        } finally {
            LOGGER.info("Response fetchCompetencyFocus={}", competencyFocusList);
            LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchCompetencyFocus={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return competencyFocusList;
    }
    public List<AIMLUserData> fetchUserHierarchy(String businessUnitId, String managerDsid) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchUserHierarchy()");
        AIMLUserHierarchy userHierarchy = new AIMLUserHierarchy();
        List<AIMLUserData> userDataList = new ArrayList<>();
        try {
            LOGGER.info("AIMLInsightsPlanRepository : fetchUserHierarchy()");
            try {
                Bson buFilter = Filters.eq("businessUnitId", businessUnitId);
                Bson managerDsidFilter = Filters.eq("managerDsid", managerDsid);
                Bson userDataFilter = Filters.and(buFilter, managerDsidFilter);
                FindIterable<Document> document = mongoCollectionMaestroUserData.find(userDataFilter);
                if (document != null) {
                    AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(document, AIMLRepositoryResponse.class,
                            "aimlUserDataList");
                    userDataList = response.getAimlUserDataList();
                }
            } catch (Exception e) {
                LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_AIMLUserHierarchy", e);
                throw new AIMLInsightsException("Exception occurred while fetching AIMLUserHierarchy from DB", e);
            } finally {
                LOGGER.info("Response fetchUserHierarchy={}", userDataList);
                LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchUserHierarchy={}",
                        Duration.between(startTime, Instant.now()).toMillis());
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_AIML_USER_HIERARCHY", e);
            throw new AIMLInsightsException("Exception occurred while fetching AIML UserData from DB", e);
        } finally {
            LOGGER.info("Response fetchUserHierarchy={}", userHierarchy);
            LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchUserHierarchy={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return userDataList;
    }

    public List<AIMLPlans> fetchRecentPlans(AIMLRecentPlansRequest requestDetails) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchLastThreeMonthsPlan()");
        List<AIMLPlans> planList = new ArrayList<>();

        try {
            String planDsid = requestDetails.getDsid();
            String inputDate = requestDetails.getPlanStartDate();
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate localDate = LocalDate.parse(inputDate, dateFormatter);
            localDate = localDate.minusMonths(1); // Decrement the month by 1
            Date updatedDate = new Date(localDate.format(dateFormatter));
            AggregateIterable<Document> aggregateDocument = null;
            aggregateDocument = mongoCollectionPlans.aggregate(Arrays.asList(new Document("$match",
                            new Document("isDeleted", false)
                                    .append("planDsid", requestDetails.getDsid())),
                    new Document("$addFields",
                            new Document("planMonthYear",
                                    new Document("$concat", Arrays.asList("$planYear", "-", "$planMonth", "-", "01")))),
                    new Document("$addFields",
                            new Document("dateString",
                                    new Document("$dateFromString",
                                            new Document("dateString", "$planMonthYear")))),
                    new Document("$match",
                            new Document("$expr",
                                    new Document("$lt", Arrays.asList("$dateString",
                                            new Document("$dateFromString",
                                                    new Document("dateString", updatedDate.toString())))))),
                    new Document("$sort",
                            new Document("dateString", -1L)),
                    new Document("$limit", requestDetails.getLimit())));
            if (aggregateDocument != null) {
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(aggregateDocument, AIMLRepositoryResponse.class,
                        "aimlPlansList");
                planList = response.getAimlPlansList();
            }
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_3MONTHS_CALL", e);
            throw new AIMLInsightsException("Exception occurred while fetching last three months plan from DB", e);
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_LAST_THREE_MONTHS_PLANS", e);
            throw new AIMLInsightsException("Exception occurred while fetching last three months plan from DB", e);
        } finally {
            LOGGER.info("Response fetchLastThreeMonthsPlan={}", planList);
            LOGGER.info("FETCH_LAST_THREE_MONTHS_PLAN_TOTAL_TIME_TAKEN={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return planList;
    }

    public Map<String, String> saveAIMLPlans(Document planDoc) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : saveAIMLPlans()");
        Map<String, String> responseMap = new HashMap<>();
        try {
            Bson activePlanFilter = new Document("planDsid", planDoc.getString("planDsid"))
                    .append("planState", AIMLInsightsConstants.PLAN_STATE_IN_PROGRESS);
            long count = mongoCollectionPlans.countDocuments(activePlanFilter);
            if (count == 0 || (!planDoc.getString("planState").equalsIgnoreCase(AIMLInsightsConstants.PLAN_STATE_IN_PROGRESS))) {
                Bson existingPlanFilter = checkplanExists(planDoc);
                FindIterable<Document> existingPlan = mongoCollectionPlans.find(existingPlanFilter);
                AIMLRepositoryResponse existingPlanResponse = MongoRepositoryUtil.getPOJOFromDocument(existingPlan, AIMLRepositoryResponse.class,
                        "aimlPlansList");
                List<AIMLPlans> planList = existingPlanResponse.getAimlPlansList();
                if (planList != null && planList.size() > 0) {
                    responseMap.put(AIMLInsightsConstants.PLAN_ALREADY_EXISTS, "");
                } else {
                    mongoCollectionPlans.insertOne(planDoc);
                    ObjectId mongoId = planDoc.getObjectId("_id");
                    if (mongoId != null) {
                        responseMap.put(AIMLInsightsConstants.PLAN_SAVED_SUCCESSFULLY, mongoId.toString());
                        List<AIMLPlans> plans = MongoRepositoryUtil.getPOJOFromDocument(existingPlan, AIMLRepositoryResponse.class,"aimlPlansList").getAimlPlansList();
                        if(plans.get(0).getPlanState().equals(AIMLInsightsConstants.PLAN_STATE_IN_PROGRESS))
                        	emailService.sendEmailNotification(plans.get(0).getId());
                    }
                }
            } else {
                responseMap.put(AIMLInsightsConstants.ACTIVE_PLAN_EXISTS, "");
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_AIMLInsightsPlanRepository_saveAIMLPlans", e);
            throw new AIMLInsightsException("Exception occurred while saving plan to  DB", e);
        } finally {
            LOGGER.info("SAVE_AIML_PLANS={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseMap;
    }

    public List<AIMLPlanList> getAIMLPlans(AIMLFetchPlanRequest requestDetails) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : getAIMLPlans()");
        AggregateIterable<Document> aggregateDocument = null;
        List<AIMLPlanList> aimlPlanList = new ArrayList<>();

        try {
            List<Document> planDsidList = requestDetails.getCreatedFor().stream()
                    .map(planDsid -> new Document("planDsid", planDsid))
                    .collect(Collectors.toList());

            aggregateDocument = mongoCollectionPlans.aggregate(Arrays.asList(new Document("$match",
                            new Document("$or", planDsidList)),
                    new Document("$match",
                            new Document("$or", Arrays.asList(new Document("isDeleted", false),
                                    new Document("isDeleted",
                                            new Document("$exists", false))))),
                            new Document("$sort",
                            new Document("publishedDateTime", -1L)),
                    new Document("$match",
                            new Document("$or", Arrays.asList(new Document("planState", "DRAFT"),
                                    new Document("planState", "IN_PROGRESS"),
                                    new Document("planState", "COMPLETED")))),
                    new Document("$group",
                            new Document("_id", "$planDsid")
                                    .append("doc",
                                            new Document("$push", "$$ROOT"))),
                    new Document("$project",
                            new Document("_id", 0L)
                                    .append("planDsid", "$_id")
                                    .append("doc",
                                            new Document("$concatArrays", Arrays.asList(new Document("$slice", Arrays.asList(new Document("$filter",
                                                            new Document("input", "$doc")
                                                                    .append("as", "d")
                                                                    .append("cond",
                                                                            new Document("$eq", Arrays.asList("$$d.planState", "DRAFT")))), 2L)),
                                                    new Document("$slice", Arrays.asList(new Document("$filter",
                                                            new Document("input", "$doc")
                                                                    .append("as", "d")
                                                                    .append("cond",
                                                                            new Document("$eq", Arrays.asList("$$d.planState", "IN_PROGRESS")))), 1L)),
                                                    new Document("$slice", Arrays.asList(new Document("$filter",
                                                            new Document("input", "$doc")
                                                                    .append("as", "d")
                                                                    .append("cond",
                                                                            new Document("$eq", Arrays.asList("$$d.planState", "COMPLETED")))), (long)requestDetails.getLimit()))))))));
            if (aggregateDocument != null) {
                for (Document document : aggregateDocument) {
                    AIMLPlanList AIMLPlan = new AIMLPlanList();
                    AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(document.getList("doc", Document.class), AIMLRepositoryResponse.class,
                            "aimlPlansList");
                    AIMLPlan.setPlanDsid(document.getString("planDsid"));
                    AIMLPlan.setPlansList(response.getAimlPlansList());
                    aimlPlanList.add(AIMLPlan);
                }
            }
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_GET_AIML_PLANS", e);
            throw new AIMLInsightsException("Exception occurred while getting AIML plan landing page from DB", e);
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_GET_AIML_PLANS_PLANS", e);
            throw new AIMLInsightsException("Exception occurred while getting AIML plan landing page from DB", e);
        } finally {
            LOGGER.info("Response GET_AIML_PLANS={}", aimlPlanList);
            LOGGER.info("TOTAL_TIME_TAKEN_BY_GET_AIML_PLANS={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return aimlPlanList;
    }

    public Map<String, String> updateAIMLPlans(Document planDoc, LocalDate planEndDate) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : updateAIMLPlans()");
        AIMLPlans existingAimlPlan = new AIMLPlans();
        AIMLPlans docToBeUpdated = new AIMLPlans();
        Map<String, String> response = new HashMap<>();
        try {
            Bson existingPlanFilter = checkplanExists(planDoc);
            Document existingPlan = mongoCollectionPlans.find(existingPlanFilter).first();
            if (existingPlan != null) {
                existingAimlPlan = MongoRepositoryUtil.getPOJOFromDocument(existingPlan, AIMLPlans.class);
                docToBeUpdated = MongoRepositoryUtil.getPOJOFromDocument(planDoc, AIMLPlans.class);
                long daysRemaining = ChronoUnit.DAYS.between(LocalDate.now(), planEndDate);
                Boolean isRecordModified = AIMLUtils.isRecordModified(existingAimlPlan.getLastModifiedTime(),docToBeUpdated.getLastModifiedTime());
                if (existingAimlPlan != null && isRecordModified) {
                    if (existingAimlPlan.getTasks().size() < docToBeUpdated.getTasks().size()) {
                        if (daysRemaining < 10) {
                            response.put(AIMLInsightsConstants.INVALID_TASK_UPDATE,"");
                        } else {
                            updatePlan(planDoc, existingAimlPlan, response, existingPlanFilter);
                        }
                    } if(StringUtils.isNotBlank(docToBeUpdated.getPlanState()) &&
                            docToBeUpdated.getPlanState().equalsIgnoreCase("COMPLETED")) {
                        if(StringUtils.isNotBlank(docToBeUpdated.getClosureRating())) {
                            updatePlan(planDoc, existingAimlPlan, response, existingPlanFilter);
                        } else {
                            response.put(AIMLInsightsConstants.DELETE_PLAN_COMMENTS_REQUIRED,"");
                        }
                    }else {
                        updatePlan(planDoc, existingAimlPlan, response, existingPlanFilter);
                    }
                }else {
                	response.put(AIMLInsightsConstants.CONCURRENT_USER_UPDATES_STATUS,"");
                }
            } else {
                response.put(AIMLInsightsConstants.NO_PLAN_AVAILABLE,"");
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_updateAIMLPlans", e);
            throw new AIMLInsightsException("Exception occurred while updating plan to  DB", e);
        } finally {
            LOGGER.info("TOTAL_TIME_TAKEN_BY_UPDATE_AIML_PLAN={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return response;
    }

    private static Bson checkplanExists(Document planDoc) {
        Bson existingPlanFilter = new Document("planDsid", planDoc.getString("planDsid"))
                .append("planMonth", planDoc.getString("planMonth"))
                .append("planYear", planDoc.getString("planYear"))
                .append("$or", Arrays.asList(
                        new Document("isDeleted", false),
                        new Document("isDeleted", new Document("$exists", false))));
        return existingPlanFilter;
    }

    private void updatePlan(Document planDoc, AIMLPlans existingAimlPlan, Map<String, String> response, Bson existingPlanFilter) {
        Document update = new Document("$set", planDoc);
        UpdateResult result =  mongoCollectionPlans.updateOne(existingPlanFilter, update);
        if(result.getMatchedCount() > 0) {
            response.put(AIMLInsightsConstants.PLAN_UPDATED_SUCCESSFULLY, existingAimlPlan.getId());
        } else {
            response.put(AIMLInsightsConstants.PLAN_UPDATE_FAILED,"");
        }
    }

    public String deleteAIMLPlans(AIMLDeletePlanRequest deleteDetails) throws AIMLInsightsException {
        {
            Instant startTime = Instant.now();
            LOGGER.info("AIMLInsightsPlanRepository : deleteAIMLPlans()");
            AIMLPlans aimlPlan = null;
            String response = null;
            try {
                Bson deletePlanFilter = new Document("_id", new ObjectId(deleteDetails.getId()))
                        .append("$or", Arrays.asList(
                                new Document("isDeleted", false),
                                new Document("isDeleted", new Document("$exists", false))));
                Document document = mongoCollectionPlans.find(deletePlanFilter).first();
                if (document != null) {
                    aimlPlan = MongoRepositoryUtil.getPOJOFromDocument(document, AIMLPlans.class);
                    if (aimlPlan.getPlanState().equalsIgnoreCase(AIMLInsightsConstants.PLAN_STATE_DRAFT)) {
                        DeleteResult result = mongoCollectionPlans.deleteOne(deletePlanFilter);
                        if (result.getDeletedCount() > 0) {
                            response = aimlPlan.getId();
                        } else {
                            response = AIMLInsightsConstants.PLAN_DELETE_FAILED;
                        }
                    } else if (aimlPlan.getPlanState().equalsIgnoreCase(AIMLInsightsConstants.PLAN_STATE_IN_PROGRESS) ||
                            aimlPlan.getPlanState().equalsIgnoreCase(AIMLInsightsConstants.PLAN_STATE_COMPLETED)) {
                        Document softDelete = new Document();
                        softDelete.append("$set", new Document()
                                .append("isDeleted", true)
                                .append("planState", AIMLInsightsConstants.PLAN_STATE_CANCELLED)
                                .append("closureRating", StringEscapeUtils.escapeJava(deleteDetails.getClosureRating()))
                                .append("closureComments", StringEscapeUtils.escapeJava(deleteDetails.getClosureComments())));
                        UpdateResult result = mongoCollectionPlans.updateOne(deletePlanFilter, softDelete);
                        if (result.getModifiedCount() > 0) {
                            response = aimlPlan.getId();
                        } else {
                            response = AIMLInsightsConstants.PLAN_DELETE_FAILED;
                        }
                    }
                } else {
                    response = AIMLInsightsConstants.NO_PLAN_AVAILABLE;
                }
            } catch (AIMLInsightsException | RuntimeException e) {
                LOGGER.error("EXCEPTION_OCCURRED_DELETE_PLAN", e);
                throw new AIMLInsightsException("Exception occurred while deleting plan to  DB", e);
            } catch (Exception e) {
                LOGGER.error("EXCEPTION_OCCURRED_IN_deleteAIMLPlans", e);
                throw new AIMLInsightsException("Exception occurred while deleting plan to  DB", e);
            } finally {
                LOGGER.info("TOTAL_TIME_TAKEN_BY_DELETE_AIML_PLAN={}",
                        Duration.between(startTime, Instant.now()).toMillis());
            }
            return response;
        }
    }

    public List<AIMLSTLViewResponse> fetchPlanAggregate(AIMLSTLViewRequest requestDetails) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchSTLView()");
        AggregateIterable<Document> aggregateDocument = null;
        List<AIMLSTLViewResponse> stlViewList = new ArrayList<>();

        try {
            List<String> managerDsids = (requestDetails.getDsid());

            String inputDate = requestDetails.getMonth();
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate date = LocalDate.parse(inputDate, dateFormatter);
            String month = String.format("%02d", date.getMonthValue());  // Format month to MM
            String year = String.valueOf(date.getYear());

            aggregateDocument = mongoCollectionMaestroUserData.aggregate(Arrays.asList(new Document("$match", 
            	    new Document("managerDsid", 
            	    	    new Document("$in", managerDsids))), 
            	    	    new Document("$lookup", 
            	    	    new Document("from", "aimlMaestroUserData")
            	    	            .append("let", 
            	    	    new Document("localFieldToUse", 
            	    	    new Document("$cond", 
            	    	    new Document("if", 
            	    	    new Document("$eq", Arrays.asList("$delegatedManagerDsid", "")))
            	    	                        .append("then", "$managerDsid")
            	    	                        .append("else", "$delegatedManagerDsid"))))
            	    	            .append("pipeline", Arrays.asList(new Document("$match", 
            	    	                new Document("$expr", 
            	    	                new Document("$and", Arrays.asList(new Document("$eq", Arrays.asList("$$localFieldToUse", "$dsid"))))))))
            	    	            .append("as", "tlUserData")), 
            	    	    new Document("$lookup", 
            	    	    new Document("from", "aimlPlans")
            	    	            .append("let", 
            	    	    new Document("dsid", "$dsid"))
            	    	            .append("pipeline", Arrays.asList(new Document("$match", 
            	    	                new Document("$expr", 
            	    	                new Document("$eq", Arrays.asList("$planDsid", "$$dsid")))
            	    	                        .append("planMonth", month)
            	    	                        .append("planYear", year))))
            	    	            .append("as", "plans")), 
            	    	    new Document("$unwind", 
            	    	    new Document("path", "$tlUserData")
            	    	            .append("preserveNullAndEmptyArrays", true)), 
            	    	    new Document("$project", 
            	    	    new Document("_id", 0L)
            	    	            .append("firstName", "$tlUserData.firstName")
            	    	            .append("lastName", "$tlUserData.lastName")
            	    	            .append("roleId", "$tlUserData.roleId")
            	    	            .append("roleName", "$tlUserData.roleName")
            	    	            .append("siteId", "$tlUserData.siteId")
            	    	            .append("siteName", "$tlUserData.siteName")
            	    	            .append("managerDsid", 1L)
            	    	            .append("dsid", 1L)
            	    	            .append("totalPlans", 
            	    	    new Document("$size", "$plans"))
            	    	            .append("completedPlans", 
            	    	    new Document("$size", 
            	    	    new Document("$filter", 
            	    	    new Document("input", "$plans")
            	    	                        .append("as", "plan")
            	    	                        .append("cond", 
            	    	    new Document("$in", Arrays.asList("$$plan.planState", Arrays.asList("COMPLETED")))))))
            	    	            .append("planTypeCounts", 
            	    	    new Document("aiml_planType_standard_coaching", 
            	    	    new Document("$size", 
            	    	    new Document("$filter", 
            	    	    new Document("input", "$plans")
            	    	                            .append("as", "plan")
            	    	                            .append("cond", 
            	    	    new Document("$eq", Arrays.asList("$$plan.planType", "aiml_planType_standard_coaching"))))))
            	    	                .append("aiml_planType_additional_development", 
            	    	    new Document("$size", 
            	    	    new Document("$filter", 
            	    	    new Document("input", "$plans")
            	    	                            .append("as", "plan")
            	    	                            .append("cond", 
            	    	    new Document("$eq", Arrays.asList("$$plan.planType", "aiml_planType_additional_development"))))))
            	    	                .append("aiml_planType_action_plan", 
            	    	    new Document("$size", 
            	    	    new Document("$filter", 
            	    	    new Document("input", "$plans")
            	    	                            .append("as", "plan")
            	    	                            .append("cond", 
            	    	    new Document("$eq", Arrays.asList("$$plan.planType", "aiml_planType_action_plan"))))))
            	    	                .append("aiml_planType_documented_coaching", 
            	    	    new Document("$size", 
            	    	    new Document("$filter", 
            	    	    new Document("input", "$plans")
            	    	                            .append("as", "plan")
            	    	                            .append("cond", 
            	    	    new Document("$eq", Arrays.asList("$$plan.planType", "aiml_planType_documented_coaching"))))))
            	    	                .append("aiml_planType_no_plan", 
            	    	    new Document("$size", 
            	    	    new Document("$filter", 
            	    	    new Document("input", "$plans")
            	    	                            .append("as", "plan")
            	    	                            .append("cond", 
            	    	    new Document("$eq", Arrays.asList("$$plan.planType", "aiml_planType_no_plan")))))))), 
            	    	    new Document("$group", 
            	    	    new Document("_id", "$managerDsid")
            	    	            .append("totalHeadCount", 
            	    	    new Document("$sum", 
            	    	    new Document("$cond", Arrays.asList(new Document("$ne", Arrays.asList("$dsid", 
            	    	                                new BsonNull())), 1L, 0L))))
            	    	            .append("firstName", 
            	    	    new Document("$first", "$firstName"))
            	    	            .append("lastName", 
            	    	    new Document("$first", "$lastName"))
            	    	            .append("roleId", 
            	    	    new Document("$first", "$roleId"))
            	    	            .append("roleName", 
            	    	    new Document("$first", "$roleName"))
            	    	            .append("siteId", 
            	    	    new Document("$first", "$siteId"))
            	    	            .append("siteName", 
            	    	    new Document("$first", "$siteName"))
            	    	            .append("totalPlans", 
            	    	    new Document("$sum", "$totalPlans"))
            	    	            .append("completedPlans", 
            	    	    new Document("$sum", "$completedPlans"))
            	    	            .append("aiml_planType_standard_coaching", 
            	    	    new Document("$sum", "$planTypeCounts.aiml_planType_standard_coaching"))
            	    	            .append("aiml_planType_additional_development", 
            	    	    new Document("$sum", "$planTypeCounts.aiml_planType_additional_development"))
            	    	            .append("aiml_planType_action_plan", 
            	    	    new Document("$sum", "$planTypeCounts.aiml_planType_action_plan"))
            	    	            .append("aiml_planType_documented_coaching", 
            	    	    new Document("$sum", "$planTypeCounts.aiml_planType_documented_coaching"))
            	    	            .append("aiml_planType_no_plan", 
            	    	    new Document("$sum", "$planTypeCounts.aiml_planType_no_plan"))), 
            	    	    new Document("$addFields", 
            	    	    new Document("planTypes", 
            	    	    new Document("aiml_planType_standard_coaching", "$aiml_planType_standard_coaching")
            	    	                .append("aiml_planType_additional_development", "$aiml_planType_additional_development")
            	    	                .append("aiml_planType_action_plan", "$aiml_planType_action_plan")
            	    	                .append("aiml_planType_documented_coaching", "$aiml_planType_documented_coaching")
            	    	                .append("aiml_planType_no_plan", "$aiml_planType_no_plan"))), 
            	    	    new Document("$project", 
            	    	    new Document("_id", 0L)
            	    	            .append("dsid", "$_id")
            	    	            .append("firstName", 1L)
            	    	            .append("lastName", 1L)
            	    	            .append("roleId", 1L)
            	    	            .append("roleName", 1L)
            	    	            .append("siteId", 1L)
            	    	            .append("siteName", 1L)
            	    	            .append("totalPlans", 1L)
            	    	            .append("completedPlans", 1L)
            	    	            .append("planTypes", 1L)
            	    	            .append("totalHeadCount", 1L))));
            if (aggregateDocument != null) {
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(aggregateDocument, AIMLRepositoryResponse.class,
                        "aimlStlViewResponseList");
                stlViewList = response.getAimlStlViewResponseList();

            }
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_STL_VIEW_PLANS", e);
            throw new AIMLInsightsException("Exception occurred while getting STL plan landing page from DB", e);
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_STL_VIEW_PLANS", e);
            throw new AIMLInsightsException("Exception occurred while getting STL plan landing page from DB", e);
        } finally {
            LOGGER.info("Response STL_VIEW_PLANS={}", stlViewList);
            LOGGER.info("TOTAL_TIME_TAKEN_BY_STL_VIEW_PLANS={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return stlViewList;
    }

    public List<AIMLTaskViewResponse> getAIMLTasks(AIMLTaskViewRequest requestDetails) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : getAIMLTasks()");
        AggregateIterable<Document> aggregateDocument = null;
        List<AIMLTaskViewResponse> aimlTasksList = new ArrayList<>();
        try {
            List<String> dsIdList = requestDetails.getDsid();

            aggregateDocument = mongoCollectionPlans.aggregate(Arrays.asList(new Document("$match",
                            new Document("planDsid",
                                    new Document("$in", dsIdList))
                                    .append("planState", "IN_PROGRESS")),
                    new Document("$unwind",
                            new Document("path", "$tasks")
                                    .append("preserveNullAndEmptyArrays", true)),
                    new Document("$lookup",
                            new Document("from", "aimlMaestroUserData")
                                    .append("localField", "tasks.taskOwner")
                                    .append("foreignField", "dsid")
                                    .append("as", "taskOwner")),
                    new Document("$unwind",
                            new Document("path", "$taskOwner")
                                    .append("preserveNullAndEmptyArrays", true)),
                    new Document("$project",
                            new Document("_id", 0L)
                                    .append("planId",
                                            new Document("$toString", "$_id"))
                                    .append("planMonth", "$planMonth")
                                    .append("planYear", "$planYear")
                                    .append("planState", "$planState")
                                    .append("planStartDate", "$planStartDate")
                                    .append("planEndDate", "$planEndDate")
                                    .append("publishedDateTime", "$publishedDateTime")
                                    .append("planType", "$planType")
                                    .append("taskId", "$tasks.id")
                                    .append("taskCode", "$tasks.taskCode")
                                    .append("taskDescription", "$tasks.taskDescription")
                                    .append("taskStatus", "$tasks.taskStatus")
                                    .append("taskOwnerDsid", "$tasks.taskOwner")
                                    .append("taskDueDate", "$tasks.taskDueDate")
                                    .append("taskOwnerFirstName", "$taskOwner.firstName")
                                    .append("taskOwnerLastName", "$taskOwner.lastName"))));
            if (aggregateDocument != null) {
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(aggregateDocument, AIMLRepositoryResponse.class,
                        "aimlTasksResponseList");
                aimlTasksList = response.getAimlTasksResponseList();

            }
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_GET_AIML_TASKS", e);
            throw new AIMLInsightsException("Exception occurred while fetching AIML tasks from DB", e);
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_GET_AIML_TASKS", e);
            throw new AIMLInsightsException("Exception occurred while fetching AIML tasks from DB", e);
        } finally {
            LOGGER.info("Response GET_AIML_TASKS={}", aimlTasksList);
            LOGGER.info("TOTAL_TIME_TAKEN_BY_GET_AIML_TASKS={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return aimlTasksList;
    }

    public List<AIMLSTLTaskViewResponse> fetchTaskAggregate(AIMLSTLViewRequest requestDetails) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchTaskAggregate()");
        AggregateIterable<Document> aggregateDocument = null;
        List<AIMLSTLTaskViewResponse> stlViewList = new ArrayList<>();

        try {
            List<String> managerDsids = (requestDetails.getDsid());

            String inputDate = requestDetails.getMonth();
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate date = LocalDate.parse(inputDate, dateFormatter);
            String month = String.format("%02d", date.getMonthValue());  // Format month to MM
            String year = String.valueOf(date.getYear());

            aggregateDocument = mongoCollectionMaestroUserData.aggregate(Arrays.asList(new Document("$match", 
            	    new Document("dsid", 
            	    	    new Document("$in", managerDsids))), 
            	    	    new Document("$lookup", 
            	    	    new Document("from", "aimlMaestroUserData")
            	    	            .append("localField", "dsid")
            	    	            .append("foreignField", "managerDsid")
            	    	            .append("as", "tlUserData")), 
            	    	    new Document("$project", 
            	    	    new Document("tlDsid", "$dsid")
            	    	            .append("tlFirstName", "$firstName")
            	    	            .append("tlLastName", "$lastName")
            	    	            .append("tlSiteId", "$siteId")
            	    	            .append("tlSiteName", "$siteName")
            	    	            .append("tlRoleId", "$roleId")
            	    	            .append("tlRoleName", "$roleName")
            	    	            .append("totalHeadCount", 
            	    	    new Document("$size", "$tlUserData"))
            	    	            .append("isTl", 
            	    	    new Document("$cond", 
            	    	    new Document("if", 
            	    	    new Document("$gt", Arrays.asList(new Document("$size", "$tlUserData"), 0L)))
            	    	                    .append("then", true)
            	    	                    .append("else", false)))
            	    	            .append("aDsid", 
            	    	    new Document("$cond", 
            	    	    new Document("if", 
            	    	    new Document("$lte", Arrays.asList(new Document("$size", "$tlUserData"), 0L)))
            	    	                    .append("then", Arrays.asList("$dsid"))
            	    	                    .append("else", "$tlUserData.dsid")))), 
            	    	    new Document("$unwind", 
            	    	    new Document("path", "$aDsid")
            	    	            .append("preserveNullAndEmptyArrays", true)), 
            	    	    new Document("$lookup", 
            	    	    new Document("from", "aimlPlans")
            	    	            .append("let", 
            	    	    new Document("dsid", "$aDsid"))
            	    	            .append("pipeline", Arrays.asList(new Document("$match", 
            	    	                new Document("$expr", 
            	    	                new Document("$eq", Arrays.asList("$planDsid", "$$dsid"))))))
            	    	            .append("as", "plans")), 
            	    	    new Document("$unwind", 
            	    	    new Document("path", "$plans")
            	    	            .append("preserveNullAndEmptyArrays", true)), 
            	    	    new Document("$match", 
            	    	    new Document("plans.planState", "IN_PROGRESS")), 
            	    	    new Document("$unwind", 
            	    	    new Document("path", "$plans.tasks")
            	    	            .append("preserveNullAndEmptyArrays", true)), 
            	    	    new Document("$addFields", 
            	    	    new Document("endDateISO", 
            	    	    new Document("$dateFromString", 
            	    	    new Document("dateString", "$plans.tasks.taskDueDate")))), 
            	    	    new Document("$addFields", 
            	    	    new Document("dateDifference", 
            	    	    new Document("$dateDiff", 
            	    	    new Document("startDate", 
            	    	    new java.util.Date())
            	    	                    .append("endDate", "$endDateISO")
            	    	                    .append("unit", "day")))), 
            	    	    new Document("$addFields", 
            	    	    new Document("overdue", 
            	    	    new Document("$cond", Arrays.asList(new Document("$and", Arrays.asList(new Document("$lte", Arrays.asList("$dateDifference", -1L)), 
            	    	                            new Document("$eq", Arrays.asList("$plans.tasks.taskStatus", "IN_PROGRESS")))), 1L, 0L)))
            	    	            .append("dueSoon", 
            	    	    new Document("$cond", Arrays.asList(new Document("$and", Arrays.asList(new Document("$gt", Arrays.asList("$dateDifference", -1L)), 
            	    	                            new Document("$lte", Arrays.asList("$dateDifference", 10L)), 
            	    	                            new Document("$eq", Arrays.asList("$plans.tasks.taskStatus", "IN_PROGRESS")))), 1L, 0L)))
            	    	            .append("closed", 
            	    	    new Document("$cond", Arrays.asList(new Document("$eq", Arrays.asList("$plans.tasks.taskStatus", "COMPLETED")), 1L, 0L)))), 
            	    	    new Document("$project", 
            	    	    new Document("_id", 0L)
            	    	            .append("firstName", "$tlFirstName")
            	    	            .append("lastName", "$tlLastName")
            	    	            .append("roleId", "$tlRoleId")
            	    	            .append("roleName", "$tlRoleName")
            	    	            .append("siteId", "$tlSiteId")
            	    	            .append("siteName", "$tlSiteName")
            	    	            .append("managerDsid", "$tlDsid")
            	    	            .append("roleName", "$tlRoleName")
            	    	            .append("totalHeadCount", "$totalHeadCount")
            	    	            .append("overdue", 1L)
            	    	            .append("dueSoon", 1L)
            	    	            .append("closed", 1L)), 
            	    	    new Document("$group", 
            	    	    new Document("_id", "$managerDsid")
            	    	            .append("totalHeadCount", 
            	    	    new Document("$first", "$totalHeadCount"))
            	    	            .append("firstName", 
            	    	    new Document("$first", "$firstName"))
            	    	            .append("lastName", 
            	    	    new Document("$first", "$lastName"))
            	    	            .append("roleId", 
            	    	    new Document("$first", "$roleId"))
            	    	            .append("siteId", 
            	    	    new Document("$first", "$siteId"))
            	    	            .append("siteName", 
            	    	    new Document("$first", "$siteName"))
            	    	            .append("overDue", 
            	    	    new Document("$sum", "$overdue"))
            	    	            .append("dueSoon", 
            	    	    new Document("$sum", "$dueSoon"))
            	    	            .append("closed", 
            	    	    new Document("$sum", "$closed"))
            	    	            .append("dsid", 
            	    	    new Document("$first", "$managerDsid"))
            	    	            .append("roleName", 
            	    	    new Document("$first", "$roleName")))));
            if (aggregateDocument != null) {
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(aggregateDocument, AIMLRepositoryResponse.class,
                        "aimlTaskAggregateResponseList");
                stlViewList = response.getAimlTaskAggregateResponseList();

            }
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_TASK_AGGREGATE", e);
            throw new AIMLInsightsException("Exception occurred while getting STL task aggregate page from DB", e);
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_TASK_AGGREGATE", e);
            throw new AIMLInsightsException("Exception occurred while getting STL task aggregate page from DB", e);
        } finally {
            LOGGER.info("Response TASK_AGGREGATE={}", stlViewList);
            LOGGER.info("TOTAL_TIME_TAKEN_BY_TASK_AGGREGATE={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return stlViewList;

    }

    public Map<String, String> updateTask(AIMLTaskUpdate requestDetails) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : updateTask()");
        Map<String, String> responseMap = new HashMap<>();
        AIMLPlans existingAimlPlan = new AIMLPlans();
        try {
            LocalDate taskDueDate = parseDates(requestDetails.getTaskDueDate());
            Bson planFilter = new Document("_id", new ObjectId(requestDetails.getPlanId()))
                    .append("planState", AIMLInsightsConstants.PLAN_STATE_IN_PROGRESS);
            Document existingPlan = mongoCollectionPlans.find(planFilter).first();
            existingAimlPlan = MongoRepositoryUtil.getPOJOFromDocument(existingPlan, AIMLPlans.class);
            if (existingAimlPlan != null) {
                if (taskDueDate.isBefore(parseDates(existingAimlPlan.getPlanStartDate()))
                        || taskDueDate.isAfter(parseDates(existingAimlPlan.getPlanEndDate()))) {
                    responseMap.put(AIMLInsightsConstants.INVALID_TASK_DUEDATE,"");
                } else {
                    Document update = new Document("$set", new Document("tasks.$[elem].taskStatus", requestDetails.getTaskStatus())
                            .append("tasks.$[elem].taskDueDate", requestDetails.getTaskDueDate()));
                    Document filter = new Document("_id", new ObjectId(requestDetails.getPlanId()));
                    List<Document> arrayFilters = List.of(new Document("elem.id", requestDetails.getTaskId()));
                    UpdateResult result = mongoCollectionPlans.updateOne(filter, update, new UpdateOptions().arrayFilters(arrayFilters));
                    if (result.getMatchedCount() > 0) {
                        responseMap.put(AIMLInsightsConstants.TASK_UPDATED_SUCCESSFULLY, requestDetails.getPlanId());
                    } else {
                        responseMap.put(AIMLInsightsConstants.TASK_UPDATED_FAILED, "");
                    }
                }
            }else {
                responseMap.put(AIMLInsightsConstants.NO_PLAN_AVAILABLE, "");
            }
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_UPDATE_TASK", e);
            throw new AIMLInsightsException("Exception occurred while updating task", e);
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_UPDATE_TASK", e);
            throw new AIMLInsightsException("Exception occurred while updating task", e);
        } finally {
            LOGGER.info("TOTAL_TIME_TAKEN_BY_UPDATE_TASK={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseMap;
    }

    private LocalDate parseDates(String date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDate formattedDate = LocalDate.parse(date, formatter);
        return formattedDate;
    }
    
    public AIMLEmailResponse fetchAIMLPlanAndUserData(String planId) throws EmailNotificationException {
  		Instant startTime = Instant.now();
  		LOGGER.info("AIMLEmailViewResponse : fetchAIMLPlanAndUserData()");
  		AIMLEmailResponse response = null;
  		try {
  			AggregateIterable<Document> document = mongoCollectionPlans.aggregate(Arrays.asList(new Document("$match", 
  				    new Document("_id", 
  				    	    new ObjectId(planId))), 
  				    	    new Document("$lookup", 
  				    	    new Document("from", "aimlMaestroUserData")
  				    	            .append("localField", "planDsid")
  				    	            .append("foreignField", "dsid")
  				    	            .append("as", "userDetails")), 
  				    	    new Document("$lookup", 
  				    	    new Document("from", "aimlMaestroUserData")
  				    	            .append("localField", "createdBy")
  				    	            .append("foreignField", "dsid")
  				    	            .append("as", "planCreatedUser")), 
  				    	    new Document("$project", 
  				    	    new Document("planState", 1L)
  				    	            .append("planType", 1L)
  				    	            .append("planYear", 1L)
  				    	            .append("planEndDate", 1L)
  				    	            .append("planMonth", 1L)
  				    	            .append("planDsid", 1L)
  				    	            .append("planStartDate", 1L)
  				    	            .append("behaviors", 1L)
  				    	            .append("planNotes", 1L)
  				    	            .append("tasks", 1L)
  				    	            .append("competencyFocus", 1L)
  				    	            .append("focusAreaMetrics", 1L)
  				    	            .append("createdBy", 1L)
  				    	            .append("userDetails", 
  				    	    new Document("dsid", 1L)
  				    	                .append("lastName", 1L)
  				    	                .append("firstName", 1L)
  				    	                .append("roleId", 1L)
  				    	                .append("emailAddress", 1L)
  				    	                .append("roleName", 1L)
  				    	                .append("l1Locale", 1L)
  				    	                .append("l2Locale", 1L)
  				    	                .append("l3Locale", 1L)
  				    	                .append("l4Locale", 1L)
  				    	                .append("l5Locale", 1L)
  				    	                .append("businessUnitId", 1L))
  				    	            .append("planCreatedBy", 
  				    	    new Document("$arrayElemAt", Arrays.asList("$planCreatedUser", 0L)))), 
  				    	    new Document("$lookup", 
  				    	    new Document("from", "aimlMaestroUserData")
  				    	            .append("localField", "tasks.taskOwner")
  				    	            .append("foreignField", "dsid")
  				    	            .append("as", "taskOwnerDetails")), 
  				    	    new Document("$project", 
  				    	    new Document("planState", 1L)
  				    	            .append("planType", 1L)
  				    	            .append("planYear", 1L)
  				    	            .append("planEndDate", 1L)
  				    	            .append("planMonth", 1L)
  				    	            .append("planDsid", 1L)
  				    	            .append("planStartDate", 1L)
  				    	            .append("behaviors", 1L)
  				    	            .append("tasks", 1L)
  				    	            .append("planNotes", 1L)
  				    	            .append("competencyFocus", 1L)
  				    	            .append("focusAreaMetrics", 1L)
  				    	            .append("userDetails", 1L)
  				    	            .append("roleName", 1L)
  				    	            .append("taskOwnerDetails", 1L)
  				    	            .append("createdBy", 1L)
  				    	            .append("createdByFirstName", "$planCreatedBy.firstName")
  				    	            .append("createdByLastName", "$planCreatedBy.lastName")
  				    	            .append("createdByEmail", "$planCreatedBy.emailAddress"))));
  			if (document != null) {
  				response = MongoRepositoryUtil
  						.getPOJOFromDocument(document, AIMLRepositoryResponse.class, "aimlEmailResponse")
  						.getAimlEmailResponse().get(0);
  			}
  		} catch (Exception e) {
  			LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_AIMLPlan", e);
  			throw new EmailNotificationException(
  					"Exception occurred while fetching AIMLPlans and AimlMaestroUserData from DB", e);
  		} finally {
  			LOGGER.info("Response fetchAIMLPlan={}", response);
  			LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchAIMLPlan={}",
  					Duration.between(startTime, Instant.now()).toMillis());
  		}
  		return response;
  	}
    public List<AIMLUserDirectsDelegatesData> fetchDelegationUserHierarchy(String dsid) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchDelegationUserHierarchy()");
        AggregateIterable<Document> aggregateDocument = null;
        List<AIMLUserDirectsDelegatesData> delegationUserHierarchyList = new ArrayList<>();
        try {
            aggregateDocument = mongoCollectionMaestroUserData.aggregate(Arrays.asList(new Document("$match",
                            new Document("dsid", dsid)),
                    new Document("$lookup",
                            new Document("from", "aimlMaestroUserData")
                                    .append("localField", "dsid")
                                    .append("foreignField", "managerDsid")
                                    .append("as", "directs")),
                    new Document("$lookup",
                            new Document("from", "aimlMaestroUserData")
                                    .append("localField", "dsid")
                                    .append("foreignField", "delegatedManagerDsid")
                                    .append("as", "delegatedUserData"))));
            if (aggregateDocument != null) {
                AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(aggregateDocument, AIMLRepositoryResponse.class,
                        "delegationUserHierarchyList");
                delegationUserHierarchyList = response.getDelegationUserHierarchyList();
            }
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_fetchDelegationUserHierarchy", e);
            throw new AIMLInsightsException("Exception occurred while getting delegationUserHierarchy from DB", e);
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_TASK_AGGREGATE", e);
            throw new AIMLInsightsException("Exception occurred while getting delegationUserHierarchy from DB", e);
        } finally {
            LOGGER.info("Response delegationUserHierarchy={}", delegationUserHierarchyList);
            LOGGER.info("TOTAL_TIME_TAKEN_BY_delegationUserHierarchy={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return delegationUserHierarchyList;
    }

    public List<AIMLUserData> fetchUserDataList(List<String> managerIdsList) throws AIMLInsightsException {
        Instant startTime = Instant.now();
        LOGGER.info("AIMLInsightsPlanRepository : fetchUserDataList()");
        List<AIMLUserData> userDataList = new ArrayList<>();
        try {
            LOGGER.info("AIMLInsightsPlanRepository : fetchUserDataList()");
            try {

                Bson userDataQuery = new Document("dsid", new Document("$in", managerIdsList));
                FindIterable<Document> document = mongoCollectionMaestroUserData.find(userDataQuery);
                if (document != null) {
                    AIMLRepositoryResponse response = MongoRepositoryUtil.getPOJOFromDocument(document, AIMLRepositoryResponse.class,
                            "aimlUserDataList");
                    userDataList = response.getAimlUserDataList();
                }
            } catch (Exception e) {
                LOGGER.error("EXCEPTION_OCCURRED_IN_DB_FETCHING_fetchUserDataList", e);
                throw new AIMLInsightsException("Exception occurred while fetching fetchUserDataList from DB", e);
            } finally {
                LOGGER.info("Response fetchUserDataList={}", userDataList);
                LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchUserDataList={}",
                        Duration.between(startTime, Instant.now()).toMillis());
            }
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_IN_DB_fetchUserDataList", e);
            throw new AIMLInsightsException("Exception occurred while fetchUserDataList from DB", e);
        } finally {
            LOGGER.info("Response fetchUserDataList={}", userDataList);
            LOGGER.info("MONGO_TOTAL_TIME_TAKEN_fetchUserDataList={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return userDataList;
    }

}
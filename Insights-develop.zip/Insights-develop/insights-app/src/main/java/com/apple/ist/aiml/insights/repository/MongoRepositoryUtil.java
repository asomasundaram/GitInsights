package com.apple.ist.aiml.insights.repository;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.ws.rs.core.Response;

import com.apple.ist.aiml.insights.bean.AIMLInsightsServiceStatus;
import com.apple.ist.aiml.insights.constants.AIMLInsightsConstants;
import com.apple.ist.aiml.insights.exception.AIMLInsightsException;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;

public final class MongoRepositoryUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(MongoRepositoryUtil.class);

    private static final ObjectMapper objectMapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    private MongoRepositoryUtil() {

    }

    /**
     * This method is used to get Map<String, Object> from the document along with
     * the timezone.
     * 
     * @param doc      Holds the document retruned by the monogo client.
     * 
     * @return Map<String, Object>
     */
    private static Map<String, Object> getMapFromDocumentWithDateTime(final Document doc) {
        LOGGER.info("DataManagerUtil | getMapFromDocumentWithDateTime ");
        Map<String, Object> documentMap = new HashMap<>();
        Set<Entry<String, Object>> keyValueSet = doc.entrySet();
        try {
            keyValueSet.forEach(entry -> {
                String key = entry.getKey();
                Object value = entry.getValue();
                if (value instanceof Document) {
                    documentMap.put(key, getMapFromDocumentWithDateTime((Document) value));
                } else {
                    documentMap.put(key, value);
                }
            });
        } catch (Exception e) {
            LOGGER.error("Exception while generating map from document with timezone", e);
        }
        return documentMap;
    }

    public static Timestamp getDateAndTime() {
        return new Timestamp(System.currentTimeMillis());
    }

    public static <T> T getPOJOFromDocument(final FindIterable<Document> doc, final Class<? extends T> pojoType,
            final String jsonKey) throws AIMLInsightsException {
        LOGGER.info("DataManagerUtil | getPOJOFromDocument with jsonkey");
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = null;
        try {
            for (Document document : doc) {
                jsonObject = populateJsonObject(document);

                jsonArray.put(jsonObject);
            }
            jsonObject = new JSONObject();
            jsonObject.put(jsonKey, jsonArray);
            return objectMapper.readValue(jsonObject.toString(), pojoType);

        } catch (Exception e) {
            throw new AIMLInsightsException("Exception in getPOJOFromDocument with jsonkey", e);
        }
    }

    /**
     * This method is used to get the POJO from the mongo document.
     * 
     * @param doc      Holds the document retruned by the monogo client.
     * 
     * @param pojoType The POJO to which the valued returned in document should be
     *                 mapped
     * 
     * @param timeZone Holds the timezone to which the time should be converted
     * 
     * @return <T> T POJO
     */
    public static <T> T getPOJOFromDocument(final Document document, final Class<? extends T> pojoType)
            throws AIMLInsightsException {
        LOGGER.info("DataManagerUtil | getPOJOFromDocument");
        try {
            JSONObject jsonObject = populateJsonObject(document);
            return objectMapper.readValue(jsonObject.toString(), pojoType);
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception in DataManagerUtil - getPOJOFromDocument", e);
        }
    }

    private static JSONObject populateJsonObject(Document document) throws JsonProcessingException, JSONException {
        String response = null;
        Map<String, Object> documentMap = getMapFromDocumentWithDateTime(document);
        Object docId = documentMap.get(AIMLInsightsConstants.OBJECT_ID);
        documentMap.remove(AIMLInsightsConstants.OBJECT_ID);
        response = objectMapper.writeValueAsString(documentMap);
        JSONObject jsonObject = new JSONObject(response);
        jsonObject.put(AIMLInsightsConstants.ID, docId);
        return jsonObject;
    }

    /**
     * This method is to generate random number.
     * 
     * @param size random number with size number of digits.
     * @return returns random number.
     */
    public static String getRandomNumeric(int size) {
        var randomNumeric = RandomStringUtils.randomNumeric(size);
        var counter = 10;
        while (ObjectUtils.isEmpty(randomNumeric) && counter-- > 0) {
            randomNumeric = RandomStringUtils.randomNumeric(size);
        }
        LOGGER.info("Generated randomNumeric={}", randomNumeric);
        return randomNumeric;
    }

    /**
     * This method is to extract status from the response object.
     * 
     * @param response input response object.
     * @return returns the status.
     */
    public static String getResponseStatus(Response response) {
        StringBuilder status = new StringBuilder();
        if (null != response && response.getEntity() instanceof AIMLInsightsServiceStatus<?>) {
            AIMLInsightsServiceStatus<?> dataManagerServiceStatus = (AIMLInsightsServiceStatus<?>) response.getEntity();
            if (null != dataManagerServiceStatus) {
                status.append(AIMLInsightsConstants.STATUS).append(AIMLInsightsConstants.EQUALS_TO)
                        .append(dataManagerServiceStatus.getStatus()).append(AIMLInsightsConstants.COMMA);
                status.append(AIMLInsightsConstants.STATUS_CODE).append(AIMLInsightsConstants.EQUALS_TO)
                        .append(dataManagerServiceStatus.getStatusCode()).append(AIMLInsightsConstants.COMMA);
                status.append(AIMLInsightsConstants.ERROR_MESSAGE).append(AIMLInsightsConstants.EQUALS_TO)
                        .append(dataManagerServiceStatus.getErrorMessage());
            }
        }
        return status.toString();
    }

    public static <T> T getPOJOFromDocument(final AggregateIterable<Document> doc, final Class<? extends T> pojoType,
            final String jsonKey) throws AIMLInsightsException {
        LOGGER.info("DataManagerUtil | getPOJOFromDocument ");
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = null;
        try {
            for (Document document : doc) {
                jsonObject = populateJsonObject(document);

                jsonArray.put(jsonObject);
            }
            jsonObject = new JSONObject();
            jsonObject.put(jsonKey, jsonArray);
            return objectMapper.readValue(jsonObject.toString(), pojoType);
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception in getPOJOFromDocument", e);
        }
    }

    public static <T> T getPOJOFromDocumentExcludeOuterObjectId(final AggregateIterable<Document> doc,
            final Class<? extends T> pojoType, final String jsonKey) throws AIMLInsightsException {
        LOGGER.info("DataManagerUtil | getPOJOFromDocument ");
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = null;
        try {
            for (Document document : doc) {
                document = (Document) document.get("_id");
                jsonObject = populateJsonObject((Document) document.get("_id"));
                jsonArray.put(jsonObject);
            }
            jsonObject = new JSONObject();
            jsonObject.put(jsonKey, jsonArray);
            return objectMapper.readValue(jsonObject.toString(), pojoType);
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception in getPOJOFromDocument", e);
        }
    }

    public static Map<String, String> getCodesFromDocument(final FindIterable<Document> document)
            throws AIMLInsightsException {
        LOGGER.info("PermissionManagerUtil | getCodesFromDocument ");
        Map<String, String> map = new HashMap<>();
        try {
            for (Document doc : document) {
                map.put(doc.getString("typeName"), doc.getString("typeCode"));
            }
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception in getCodesFromDocument", e);
        }
        return map;
    }

    public static <T> T getPOJOFromDocument(final List<Document> doc, final Class<? extends T> pojoType,
                                            final String jsonKey) throws AIMLInsightsException {
        LOGGER.info("DataManagerUtil | getPOJOFromDocument ");
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = null;
        try {
            for (Document document : doc) {
                jsonObject = populateJsonObject(document);

                jsonArray.put(jsonObject);
            }
            jsonObject = new JSONObject();
            jsonObject.put(jsonKey, jsonArray);
            return objectMapper.readValue(jsonObject.toString(), pojoType);
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception in getPOJOFromDocument", e);
        }
    }

}

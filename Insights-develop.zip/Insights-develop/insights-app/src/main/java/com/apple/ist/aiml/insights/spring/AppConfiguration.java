/*
 * Copyright 2023 Apple, Inc
 * Apple Internal Use Only
 */


package com.apple.ist.aiml.insights.spring;


import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
@Configuration
@EnableConfigurationProperties(AppProperties.class)
public class AppConfiguration {
}

package com.apple.ist.aiml.insights.bean;

import java.util.List;
import java.util.Map;

public class AppTranslatorResponse {

    private List<AppTranslatorMessages> supportedLanguages;

    public List<AppTranslatorMessages> getSupportedLanguages() {
        return supportedLanguages;
    }

    public void setSupportedLanguages(List<AppTranslatorMessages> supportedLanguages) {
        this.supportedLanguages = supportedLanguages;
    }
}
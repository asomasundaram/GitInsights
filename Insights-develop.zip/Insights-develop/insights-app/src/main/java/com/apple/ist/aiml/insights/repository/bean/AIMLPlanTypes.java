package com.apple.ist.aiml.insights.repository.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AIMLPlanTypes implements Serializable {

    private String id;
    private String businessUnitId;
    private String planTypeKey;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBusinessUnitId() {
        return businessUnitId;
    }

    public void setBusinessUnitId(String businessUnitId) {
        this.businessUnitId = businessUnitId;
    }

    public String getPlanTypeKey() {
        return planTypeKey;
    }

    public void setPlanTypeKey(String planTypeKey) {
        this.planTypeKey = planTypeKey;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }

}

package com.apple.ist.aiml.insights.repository.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AIMLFocusAreaMetrics implements Serializable {

    private String id;
    private String businessUnitId;
    private String focusArea;
    private List<String> focusAreaMetrics;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBusinessUnitId() {
        return businessUnitId;
    }

    public void setBusinessUnitId(String businessUnitId) {
        this.businessUnitId = businessUnitId;
    }

    public String getFocusArea() {
        return focusArea;
    }

    public void setFocusArea(String focusArea) {
        this.focusArea = focusArea;
    }

    public List<String> getFocusAreaMetrics() {
        return focusAreaMetrics;
    }

    public void setFocusAreaMetrics(List<String> focusAreaMetrics) {
        this.focusAreaMetrics = focusAreaMetrics;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }

}

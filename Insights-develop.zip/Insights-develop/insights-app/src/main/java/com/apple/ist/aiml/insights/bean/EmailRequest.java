package com.apple.ist.aiml.insights.bean;

import java.io.Serializable;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.apple.ist.aiml.insights.repository.bean.AIMLEmailResponse;
import com.apple.ist.aiml.insights.repository.bean.AIMLPlans;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailRequest implements Serializable{
	 private static final long serialVersionUID = 1L;
	private String subscriptionid;
	    private String templateid;
	    private String subject;
	    private String[] to;
	    private FromEmail from;
	    private AIMLEmailResponse data;

	    public String getSubscriptionid() {
	        return subscriptionid;
	    }

	    public void setSubscriptionid(final String subscriptionid) {
	        this.subscriptionid = subscriptionid;
	    }

	    public String getTemplateid() {
	        return templateid;
	    }

	    public void setTemplateid(final String templateid) {
	        this.templateid = templateid;
	    }

	    public String getSubject() {
	        return subject;
	    }

	    public void setSubject(final String subject) {
	        this.subject = subject;
	    }

	    public String[] getTo() {
	        return to;
	    }

	    public void setTo(final String[] to) {
	        this.to = to;
	    }

	    public FromEmail getFrom() {
	        return from;
	    }

	    public void setFrom(final FromEmail from) {
	        this.from = from;
	    }

	    public AIMLEmailResponse getData() {
	        return data;
	    }

	    public void setData(final AIMLEmailResponse data) {
	        this.data = data;
	    }

	    @Override
	    public String toString() {
	        return "UserEmailRequest :" + ReflectionToStringBuilder.toString(this);
	    }
	}

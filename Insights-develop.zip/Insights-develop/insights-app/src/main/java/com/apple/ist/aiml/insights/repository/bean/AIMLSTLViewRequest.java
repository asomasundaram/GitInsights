package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;
import java.util.List;

public class AIMLSTLViewRequest implements Serializable {

    private List<String> dsid;
    private String month;

    public List<String> getDsid() {
        return dsid;
    }

    public void setDsid(List<String> dsid) {
        this.dsid = dsid;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }
}

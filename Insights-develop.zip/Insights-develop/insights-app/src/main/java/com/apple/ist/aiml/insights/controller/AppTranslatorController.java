package com.apple.ist.aiml.insights.controller;

import com.apple.ist.aiml.insights.exception.AIMLInsightsException;
import com.apple.ist.aiml.insights.handler.AIMLInsightsResponseHandler;
import com.apple.ist.aiml.insights.service.impl.AppTranslatorServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Singleton;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.time.Duration;
import java.time.Instant;

@RestController
@Singleton
public class AppTranslatorController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AppTranslatorController.class);

    @Autowired
    private AppTranslatorServiceImpl appTranslatorService;

    @Autowired
    private AIMLInsightsResponseHandler responseHandler;

    /**
     * API to fetch translation text from AppTranslator
     *
     * @param locale
     * @return
     */
    @RequestMapping(value = "/api/v1/aiml/messages/{locale}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity fetchAppTranslatorMessages(@PathVariable final String locale) {
        Instant startTime = Instant.now();
        LOGGER.info("AppTranslator Started");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = appTranslatorService.fetchAppTransalatorMessages(locale);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_INIT_CALL", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("INIT_CALL_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_INIT_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }
}


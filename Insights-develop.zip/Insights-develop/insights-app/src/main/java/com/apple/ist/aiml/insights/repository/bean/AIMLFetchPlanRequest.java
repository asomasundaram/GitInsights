package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;
import java.util.List;

public class AIMLFetchPlanRequest implements Serializable {

    private List<String> createdFor;
    private Boolean includeDrafts;
    private Boolean includeCurrent;
    private int limit;
    private String startDate;
    private String endDate;

    public List<String> getCreatedFor() {
        return createdFor;
    }

    public void setCreatedFor(List<String> createdFor) {
        this.createdFor = createdFor;
    }

    public Boolean getIncludeDrafts() {
        return includeDrafts;
    }

    public void setIncludeDrafts(Boolean includeDrafts) {
        this.includeDrafts = includeDrafts;
    }

    public Boolean getIncludeCurrent() {
        return includeCurrent;
    }

    public void setIncludeCurrent(Boolean includeCurrent) {
        this.includeCurrent = includeCurrent;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}

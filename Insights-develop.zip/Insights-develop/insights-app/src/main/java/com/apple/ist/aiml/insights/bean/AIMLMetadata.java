package com.apple.ist.aiml.insights.bean;

import com.apple.ist.aiml.insights.repository.bean.*;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class AIMLMetadata implements Serializable {

    private String environment;
    private List<String> planTypes;
    private List<AIMLFocusAreaMetrics> focusMetrics;
    private List<AIMLBehaviors> behaviors;
    private List<AIMLTasks> tasks;
    private List<AIMLCompetencyFocusMetadata> competencyFocus;
    private AIMLUserData userData;

    public List<String> getPlanTypes() {
        return planTypes;
    }

    public void setPlanTypes(List<String> planTypes) {
        this.planTypes = planTypes;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public List<AIMLFocusAreaMetrics> getFocusMetrics() {
        return focusMetrics;
    }

    public void setFocusMetrics(List<AIMLFocusAreaMetrics> focusMetrics) {
        this.focusMetrics = focusMetrics;
    }

    public List<AIMLBehaviors> getBehaviors() {
        return behaviors;
    }

    public void setBehaviors(List<AIMLBehaviors> behaviors) {
        this.behaviors = behaviors;
    }

    public List<AIMLTasks> getTasks() {
        return tasks;
    }

    public void setTasks(List<AIMLTasks> tasks) {
        this.tasks = tasks;
    }

    public List<AIMLCompetencyFocusMetadata> getCompetencyFocus() {
        return competencyFocus;
    }

    public void setCompetencyFocus(List<AIMLCompetencyFocusMetadata> competencyFocus) {
        this.competencyFocus = competencyFocus;
    }

    public AIMLUserData getUserData() {
        return userData;
    }

    public void setUserData(AIMLUserData userData) {
        this.userData = userData;
    }
}

package com.apple.ist.aiml.insights.repository.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AIMLCompetencyFocusMetadata implements Serializable {

    private String id;
    private String factorName;
    private List<AIMLCompetencyMetadata> categoryList;
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFactorName() {
        return factorName;
    }

    public void setFactorName(String factorName) {
        this.factorName = factorName;
    }

    public List<AIMLCompetencyMetadata> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(List<AIMLCompetencyMetadata> categoryList) {
        this.categoryList = categoryList;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }

}

package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;

public class AIMLSTLTaskViewResponse implements Serializable {
    private String dsid;
    private String firstName;
    private String lastName;
    private String roleId;
    private String roleName;
    private String siteId;
    private String siteName;
    private String overDue;
    private String dueSoon;
    private String closed;
    private String totalHeadCount;
   
	public String getDsid() {
        return dsid;
    }
    public void setDsid(String dsid) {
        this.dsid = dsid;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getOverDue() {
        return overDue;
    }

    public void setOverDue(String overDue) {
        this.overDue = overDue;
    }

    public String getDueSoon() {
        return dueSoon;
    }

    public void setDueSoon(String dueSoon) {
        this.dueSoon = dueSoon;
    }

    public String getClosed() {
        return closed;
    }

    public void setClosed(String closed) {
        this.closed = closed;
    }
    
    public String getTotalHeadCount() {
		return totalHeadCount;
	}
    
	public void setTotalHeadCount(String totalHeadCount) {
		this.totalHeadCount = totalHeadCount;
	}
}

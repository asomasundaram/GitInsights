package com.apple.ist.aiml.insights.controller;

import com.apple.ist.aiml.insights.exception.AIMLInsightsException;
import com.apple.ist.aiml.insights.handler.AIMLInsightsResponseHandler;
import com.apple.ist.aiml.insights.repository.bean.*;
import com.apple.ist.aiml.insights.service.AIMLInsightsService;
import com.apple.ist.aiml.insights.spring.AppProperties;
import com.apple.ist.aiml.insights.utils.InsightsUtility;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebSession;

import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;

@Controller
public class InsightsAppController {

    private static final Logger LOGGER = LoggerFactory.getLogger(InsightsAppController.class);

    @Autowired
    private AppProperties properties;

    @Autowired
    private AIMLInsightsService aimlService;

    @Autowired
    private AIMLInsightsResponseHandler responseHandler;

    @Autowired
    private InsightsUtility insightsUtility;

    @RequestMapping(value = "/application", method = RequestMethod.GET)
    public String loadAIMLInsightsApplication(
            @QueryParam("dsid") final String dsid,
            @QueryParam("roleId") final String roleId,
            @QueryParam("locale") final String locale,
            @Context WebSession session) {
        LOGGER.info("API_Name=application , METHOD=GET, DSID={} ROLE_ID={} LOCALE={}", dsid, roleId, locale);
        Instant startTime = Instant.now();
        String returnView = "error";
        try {
            // Persist request param in WebSession
            insightsUtility.persistRequestParamsInSession(session, dsid, roleId, locale);
            returnView = "index";
        } catch (Exception e) {
            LOGGER.error("EXCEPTION_OCCURRED_PAGE_LOAD", e);
        } finally {
            LOGGER.info("TOTAL_TIME_PAGE_LOAD={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return returnView;
    }

    @RequestMapping(value = "/reload", method = RequestMethod.GET)
    public String reloadPage(@Context WebSession webSession) {
        LOGGER.info("API_Name=reload , METHOD=GET");
        // Invalidate older session.
        webSession.invalidate();
        return "index";
    }

    @RequestMapping(value = "/idmsLogin", produces = MediaType.TEXT_HTML)
    public String idmsLogin(ServerWebExchange exchange) {
        LOGGER.info("API_Name=idmsLogin , METHOD=GET");
        LOGGER.info("Path={}", exchange.getRequest().getQueryParams());
        StringBuffer queryParams = new StringBuffer();
        String redirectionUrl = properties.getLoginUrl();
        MultiValueMap<String, String> map = exchange.getRequest().getQueryParams();
        map.toSingleValueMap().forEach((k, v) -> {
            queryParams.append(k).append("=").append(v).append("%26");
        });
        if (StringUtils.isNotEmpty(queryParams)) {
            redirectionUrl = redirectionUrl + "?" + queryParams;
        }
        redirectionUrl = StringUtils.toEncodedString(redirectionUrl.getBytes(), StandardCharsets.UTF_8);
        LOGGER.info("REDIRECTION_URL={}", redirectionUrl);
        return "redirect:" + redirectionUrl;
    }

    @RequestMapping(value = "/error", method = RequestMethod.GET)
    public String errorPage() {
        LOGGER.info("API_Name=errorPage");
        return "error";
    }

    @RequestMapping(value = "/unauthorized", method = RequestMethod.GET)
    public String unauthorizedPage() {
        LOGGER.info("API_Name=unauthorized");
        return "unauthorized";
    }

    /**
     * API to fetch metadata required on application page load
     *
     * @param dsid
     * @return
     */
    @RequestMapping(value = "/api/v1/aiml/init", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity fetchAIMLMetadata(@Context WebSession session) {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=init , METHOD=GET");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.fetchMetaData(session);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_INIT_CALL", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("INIT_CALL_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_INIT_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }

    /**
     * API to fetch User Hierarchy details
     *
     * @param dsid of the login user
     * @return
     */
    /*@RequestMapping(value = "/api/v1/aiml/userHierarchy/{dsid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity fetchUserHierarchy(@PathVariable String dsid) {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=userHierarchy , METHOD=GET");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.fetchUserHierarchy(dsid);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_USER_HIERARCHY", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("USER_HIERARCHY_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_USER_HIERARCHY={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }*/

    /**
     * API to fetch metadata required on application page load
     *
     * @param locale
     * @return
     */
//    @RequestMapping(value = "/api/v1/aiml/plans", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON
//            + ";charset=utf-8")
//    public ResponseEntity fetchAIMLPlans() {
//        Instant startTime = Instant.now();
//        LOGGER.info("fetchAIMLPlans");
//        ResponseEntity responseStatus = null;
//        try {
//            responseStatus = aimlService.fetchPlans();
//        } catch (AIMLInsightsException | RuntimeException e) {
//            LOGGER.error("EXCEPTION_OCCURRED_INIT_CALL", e);
//            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
//        } finally {
//            LOGGER.info("INIT_CALL_STATUS={}", responseHandler.getResponseStatus(responseStatus));
//            LOGGER.info("TOTAL_TIME_TAKEN_INIT_CALL={}",
//                    Duration.between(startTime, Instant.now()).toMillis());
//        }
//        return responseStatus;
//    }

    /**
     * API to save plan as a draft
     *
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/api/v1/aiml/saveAIMLPlan", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity saveAIMLPlans(@RequestBody AIMLPlans plans) throws JSONException {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=saveAIMLPlan , METHOD=POST");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.saveAIMLPlans(plans);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_SAVE_PLAN", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("InsightsAppController - SAVE_AS_DRAFT_CALL_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_SAVE_PLAN_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }

    @RequestMapping(value = "/api/v1/aiml/fetchRecentPlans", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity fetchRecentPlans(@RequestBody AIMLRecentPlansRequest requestDetails) {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=lastThreeMonthsplans , METHOD=POST");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.fetchRecentPlans(requestDetails);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_3MONTHS_CALL", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("FETCH_LAST_THREE_MONTHS_PLAN_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_FETCH_LAST_THREE_MONTHS_PLAN_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }

    @RequestMapping(value = "/api/v1/aiml/plans", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity getAIMLPlans(@RequestBody AIMLFetchPlanRequest requestDetails) throws JSONException {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=plans , METHOD=POST");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.getAIMLPlans(requestDetails);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_GET_AIML_PLANS", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("InsightsAppController - GET_AIML_PLANS_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_GET_AIML_PLANS_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }

    @RequestMapping(value = "/api/v1/aiml/updateAIMLPlan", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity updateAIMLPlans(@RequestBody AIMLPlans plans) throws JSONException {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=updateAIMLPlan , METHOD=PUT");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.updateAIMLPlans(plans);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_UPDATE_PLAN", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("InsightsAppController - UPDATE_PLAN_CALL_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_UPDATE_PLAN_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }

    @RequestMapping(value = "/api/v1/aiml/deleteAIMLPlan", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity deleteAIMLPlans(@RequestBody AIMLDeletePlanRequest deleteDetails) throws JSONException {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=deleteAIMLPlan , METHOD=GET");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.deleteAIMLPlans(deleteDetails);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_DELETE_PLAN", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("InsightsAppController - DELETE_PLAN_CALL_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_DELETE_PLAN_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }

    @RequestMapping(value = "/api/v1/aiml/planAggregate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity getPlanAggregate(@RequestBody AIMLSTLViewRequest requestDetails) {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=getSTLView , METHOD=GET");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.getPlanAggregate(requestDetails);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_getSTLView", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("getSTLView_PLAN_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_getSTLView_PLAN_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }

    @RequestMapping(value = "/api/v1/aiml/tasks", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity getAIMLTasks(@RequestBody AIMLTaskViewRequest requestDetails) {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=getAIMLTasks , METHOD=POST");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.getAIMLTasks(requestDetails);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_getAIMLTasks", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("getAIMLTasks_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_getAIMLTasks_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }

    @RequestMapping(value = "/api/v1/aiml/taskAggregate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity getAIMLTaskAggregate(@RequestBody AIMLSTLViewRequest requestDetails) {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=getAIMLTaskAggregate , METHOD=POST");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.getAIMLTaskAggregate(requestDetails);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_getAIMLTaskAggregate", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("getAIMLTaskAggregate_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_getAIMLTaskAggregate_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }

    @RequestMapping(value = "/api/v1/aiml/updateTask", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity updateTask(@RequestBody AIMLTaskUpdate requestDetails){
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=updateTask , METHOD=PUT");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.updateTask(requestDetails);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_UPDATE_TASK", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        }  finally {
            LOGGER.info("InsightsAppController - UPDATE_TASK_CALL_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_UPDATE_TASK_CALL={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }
    @RequestMapping(value = "/api/v1/aiml/person/{dsid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON
			+ ";charset=utf-8")
	public ResponseEntity fetchMaestroUserData(@PathVariable String dsid) {
		Instant startTime = Instant.now();
		LOGGER.info("API_Name=fetchMaestroUserData , METHOD=GET");
		ResponseEntity responseStatus = null;
		try {
			responseStatus = aimlService.fetchMaestroUserData(dsid);
		} catch (AIMLInsightsException | RuntimeException e) {
			LOGGER.error("EXCEPTION_OCCURRED_FETCHING_MAESTRO_USER_DATA", e);
			responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
		} finally {
			LOGGER.info("PERSON_API_STATUS={}", responseHandler.getResponseStatus(responseStatus));
			LOGGER.info("TOTAL_TIME_TAKEN_PERSON_API={}", Duration.between(startTime, Instant.now()).toMillis());
		}
		return responseStatus;
	}

    @RequestMapping(value = "/api/v1/aiml/userHierarchy/{dsid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON
            + ";charset=utf-8")
    public ResponseEntity fetchUserHierarchy(@PathVariable String dsid) {
        Instant startTime = Instant.now();
        LOGGER.info("API_Name=delegationUserHierarchy , METHOD=GET");
        ResponseEntity responseStatus = null;
        try {
            responseStatus = aimlService.fetchDelegationUserHierarchy(dsid);
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_DELEGATION_USER_HIERARCHY", e);
            responseStatus = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } finally {
            LOGGER.info("DELEGATION_USER_HIERARCHY_STATUS={}", responseHandler.getResponseStatus(responseStatus));
            LOGGER.info("TOTAL_TIME_TAKEN_DELEGATION_USER_HIERARCHY={}",
                    Duration.between(startTime, Instant.now()).toMillis());
        }
        return responseStatus;
    }
}
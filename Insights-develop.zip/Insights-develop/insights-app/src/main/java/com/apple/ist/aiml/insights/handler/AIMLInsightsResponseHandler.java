package com.apple.ist.aiml.insights.handler;

import com.apple.ist.aiml.insights.bean.AIMLInsightsServiceStatus;
import com.apple.ist.aiml.insights.constants.AIMLInsightsConstants;
import org.bson.types.ObjectId;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Named;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

@Named
public class AIMLInsightsResponseHandler {

	/**
	 * Build success response.
	 */
	public Response getSuccessResponse(final Status statusCode, final String message) {
		AIMLInsightsServiceStatus aimlInsightsServiceStatus = new AIMLInsightsServiceStatus();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.SUCCESS);
		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
		aimlInsightsServiceStatus.setErrorMessage(message);
		return Response.status(statusCode).entity(aimlInsightsServiceStatus).type(MediaType.APPLICATION_JSON).build();
	}

	public Response getSuccessResponse(final Status status, final int statusCode, final String id, final Timestamp lastModifiedTime) {
		AIMLInsightsServiceStatus aimlInsightsServiceStatus = new AIMLInsightsServiceStatus();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.SUCCESS);
		aimlInsightsServiceStatus.setStatusCode(statusCode);
		aimlInsightsServiceStatus.setId(id);
		aimlInsightsServiceStatus.setLastModifiedTime(lastModifiedTime);
		return Response.status(status).entity(aimlInsightsServiceStatus).type(MediaType.APPLICATION_JSON).build();
	}

	public <T> ResponseEntity getSuccessResponse(final Status statusCode, final T data) {
		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.SUCCESS);
		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
		aimlInsightsServiceStatus.setData(data);
		return ResponseEntity.status(HttpStatus.OK).body((T) aimlInsightsServiceStatus);
	}

	public <T> ResponseEntity getSuccessResponse(final Status statusCode, final String id,final String message) {
		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.SUCCESS);
		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
		aimlInsightsServiceStatus.setId(id);
		aimlInsightsServiceStatus.setErrorMessage(message);
		return ResponseEntity.status(HttpStatus.OK).body((T) aimlInsightsServiceStatus);
	}

	public <T> ResponseEntity getFailureResponse(final Status statusCode, final Boolean planExists) {
		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.FAILURE);
		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
		aimlInsightsServiceStatus.setErrorMessage("A Plan already exists for this planDsid, month and year");
		return ResponseEntity.status(HttpStatus.OK).body((T) aimlInsightsServiceStatus);
	}

//	public <T> Response getSuccessResponse(Status statusCode, T data, long recordCount) {
//		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
//	    aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.SUCCESS);
//	    aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
//	    aimlInsightsServiceStatus.setData(data);
//	    aimlInsightsServiceStatus.setRecordCount(recordCount);
//	    return Response.status(Status.OK).entity(aimlInsightsServiceStatus).type(MediaType.APPLICATION_JSON).build();
//	}

	public <T> ResponseEntity getSuccessResponse(final Status statusCode, final T data, final long recordCount) {
		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.SUCCESS);
		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
		aimlInsightsServiceStatus.setData(data);
		aimlInsightsServiceStatus.setRecordCount(recordCount);
		return ResponseEntity.status(HttpStatus.OK).body((T) aimlInsightsServiceStatus);
		//Response.status(Status.OK).entity(aimlInsightsServiceStatus).type(MediaType.APPLICATION_JSON).build();
	}

	public <T> Response getSuccessResponse(final Status statusCode, final String message, final T data) {
		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.SUCCESS);
		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
		aimlInsightsServiceStatus.setErrorMessage(message);
		aimlInsightsServiceStatus.setData(data);
		return Response.status(statusCode).entity(aimlInsightsServiceStatus).type(MediaType.APPLICATION_JSON).build();
	}

	/*
	 * Build Failure response.
	 */
//	public <T> Response getFailureResponse(Status statusCode, String errorMessage) {
//		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
//		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.FAILURE);
//		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
//		aimlInsightsServiceStatus.setErrorMessage(errorMessage);
//		return Response.status(Status.OK).entity(aimlInsightsServiceStatus).type(MediaType.APPLICATION_JSON).build();
//	}

	public <T> ResponseEntity getFailureResponse(final Status statusCode, final String errorMessage) {
		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.FAILURE);
		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
		aimlInsightsServiceStatus.setErrorMessage(errorMessage);
		return ResponseEntity.status(HttpStatus.OK).body((T) aimlInsightsServiceStatus);
	}

	public <T> ResponseEntity getFailureResponse(final Status statusCode, final String errorMessage, final String id) {
		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.FAILURE);
		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
		aimlInsightsServiceStatus.setErrorMessage(errorMessage);
		aimlInsightsServiceStatus.setId(id);
		return ResponseEntity.status(HttpStatus.OK).body((T) aimlInsightsServiceStatus);
	}

	public <T> ResponseEntity getFailureResponse(final Status statusCode, final String errorMessage, final T data) {
		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.FAILURE);
		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
		aimlInsightsServiceStatus.setErrorMessage(errorMessage);
		aimlInsightsServiceStatus.setData(data);
		return ResponseEntity.status(HttpStatus.OK).body((T) aimlInsightsServiceStatus);
	}

	public <T> Response getFailureResponse(final Status statusCode, final Map<String, String> customErrorMessage) {
		AIMLInsightsServiceStatus<T> aimlInsightsServiceStatus = new AIMLInsightsServiceStatus<>();
		aimlInsightsServiceStatus.setStatus(AIMLInsightsConstants.FAILURE);
		aimlInsightsServiceStatus.setStatusCode(statusCode.getStatusCode());
		aimlInsightsServiceStatus.setCustomErrorMessage(customErrorMessage);
		return Response.status(Status.OK).entity(aimlInsightsServiceStatus).type(MediaType.APPLICATION_JSON).build();
	}

	/**
	 * This method is to extract status from the response object.
	 *
	 * @param response input response object.
	 * @return returns the status.
	 */
	public static String getResponseStatus(final ResponseEntity response) {
		StringBuilder status = new StringBuilder();
		if (null != response && response.getBody() instanceof AIMLInsightsServiceStatus<?>) {
			AIMLInsightsServiceStatus<?> aimlInsightsServiceStatus = (AIMLInsightsServiceStatus<?>) response.getBody();
			if (null != aimlInsightsServiceStatus) {
				status.append(AIMLInsightsConstants.STATUS).append(AIMLInsightsConstants.EQUALS_TO)
						.append(aimlInsightsServiceStatus.getStatus()).append(AIMLInsightsConstants.COMMA);
				status.append(AIMLInsightsConstants.STATUS_CODE).append(AIMLInsightsConstants.EQUALS_TO)
						.append(aimlInsightsServiceStatus.getStatusCode()).append(AIMLInsightsConstants.COMMA);
				status.append(AIMLInsightsConstants.ERROR_MESSAGE).append(AIMLInsightsConstants.EQUALS_TO)
						.append(aimlInsightsServiceStatus.getErrorMessage());
			}
		}
		return status.toString();
	}

}


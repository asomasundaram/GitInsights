package com.apple.ist.aiml.insights.repository.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AIMLCompetencyFocus implements Serializable {
    private String comments;
    private List<AIMLCompetency> competencies;

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public List<AIMLCompetency> getCompetencies() {
        return competencies;
    }

    public void setCompetencies(List<AIMLCompetency> competencies) {
        this.competencies = competencies;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }

}

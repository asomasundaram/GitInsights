package com.apple.ist.aiml.insights.service.impl;
import static com.apple.ist.aiml.insights.constants.AIMLInsightsConstants.BUSINESS_UNIT_ID;
import static com.apple.ist.aiml.insights.constants.AIMLInsightsConstants.DATE_TIME_FORMATTE_MM_DD_YYYY;
import com.apple.ist.aiml.insights.bean.AIMLMetadata;
import com.apple.ist.aiml.insights.bean.AIMLUserHierarchy;
import com.apple.ist.aiml.insights.bean.AIMLUserLoginDetails;
import com.apple.ist.aiml.insights.constants.AIMLInsightsConstants;
import com.apple.ist.aiml.insights.controller.InsightsAppController;
import com.apple.ist.aiml.insights.exception.AIMLInsightsException;
import com.apple.ist.aiml.insights.handler.AIMLInsightsResponseHandler;
import com.apple.ist.aiml.insights.repository.AIMLInsightsPlanRepository;
import com.apple.ist.aiml.insights.repository.bean.*;
import com.apple.ist.aiml.insights.service.AIMLInsightsService;
import com.apple.ist.aiml.insights.spring.AppProperties;
import com.apple.ist.aiml.insights.utils.AIMLUtils;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.server.WebSession;

import javax.inject.Inject;
import javax.ws.rs.core.Response;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

import static java.time.LocalTime.now;

@Component
public class AIMLInsightsServiceImpl implements AIMLInsightsService {

    @Inject
    private AppProperties properties;

    @Inject
    AIMLInsightsPlanRepository mongoRepository;

    @Autowired
    private AIMLInsightsResponseHandler responseHandler;

    private static final Logger LOGGER = LoggerFactory.getLogger(InsightsAppController.class);

    @Override
    public ResponseEntity fetchMetaData(WebSession session) throws AIMLInsightsException {
        ResponseEntity response = null;
        AIMLMetadata metadata = new AIMLMetadata();

        try {
            // Get env from AppConfig
            metadata.setEnvironment(properties.getEnvironment());
            // Capture Plan Types from AppConfig
            List<AIMLPlanTypes> planTypesList = mongoRepository.fetchAIMLPlanTypes(BUSINESS_UNIT_ID);
            List<String> planTypes = planTypesList.stream()
                    .map(AIMLPlanTypes::getPlanTypeKey)
                    .collect(Collectors.toList());
            LOGGER.info("PlanTypes_List={}",planTypes);
            metadata.setPlanTypes(planTypes);

            // Capture Focus Areas + Metrics
            List<AIMLFocusAreaMetrics> focusAreaMetrics = mongoRepository.fetchFocusAreaMetrics(BUSINESS_UNIT_ID);
            LOGGER.info("FocusAreaMetrics_List={}",focusAreaMetrics);
            metadata.setFocusMetrics(focusAreaMetrics);

            // Capture Behavior
            List<AIMLBehaviors> behaviors = mongoRepository.fetchBehaviors(BUSINESS_UNIT_ID);
            LOGGER.info("Behavior_List={}",behaviors);
            metadata.setBehaviors(behaviors);

            // Capture Tasks
            List<AIMLTasks> tasks = mongoRepository.fetchTasks(BUSINESS_UNIT_ID);
            LOGGER.info("Task_List={}",behaviors);
            metadata.setTasks(tasks);

            // Capture UserData based on the input DSID
            AIMLUserData userData = new AIMLUserData();
            AIMLUserLoginDetails userDetails =  (AIMLUserLoginDetails) session.getAttributes().get("APPLE_CONNECT_USER_DETAILS");
            String appleConnectDSID = ( userDetails != null ) ? userDetails.getDsid() : "";
            String dsid;
            if (StringUtils.isNotBlank(appleConnectDSID)) {
                dsid = appleConnectDSID;
            } else {
                dsid = "";
            }
            userData = mongoRepository.fetchUserData(BUSINESS_UNIT_ID, dsid);
            LOGGER.info("AIML_UserData={}",userData);
            // Check if the DSID / Role ID / Primary locale to be influenced from Test Page
            if(userData.getDsid() == null) {
                // User not available in Maestro
                LOGGER.info("AIML_UserData={}",userData);
                userData.setDsid(userDetails != null ? userDetails.getDsid() : ""); // TO-DO until UI changes are completed.
                userData.setFirstName(userDetails != null ? userDetails.getFirstName() : "");
                userData.setLastName(userDetails != null ? userDetails.getLastName() : "");
                userData.setEmailAddress(userDetails != null ? userDetails.getEmailAddress() : "");
                userData.setPreferredName(userDetails != null ? userDetails.getPreferredName() : "");
            }
            String requestDsid = null;
            String requestRoleId = null;
            String requestLocale = null;
            // TO-DO. Uncomment this condition before moving to Production
//            if(properties.getEnvironment().equalsIgnoreCase("PRODUCTION")){
                if(StringUtils.isNotEmpty((String) session.getAttributes().get(AIMLInsightsConstants.INPUT_DSID))) {
                    requestDsid = (String) session.getAttributes().get(AIMLInsightsConstants.INPUT_DSID);
                    userData.setDsid(requestDsid); // TO-DO until UI changes are completed.
                }
                if(StringUtils.isNotEmpty((String) session.getAttributes().get(AIMLInsightsConstants.INPUT_ROLE_ID))) {
                    requestRoleId = (String) session.getAttributes().get(AIMLInsightsConstants.INPUT_ROLE_ID);
                    userData.setRoleId(requestRoleId);
                }
                if(StringUtils.isNotEmpty((String) session.getAttributes().get(AIMLInsightsConstants.INPUT_LOCALE))) {
                    requestLocale = (String) session.getAttributes().get(AIMLInsightsConstants.INPUT_LOCALE);
                    userData.setUserLocale(requestLocale);
                }
//            }

            if(userData != null)
                metadata.setUserData(AIMLUtils.getApplicationRoleLevel(userData,properties.getAimlRoles()));
            else
                metadata.setUserData(null);

            // Capture Competencies - TBD
            List<AIMLCompetencyFocusMetadata> competencyFocusList = mongoRepository.fetchCompetencyFocus(BUSINESS_UNIT_ID);
            LOGGER.info("CompetencyFocus_List={}",competencyFocusList);
            metadata.setCompetencyFocus(competencyFocusList);

            response = responseHandler.getSuccessResponse(Response.Status.OK, metadata);
        } catch (Exception e) {
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
            throw new AIMLInsightsException("Exception occurred while fetching AIML Metadata", e);
        }
        return response;
    }

    @Override
    public ResponseEntity fetchUserHierarchy(String dsid) throws AIMLInsightsException {
            ResponseEntity response = null;
            List<AIMLUserData> userHierarchyList = new ArrayList<>();
            AIMLUserData userData = new AIMLUserData();
            AIMLUserHierarchy userHierarchy = new AIMLUserHierarchy();
            try {
                userData = mongoRepository.fetchUserData(BUSINESS_UNIT_ID, dsid);
                userHierarchyList = mongoRepository.fetchUserHierarchy(BUSINESS_UNIT_ID, userData.getDsid());
                userHierarchy.setUserData(userData);
                userHierarchy.setDirects(userHierarchyList);
                LOGGER.info("User_Hierarchy={}",userHierarchy);
                response = responseHandler.getSuccessResponse(Response.Status.OK, userHierarchy);
            } catch (Exception e) {
                response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
                throw new AIMLInsightsException("Exception occurred while fetching AIML Metadata", e);
            }
            return response;
    }

    @Override
    public ResponseEntity fetchPlans() throws AIMLInsightsException {
        ResponseEntity response = null;
        try {
            List<AIMLPlans> planList = mongoRepository.fetchAIMLPlans(1000);
            response = responseHandler.getSuccessResponse(Response.Status.OK, planList);
        } catch (Exception e) {
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
            throw new AIMLInsightsException("Exception occurred while fetching AIML Plans", e);
        }
        return response;
    }

    @Override
    public ResponseEntity fetchRecentPlans(AIMLRecentPlansRequest requestDetails) throws AIMLInsightsException {
        ResponseEntity response = null;
        try {

            List<AIMLPlans> planList = mongoRepository.fetchRecentPlans(requestDetails);
            if (planList != null && planList.size() > 0) {
                response = responseHandler.getSuccessResponse(Response.Status.OK, planList);
            } else {
                response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, AIMLInsightsConstants.NO_PLAN_AVAILABLE);
            }
        }catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_3MONTHS_CALL", e);
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        }  catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred while fetching last three months Plans", e);
        }
        return response;
    }

    @Override
    public ResponseEntity saveAIMLPlans(AIMLPlans aimlPlans) throws AIMLInsightsException {
        ResponseEntity response = null;
        try {
            String validMonth = validateMonthFormat(aimlPlans.getPlanMonth());
            aimlPlans.setPlanMonth(validMonth);
            String validationResponse = validatePlan(aimlPlans);
            if (validationResponse.equalsIgnoreCase(AIMLInsightsConstants.PLAN_VALIDATED_SUCCESSFULLY)){
                AIMLUserData planCreatorUserData = mongoRepository.fetchUserData(BUSINESS_UNIT_ID, aimlPlans.getCreatedBy());
                AIMLUserData planUserData = mongoRepository.fetchUserData(BUSINESS_UNIT_ID, aimlPlans.getPlanDsid());
                if (properties.getCreatePlanRoles().contains(planCreatorUserData.getRoleId())){
                    Document planDoc = buildAIMLPlanDoc(aimlPlans, planUserData);
                    planDoc.append("isDeleted", false);
                    Map<String, String> planMap = mongoRepository.saveAIMLPlans(planDoc);
                    response = planMap.entrySet().stream()
                            .map(entry -> {
                                String save = entry.getKey();
                                if (save.equalsIgnoreCase(AIMLInsightsConstants.PLAN_SAVED_SUCCESSFULLY)) {

                                    return responseHandler.getSuccessResponse(Response.Status.OK, entry.getValue().toString(),save);
                                } else {
                                    return responseHandler.getFailureResponse(Response.Status.BAD_REQUEST,save);
                                }
                            })
                            .findFirst()
                            .orElse(null);
                } else {
                    response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, AIMLInsightsConstants.CREATE_PLAN_INVALID_ROLE);
                }
            } else{
                response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, validationResponse);
            }
        }
        catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_SAVE_PLAN", e);
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred while saveAIMLPlans", e);
        }
        return response;
    }

    private String validateMonthFormat(String month) {
        Boolean planMonth = month.matches("^(0?[1-9]|1[0-2])$");
        if (planMonth && month.length() == 1) {
            return "0" + month;
        }
        return month;
    }

    @Override
    public ResponseEntity getAIMLPlans(AIMLFetchPlanRequest requestDetails) throws AIMLInsightsException {
        ResponseEntity response = null;
        try {
            List<AIMLPlanList> planList = mongoRepository.getAIMLPlans(requestDetails);
            if (planList != null && planList.size() > 0) {
                response = responseHandler.getSuccessResponse(Response.Status.OK, planList);
            } else {
                response = responseHandler.getFailureResponse(Response.Status.OK, AIMLInsightsConstants.NO_PLAN_AVAILABLE, planList);
            }
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_GET_AIML_PLANS", e);
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred while getting AIML Plans landing page", e);
        }
        return response;
    }

    @Override
    public ResponseEntity updateAIMLPlans(AIMLPlans aimlPlans) throws AIMLInsightsException {
        ResponseEntity response = null;
        try {
            String validMonth = validateMonthFormat(aimlPlans.getPlanMonth());
            aimlPlans.setPlanMonth(validMonth);
            String validationResponse = validatePlan(aimlPlans);
            if (validationResponse.equalsIgnoreCase(AIMLInsightsConstants.PLAN_VALIDATED_SUCCESSFULLY)) {
                AIMLUserData userData = mongoRepository.fetchUserData(AIMLInsightsConstants.BUSINESS_UNIT_ID,
                        aimlPlans.getLastModifiedBy());
                if (properties.getUpdatePlanRoles().contains(userData.getRoleId())) {
                    Document planDoc = buildAIMLPlanDoc(aimlPlans, userData);
                    LocalDate planEndDate = parseDates(aimlPlans.getPlanEndDate());
                    Map<String,String> updateResponse = mongoRepository.updateAIMLPlans(planDoc, planEndDate);
                    response = updateResponse.entrySet().stream()
                            .map(entry -> {
                                String update = entry.getKey();
                                if (update.equalsIgnoreCase(AIMLInsightsConstants.PLAN_UPDATED_SUCCESSFULLY)) {
                                    return responseHandler.getSuccessResponse(Response.Status.OK, entry.getValue().toString(),update);
                                } else {
                                    return responseHandler.getFailureResponse(Response.Status.BAD_REQUEST,update);
                                }
                            })
                            .findFirst()
                            .orElse(null);
                } else {
                    response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, AIMLInsightsConstants.UPDATE_PLAN_INVALID_ROLE);
                }
            } else {
                response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, validationResponse);
            }
        }catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_UPDATE_PLAN", e);
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred while updateAIMLPlans", e);
        }
        return response;
    }

    @Override
    public ResponseEntity deleteAIMLPlans(AIMLDeletePlanRequest deleteDetails) throws AIMLInsightsException {
        ResponseEntity response = null;
        try {
            AIMLUserData userData = mongoRepository.fetchUserData(AIMLInsightsConstants.BUSINESS_UNIT_ID,
                    deleteDetails.getLastModifiedBy());
            if (properties.getDeletePlanRoles().contains(userData.getRoleId())) {
                String deleteResponse = mongoRepository.deleteAIMLPlans(deleteDetails);
                if (deleteResponse.equalsIgnoreCase(deleteDetails.getId())) {
                    response = responseHandler.getSuccessResponse(Response.Status.OK, deleteResponse.toString(), AIMLInsightsConstants.PLAN_DELETED_SUCCESSFULLY);
                } else {
                    response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, deleteResponse);
                }
            } else {
                response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, AIMLInsightsConstants.DELETE_PLAN_INVALID_ROLE);
            }
        }catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_DELETE_PLAN", e);
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        }catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred while deleteAIMLPlans", e);
        }
        return response;
    }

    @Override
    public ResponseEntity getPlanAggregate(AIMLSTLViewRequest requestDetails) throws AIMLInsightsException {
        ResponseEntity response = null;
        try {
            List<AIMLSTLViewResponse> stlViewList = mongoRepository.fetchPlanAggregate(requestDetails);
            if (stlViewList != null && stlViewList.size() > 0) {
                response = responseHandler.getSuccessResponse(Response.Status.OK, stlViewList);
            } else {
                response = responseHandler.getFailureResponse(Response.Status.OK, AIMLInsightsConstants.NO_PLAN_AGGREGATE, stlViewList);
            }
        }catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_stlViewList", e);
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        }  catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred while fetching stlViewList", e);
        }
        return response;
    }

    @Override
    public ResponseEntity getAIMLTasks(AIMLTaskViewRequest requestDetails) throws AIMLInsightsException {
        ResponseEntity response = null;
        try {
            List<AIMLTaskViewResponse> tasksList = mongoRepository.getAIMLTasks(requestDetails);
            if (tasksList != null && tasksList.size() > 0) {
                response = responseHandler.getSuccessResponse(Response.Status.OK, tasksList);
            } else {
                response = responseHandler.getFailureResponse(Response.Status.OK, AIMLInsightsConstants.NO_TASKS_AVAILABLE, tasksList);
            }
        }catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_getAIMLTasks", e);
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        }  catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred in method getAIMLTasks", e);
        }
        return response;
    }

    @Override
    public ResponseEntity getAIMLTaskAggregate(AIMLSTLViewRequest requestDetails) throws AIMLInsightsException {
        ResponseEntity response = null;
        try {
            List<AIMLSTLTaskViewResponse> taskAggregateList = mongoRepository.fetchTaskAggregate(requestDetails);
            if (taskAggregateList != null && taskAggregateList.size() > 0) {
                response = responseHandler.getSuccessResponse(Response.Status.OK, taskAggregateList);
            } else {
                response = responseHandler.getFailureResponse(Response.Status.OK, AIMLInsightsConstants.NO_TASK_AGGREGATE, taskAggregateList);
            }
        }catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_getAIMLTaskAggregate", e);
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        }  catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred in method getAIMLTaskAggregate", e);
        }
        return response;
    }

    @Override
    public ResponseEntity updateTask(AIMLTaskUpdate requestDetails) throws AIMLInsightsException {
        ResponseEntity response = null;
        try {
            Map<String,String> updateResponse = mongoRepository.updateTask(requestDetails);
            response = updateResponse.entrySet().stream()
                    .map(entry -> {
                        String update = entry.getKey();
                        if (update.equalsIgnoreCase(AIMLInsightsConstants.TASK_UPDATED_SUCCESSFULLY)) {
                            return responseHandler.getSuccessResponse(Response.Status.OK, entry.getValue().toString(),update);
                        } else {
                            return responseHandler.getFailureResponse(Response.Status.BAD_REQUEST,update);
                        }
                    })
                    .findFirst()
                    .orElse(null);
        }catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_UPDATE_TASK", e);
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred while updateTask", e);
        }
        return response;
    }


    public Document buildAIMLPlanDoc(AIMLPlans plans, AIMLUserData userData) {
        Document planDoc = new Document();
        List<Document> behaviorsDocList = new ArrayList<Document>();
        List<Document> focusAreaMetricsDocList = new ArrayList<Document>();
        List<Document> tasksDocList = new ArrayList<Document>();
        Document competencyFocusDoc = new Document();

        planDoc.append("planState", plans.getPlanState());
        planDoc.append("lastModifiedTime", plans.getLastModifiedTime());
        planDoc.append("planType", plans.getPlanType());
        planDoc.append("planYear", plans.getPlanYear());
        planDoc.append("planEndDate", plans.getPlanEndDate());
        planDoc.append("planMonth", plans.getPlanMonth());
        planDoc.append("lastModifiedBy", plans.getLastModifiedBy());
        planDoc.append("publishedDateTime", plans.getPublishedDateTime());
        planDoc.append("planDsid", plans.getPlanDsid());
        planDoc.append("createdBy", plans.getCreatedBy());
        planDoc.append("planNotes", plans.getPlanNotes());
        planDoc.append("planStartDate", plans.getPlanStartDate());
        planDoc.append("planOutput", plans.getPlanOutput());
        planDoc.append("closureRating", StringEscapeUtils.escapeJava(plans.getClosureRating()));
        planDoc.append("closureComments", StringEscapeUtils.escapeJava(plans.getClosureComments()));
        planDoc.append("planTypeReason", StringEscapeUtils.escapeJava(plans.getPlanTypeReason()));

        // Include user metadata
        Metadata metadata = new Metadata();
        metadata.setCreationRoleId(userData.getRoleId());
        metadata.setCreationRoleName(userData.getRoleName());

        Document metadataDoc = new Document();
        metadataDoc.append("creationRoleId", metadata.getCreationRoleId());
        metadataDoc.append("creationRoleName", metadata.getCreationRoleName());
        planDoc.append("metaData", metadataDoc);

        if (plans.getBehaviors() != null && plans.getBehaviors().size() > 0) {
            for (AIMLBehaviors behavior : plans.getBehaviors()) {
                Document behaviorsDoc = new Document();
                behaviorsDoc.append("id", null != behavior.getId() ? behavior.getId() : null);
                behaviorsDoc.append("behaviorMetricCode", null != behavior.getBehaviorMetricCode() ? behavior.getBehaviorMetricCode() : null);
                behaviorsDoc.append("behaviorCode", null != behavior.getBehaviorCode() ? behavior.getBehaviorCode() : null);
                behaviorsDoc.append("behaviorDescription", null != behavior.getBehaviorDescription() ? behavior.getBehaviorDescription() : null);

                behaviorsDocList.add(behaviorsDoc);
            }
        }
        planDoc.append("behaviors", behaviorsDocList);

        if (plans.getTasks() != null && plans.getTasks().size() > 0) {
            for (AIMLTasks task : plans.getTasks()) {
                Document tasksDoc = new Document();
                tasksDoc.append("id", null != task.getId() ? task.getId() : null);
                tasksDoc.append("taskCode", null != task.getTaskCode() ? task.getTaskCode() : null);
                tasksDoc.append("taskType", null != task.getTaskType() ? task.getTaskType() : null);
                tasksDoc.append("taskDescription", null != task.getTaskDescription() ? task.getTaskDescription() : null);
                tasksDoc.append("taskOwner", null != task.getTaskOwner() ? task.getTaskOwner() : null);
                tasksDoc.append("taskDueDate", null != task.getTaskDueDate() ? task.getTaskDueDate() : null);
                tasksDoc.append("taskStatus", null != task.getTaskStatus() ? task.getTaskStatus() : null);
                tasksDocList.add(tasksDoc);
            }
        }
        planDoc.append("tasks", tasksDocList);

        if (plans.getCompetencyFocus() != null) {
            AIMLCompetencyFocus competencyFocus = plans.getCompetencyFocus();
            competencyFocusDoc.append("comments", competencyFocus.getComments());
            if (competencyFocus.getCompetencies() != null && competencyFocus.getCompetencies().size() > 0) {
                List<Document> competencyList = new ArrayList<Document>();
                for (AIMLCompetency competency : competencyFocus.getCompetencies()) {
                    Document categoryDoc = new Document();
                    categoryDoc.append("factorName", null != competency.getFactorName()? competency.getFactorName() : null);
                    categoryDoc.append("categoryName", null != competency.getCategoryName() ? competency.getCategoryName() : null);
                    categoryDoc.append("focusArea", null != competency.getFocusArea() ? competency.getFocusArea() : null);
                    competencyList.add(categoryDoc);
                }
                competencyFocusDoc.append("competencies", competencyList);
            }
        }
        planDoc.append("competencyFocus", competencyFocusDoc);

        if (plans.getFocusAreaMetrics() != null && plans.getFocusAreaMetrics().size() > 0) {
            for (AIMLFocusAreaMetrics focusAreaMetrics : plans.getFocusAreaMetrics()) {
                Document focusAreaMetricsDoc = new Document();
                focusAreaMetricsDoc.append("focusArea", null != focusAreaMetrics.getFocusArea() ? focusAreaMetrics.getFocusArea() : null);
                focusAreaMetricsDoc.append("focusAreaMetrics", (null != focusAreaMetrics.getFocusAreaMetrics()) ? focusAreaMetrics.getFocusAreaMetrics() : null);
                focusAreaMetricsDocList.add(focusAreaMetricsDoc);
            }
        }
        planDoc.append("focusAreaMetrics", focusAreaMetricsDocList);
        return planDoc;
    }

    public String validatePlan(AIMLPlans aimlPlan)throws AIMLInsightsException {

        String response = null;
        boolean validateTask = false;
        boolean validateBehavior = false;
        boolean validateCompetency = false;
        boolean validateFocusAreaMetrics = false;
        boolean validateDates = false;
        boolean taskDueDateValid = false;
        boolean validateNoPlanType = false;
        boolean validateDraftPlan = false;

        LocalDate planStartDate = parseDates(aimlPlan.getPlanStartDate());
        LocalDate planEndDate = parseDates(aimlPlan.getPlanEndDate());

        if(StringUtils.isNotBlank(aimlPlan.getPlanType()) && (aimlPlan.getPlanType().equalsIgnoreCase(AIMLInsightsConstants.NO_PLAN_TYPE))) {
            if (StringUtils.isNotBlank(aimlPlan.getPlanStartDate()) && StringUtils.isNotBlank(aimlPlan.getPlanEndDate())
                    && StringUtils.isNotBlank(aimlPlan.getPlanMonth())
                    && planEndDate.isAfter(planStartDate) && !planEndDate.isBefore(LocalDate.now())) {
                validateDates = true;
                validateNoPlanType = true;
            } else {
                return response = AIMLInsightsConstants.INVALID_DATES_NO_PLAN;
            }
        }
        else if (StringUtils.isNotBlank(aimlPlan.getPlanState()) && (aimlPlan.getPlanState().equalsIgnoreCase(AIMLInsightsConstants.PLAN_STATE_DRAFT))) {
            if (StringUtils.isNotBlank(aimlPlan.getPlanStartDate()) && StringUtils.isNotBlank(aimlPlan.getPlanEndDate())
                    && StringUtils.isNotBlank(aimlPlan.getPlanMonth())
                    && planEndDate.isAfter(planStartDate) && !planEndDate.isBefore(LocalDate.now())) {
                validateDates = true;
                validateDraftPlan = true;
            } else {
                return response = AIMLInsightsConstants.INVALID_DATES_DRAFT_STATE;
            }
        } else {
            if (null != aimlPlan.getTasks() && aimlPlan.getTasks().size() >= 1 && aimlPlan.getTasks().size() <= 10) {
                for (AIMLTasks task : aimlPlan.getTasks()) {
                    if (StringUtils.isNotBlank(task.getTaskOwner()) && StringUtils.isNotBlank(task.getTaskStatus())) {
                        validateTask = true;
                    } else {
                        return response = AIMLInsightsConstants.TASK_OWNER_AND_STATUS;
                    }
                    LocalDate taskDueDate = parseDates(task.getTaskDueDate());
                    if (taskDueDate.isBefore(planStartDate) || taskDueDate.isAfter(planEndDate)) {
                        return response = AIMLInsightsConstants.INVALID_TASK_DUEDATE;
                    } else {
                        taskDueDateValid = true;
                    }
                }
            } else {
                return response = AIMLInsightsConstants.INVALID_TASK_SIZE;
            }

            if (null != aimlPlan.getBehaviors() && aimlPlan.getBehaviors().size() >= 1 && aimlPlan.getBehaviors().size() <= 10) {
                validateBehavior = true;
            } else {
                return response = AIMLInsightsConstants.INVALID_BEHAVIOR_SIZE;
            }

            Optional<AIMLCompetencyFocus> optionalCompetencyFocus = Optional.ofNullable(aimlPlan.getCompetencyFocus());

            if (optionalCompetencyFocus.isPresent()) {
                AIMLCompetencyFocus competencyFocus = optionalCompetencyFocus.get();
                if (competencyFocus.getCompetencies() != null &&
                        competencyFocus.getCompetencies().size() >= 1 && competencyFocus.getCompetencies().size() <= 10) {
                    validateCompetency = true;
                } else {
                    return response = AIMLInsightsConstants.INVALID_COMPETENCY_SIZE;
                }
            }
            if (null != aimlPlan.getFocusAreaMetrics() && aimlPlan.getFocusAreaMetrics().size() > 0) {
                validateFocusAreaMetrics = true;
            } else {
                return response = AIMLInsightsConstants.INVALID_FOCUS_AREA_METRICS_SIZE;
            }
            if (StringUtils.isNotBlank(aimlPlan.getPlanStartDate()) && StringUtils.isNotBlank(aimlPlan.getPlanEndDate())
                    && StringUtils.isNotBlank(aimlPlan.getPlanMonth())
                    && planEndDate.isAfter(planStartDate) && !planEndDate.isBefore(LocalDate.now())) {
                validateDates = true;
            } else {
                return response = AIMLInsightsConstants.INVALID_DATES;
            }
        }


        if (validateTask && validateBehavior && validateCompetency && validateFocusAreaMetrics && validateDates) {
            response = AIMLInsightsConstants.PLAN_VALIDATED_SUCCESSFULLY;
        } else if (validateNoPlanType) {
            response = AIMLInsightsConstants.PLAN_VALIDATED_SUCCESSFULLY;
        } else if (validateDraftPlan) {
            response = AIMLInsightsConstants.PLAN_VALIDATED_SUCCESSFULLY;
        } else {
            response = AIMLInsightsConstants.PLAN_VALIDATED_SUCCESSFULLY;
        }
        return response;
    }

    public LocalDate parseDates(String endDate) throws DateTimeParseException{
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMATTE_MM_DD_YYYY);
        LocalDate date = LocalDate.parse(endDate, formatter);
        return date;
    }

    @Override
    public boolean authorizeUserMaestroData(final String dsid, final String businessUnitId) throws AIMLInsightsException {
        boolean authorizedMaestroUser = false;
        try {
            AIMLUserData userData = mongoRepository.fetchUserData(businessUnitId, dsid);
            if (userData != null && StringUtils.isNotBlank(userData.getDsid())) {
                // Mark as Maestro authorized user
                authorizedMaestroUser = true;
            }
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_authorizeUserMaestroData", e);
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred during Maestro User Validation", e);
        }
        return authorizedMaestroUser;
    }
    
    @Override
	public ResponseEntity fetchMaestroUserData(String dsid) throws AIMLInsightsException {
		ResponseEntity response = null;

		try {
			AIMLUserData userData = mongoRepository.fetchUserData(BUSINESS_UNIT_ID, dsid);
			if (Objects.nonNull(userData)) {
				response = responseHandler.getSuccessResponse(Response.Status.OK, userData);
			} else {
				response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST,
						AIMLInsightsConstants.NOT_A_VALID_USER);
			}

		} catch (AIMLInsightsException | RuntimeException e) {
			LOGGER.error("EXCEPTION_OCCURRED_FETCHING_MAESTRO_USER_DATA", e);
			response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
		} catch (Exception e) {
			throw new AIMLInsightsException("Exception occurred in method fetchMaestroUserData", e);
		}
		return response;

	}
    @Override
    public ResponseEntity fetchDelegationUserHierarchy(String dsid) throws AIMLInsightsException {
        ResponseEntity response = null;
        AIMLUserDelegationHierarchy userDelegation = new AIMLUserDelegationHierarchy();
        List<AIMLUserDirectsDelegatesData> userDelegateDataList = new ArrayList<>();
        List<AIMLUserData> userDelegatesList = new ArrayList<>();
        AIMLUserData userData = new AIMLUserData();
        List<AIMLUserData> userDirectsList = new ArrayList<>();
        List<AIMLUserDelegation> delegatedUserDataList = new ArrayList<>();
        Map<String, List<AIMLUserData>> managerDsidMap = new HashMap<>();
        try {
            userDelegateDataList = mongoRepository.fetchDelegationUserHierarchy(dsid);
            if (userDelegateDataList.size() > 0) {
                AIMLUserDirectsDelegatesData userDataDetails = userDelegateDataList.get(0);
                userData.setDsid(userDataDetails.getDsid());
                userData.setFirstName(userDataDetails.getFirstName());
                userData.setLastName(userDataDetails.getLastName());
                userData.setPreferredName(userDataDetails.getPreferredName());
                userData.setRoleId(userDataDetails.getRoleId());
                userData.setRoleName(userDataDetails.getRoleName());
                userData.setManagerDsid(userDataDetails.getManagerDsid());
                userData.setL1Locale(userDataDetails.getL1Locale());
                userData.setL2Locale(userDataDetails.getL2Locale());
                userData.setL3Locale(userDataDetails.getL3Locale());
                userData.setL4Locale(userDataDetails.getL4Locale());
                userData.setL5Locale(userDataDetails.getL5Locale());
                userData.setSiteId(userDataDetails.getSiteId());
                userData.setSiteName(userDataDetails.getSiteName());
                userData.setEmployeeStatus(userDataDetails.getEmployeeStatus());
                userData.setBusinessUnitId(userDataDetails.getBusinessUnitId());
                userData.setEmailAddress(userDataDetails.getEmailAddress());
                userData.setDelegationStartDate(userDataDetails.getDelegationStartDate());
                userData.setDelegationEndDate(userDataDetails.getDelegationEndDate());
                userData.setDelegatedManagerDsid(userDataDetails.getDelegatedManagerDsid());
                userData.setPersonType(userDataDetails.getPersonType());
                userData.setPersonCategory(userDataDetails.getPersonCategory());
                userData.setUserLocale(userDataDetails.getUserLocale());
                List<String> managerIdsList = userDelegateDataList.stream()
                        .flatMap(userHierarchy -> userHierarchy.getDelegatedUserData().stream()) // Flatten the lists
                        .map(AIMLUserData::getManagerDsid) // Map to managerId
                        .collect(Collectors.toList());
                List<AIMLUserData> managerDsidData = mongoRepository.fetchUserDataList(managerIdsList);

                for (AIMLUserData manager : managerDsidData) {
                    String managerDsiId = manager.getDsid();
                    AIMLUserDelegation delegatedUserData = new AIMLUserDelegation();
                    for (AIMLUserDirectsDelegatesData userDirectDelegates : userDelegateDataList) {
                        userDelegatesList = userDirectDelegates.getDelegatedUserData();
                        managerDsidMap = userDelegatesList.stream()
                                .filter(userDelegate -> userDelegate.getDelegatedManagerDsid() != null)
                                .filter(userDelegate -> (null != userDelegate.getDelegationStartDate()) && (parseDates(userDelegate.getDelegationStartDate()).isBefore(LocalDate.now()))
                                        && (null != userDelegate.getDelegationEndDate()) && (parseDates(userDelegate.getDelegationEndDate()).isAfter(LocalDate.now())))
                                .collect(Collectors.groupingBy(AIMLUserData::getManagerDsid));
                        if(null!=managerDsidMap.get(managerDsiId) && managerDsidMap.get(managerDsiId).size() > 0) {
                            delegatedUserData.setManagerData(AIMLUtils.getApplicationRoleLevel(manager,properties.getAimlRoles()));
                            delegatedUserData.setDelegatesData(managerDsidMap.get(managerDsiId).stream().map(delegatedUser->AIMLUtils.getApplicationRoleLevel(delegatedUser,properties.getAimlRoles())).collect(Collectors.toList()));
                            delegatedUserDataList.add(delegatedUserData);
                        }
                    }
                }
                userDelegation.setUserData(AIMLUtils.getApplicationRoleLevel(userData,properties.getAimlRoles()));
                userDirectsList = userDataDetails.getDirects().stream().map(directsUsers->AIMLUtils.getApplicationRoleLevel(directsUsers,properties.getAimlRoles())).collect(Collectors.toList());
                userDelegation.setDirects(userDirectsList);
                userDelegation.setDelegatedUserData(delegatedUserDataList);
                response = responseHandler.getSuccessResponse(Response.Status.OK, userDelegation);
            } else {
                response = responseHandler.getFailureResponse(Response.Status.OK, AIMLInsightsConstants.NO_USER_DATA, userDirectsList);
            }
        } catch (AIMLInsightsException | RuntimeException e) {
            LOGGER.error("EXCEPTION_OCCURRED_fetchDelegationUserHierarchy", e);
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred in method fetchDelegationUserHierarchy", e);
        }
        return response;
    }
}


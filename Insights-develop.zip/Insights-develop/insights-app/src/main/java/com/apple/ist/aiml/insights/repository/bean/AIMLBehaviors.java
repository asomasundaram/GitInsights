package com.apple.ist.aiml.insights.repository.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AIMLBehaviors implements Serializable {

    private String id;
    private String businessUnitId;
    private String behaviorCode;
    private String behaviorMetricCode;
    private String behaviorDescription;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBusinessUnitId() {
        return businessUnitId;
    }

    public void setBusinessUnitId(String businessUnitId) {
        this.businessUnitId = businessUnitId;
    }

    public String getBehaviorCode() {
        return behaviorCode;
    }

    public void setBehaviorCode(String behaviorCode) {
        this.behaviorCode = behaviorCode;
    }

    public String getBehaviorMetricCode() {
        return behaviorMetricCode;
    }

    public void setBehaviorMetricCode(String behaviorMetricCode) {
        this.behaviorMetricCode = behaviorMetricCode;
    }

    public String getBehaviorDescription() {
        return behaviorDescription;
    }

    public void setBehaviorDescription(String behaviorDescription) {
        this.behaviorDescription = behaviorDescription;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }

}

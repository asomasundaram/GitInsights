package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;

public class AIMLRecentPlansRequest implements Serializable {

    private String dsid;
    private String planStartDate;

    private int limit;

    public String getDsid() {
        return dsid;
    }

    public void setDsid(String dsid) {
        this.dsid = dsid;
    }

    public String getPlanStartDate() {
        return planStartDate;
    }

    public void setPlanStartDate(String planStartDate) {
        this.planStartDate = planStartDate;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }
}

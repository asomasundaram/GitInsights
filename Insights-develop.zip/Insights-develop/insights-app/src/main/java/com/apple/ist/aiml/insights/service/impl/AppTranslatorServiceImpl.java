package com.apple.ist.aiml.insights.service.impl;

import com.apple.ist.aiml.insights.bean.AppTranslatorMessages;
import com.apple.ist.aiml.insights.bean.AppTranslatorResponse;
import com.apple.ist.aiml.insights.exception.AIMLInsightsException;
import com.apple.ist.aiml.insights.handler.AIMLInsightsResponseHandler;
import com.apple.ist.aiml.insights.spring.AppProperties;
import com.apple.nexus.apptranslator.client.LocalizationClientHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.core.Response;
import java.util.*;

@Component
public class AppTranslatorServiceImpl { //implements ApplicationRunner {

    private static final Logger LOGGER = LoggerFactory.getLogger(AppTranslatorServiceImpl.class);

    private ObjectMapper mapper;

    private LocalizationClientHelper localizationClientHelper;

    @Inject
    private AppProperties properties;

    @Autowired
    private AIMLInsightsResponseHandler responseHandler;

    @Inject
    public AppTranslatorServiceImpl(final LocalizationClientHelper localizationClientHelper) {
        this.localizationClientHelper = localizationClientHelper;
    }

    public ResponseEntity fetchAppTransalatorMessages(String locale) throws AIMLInsightsException {
        ResponseEntity response = null;
        AppTranslatorResponse appTranslatorResponse = new AppTranslatorResponse();
        List<AppTranslatorMessages> supportedLanguages = new ArrayList<>();
        try {
            String defaultLocale = "en_US";
            if (locale != null) {
                // Load default locale - en_US
                supportedLanguages.add(loadAppTransalatorMessages(defaultLocale));

                // Load messages for non en_US locales
                if (!locale.equalsIgnoreCase("en_US")) {
                    supportedLanguages.add(loadAppTransalatorMessages(locale));
                }
            }
            if (!supportedLanguages.isEmpty()) {
                appTranslatorResponse.setSupportedLanguages(supportedLanguages);
            }

            response = responseHandler.getSuccessResponse(Response.Status.OK, appTranslatorResponse);
        } catch (Exception e) {
            response = responseHandler.getFailureResponse(Response.Status.BAD_REQUEST, e.getMessage());
            throw new AIMLInsightsException("Exception occurred while processing messages from AppTranslator", e);
        }
        return response;
    }

    public AppTranslatorMessages loadAppTransalatorMessages(String locale) throws AIMLInsightsException {
        String[] localeArray;
        String country = "US";
        String language = "en";
        AppTranslatorMessages appTranslatorMessages = new AppTranslatorMessages();
        appTranslatorMessages.setLocale(locale);
        try {
            if (locale != null) {
                locale = locale.toLowerCase();
                localeArray = locale.split("_");
                if (localeArray.length != 0) {
                    language = localeArray[0];
                    country = localeArray[1];
                }
            }
            LOGGER.info("Loading AppTranslator message details for country ={} , language={}", country, language);
            ResourceBundle bundle = localizationClientHelper.getResourceBundle(new Locale(language, country));
            Map<String, String> messageKeys = new HashMap<>();
            final Enumeration<String> keys = bundle.getKeys();
            while (keys.hasMoreElements()) {
                final String key = keys.nextElement();
                messageKeys.put(key, bundle.getString(key));
            }
            appTranslatorMessages.setMessages(messageKeys);
            if (messageKeys.isEmpty()) {
                appTranslatorMessages.setMessages(messageKeys);
            }
        } catch (Exception e) {
            throw new AIMLInsightsException("Exception occurred while fetching messages from AppTranslator", e);
        }
        return appTranslatorMessages;
    }
}

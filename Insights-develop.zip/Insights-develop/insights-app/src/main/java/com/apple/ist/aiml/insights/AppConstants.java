/*
 * Copyright 2023 Apple, Inc
 * Apple Internal Use Only
 */


package com.apple.ist.aiml.insights;


/**
 * General constants for use across the module.
 */
public interface AppConstants {

    /**
     * The version of the REST APIs
     */
    String API_VERSION_V1 = "v1";

    /**
     * The root of all REST API URLs
     */
    String API_PREFIX = "/api/" + API_VERSION_V1;

    String ROOT_PATH = API_PREFIX + "/app";

    String INSIGHTS_ROOT_PATH = API_PREFIX + "/aiml";
    String HELLO_WORLD_URI = "/hello";

    String HELLO_WORLD_PATH = ROOT_PATH + HELLO_WORLD_URI;


}

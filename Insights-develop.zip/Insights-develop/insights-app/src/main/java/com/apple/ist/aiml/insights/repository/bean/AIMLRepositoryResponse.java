package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;
import java.util.List;

public class AIMLRepositoryResponse implements Serializable {
    List<AIMLPlans> aimlPlansList;
    List<AIMLPlanTypes> aimlPlanTypes;
    List<AIMLFocusAreaMetrics> aimlFocusAreaMetricsList;
    List<AIMLBehaviors> aimlBehaviorList;
    List<AIMLTasks> aimlTaskList;
    List<AIMLUserData> aimlUserDataList;
    AIMLUserData aimlUserData;
    List<AIMLCompetencyFocusMetadata> aimlCompetencyFocusList;

    List<AIMLPlanList> aimlPlanByDsidList;

    List<AIMLSTLViewResponse> aimlStlViewResponseList;

    List<AIMLTaskViewResponse> aimlTasksResponseList;
    List <AIMLSTLTaskViewResponse> aimlTaskAggregateResponseList;
    
    List<AIMLEmailResponse> aimlEmailResponse;

    List<AIMLUserDirectsDelegatesData> delegationUserHierarchyList;

	public List<AIMLSTLTaskViewResponse> getAimlTaskAggregateResponseList() {
        return aimlTaskAggregateResponseList;
    }

    public void setAimlTaskAggregateResponseList(List<AIMLSTLTaskViewResponse> aimlTaskAggregateResponseList) {
        this.aimlTaskAggregateResponseList = aimlTaskAggregateResponseList;
    }

    public List<AIMLSTLViewResponse> getAimlStlViewResponseList() {
        return aimlStlViewResponseList;
    }

    public void setAimlStlViewResponseList(List<AIMLSTLViewResponse> aimlStlViewResponseList) {
        this.aimlStlViewResponseList = aimlStlViewResponseList;
    }

    public List<AIMLPlanList> getAimlPlanByDsidList() {
        return aimlPlanByDsidList;
    }

    public void setAimlPlanByDsidList(List<AIMLPlanList> aimlPlanByDsidList) {
        this.aimlPlanByDsidList = aimlPlanByDsidList;
    }

    public List<AIMLPlans> getAimlPlansList() {
        return aimlPlansList;
    }

    public void setAimlPlansList(List<AIMLPlans> aimlPlansList) {
        this.aimlPlansList = aimlPlansList;
    }


    public List<AIMLPlanTypes> getAimlPlanTypes() {
        return aimlPlanTypes;
    }

    public void setAimlPlanTypes(List<AIMLPlanTypes> aimlPlanTypes) {
        this.aimlPlanTypes = aimlPlanTypes;
    }

    public List<AIMLFocusAreaMetrics> getAimlFocusAreaMetricsList() {
        return aimlFocusAreaMetricsList;
    }

    public void setAimlFocusAreaMetricsList(List<AIMLFocusAreaMetrics> aimlFocusAreaMetricsList) {
        this.aimlFocusAreaMetricsList = aimlFocusAreaMetricsList;
    }

    public List<AIMLBehaviors> getAimlBehaviorList() {
        return aimlBehaviorList;
    }

    public List<AIMLTasks> getAimlTaskList() {
        return aimlTaskList;
    }

    public AIMLUserData getAimlUserData() {
        return aimlUserData;
    }

    public void setAimlUserData(AIMLUserData aimlUserData) {
        this.aimlUserData = aimlUserData;
    }

    public void setAimlTaskList(List<AIMLTasks> aimlTaskList) {
        this.aimlTaskList = aimlTaskList;
    }

    public void setAimlBehaviorList(List<AIMLBehaviors> aimlBehaviorList) {
        this.aimlBehaviorList = aimlBehaviorList;
    }

    public List<AIMLCompetencyFocusMetadata> getAimlCompetencyFocusList() {
        return aimlCompetencyFocusList;
    }

    public void setAimlCompetencyFocusList(List<AIMLCompetencyFocusMetadata> aimlCompetencyFocusList) {
        this.aimlCompetencyFocusList = aimlCompetencyFocusList;
    }

    public List<AIMLUserData> getAimlUserDataList() {
        return aimlUserDataList;
    }

    public void setAimlUserDataList(List<AIMLUserData> aimlUserDataList) {
        this.aimlUserDataList = aimlUserDataList;
    }

    public List<AIMLTaskViewResponse> getAimlTasksResponseList() {
        return aimlTasksResponseList;
    }

    public void setAimlTasksResponseList(List<AIMLTaskViewResponse> aimlTasksResponseList) {
        this.aimlTasksResponseList = aimlTasksResponseList;
    }
    public List<AIMLEmailResponse> getAimlEmailResponse() {
		return aimlEmailResponse;
	}

	public void setAimlEmailResponse(List<AIMLEmailResponse> aimlEmailResponse) {
		this.aimlEmailResponse = aimlEmailResponse;
	}

    public List<AIMLUserDirectsDelegatesData> getDelegationUserHierarchyList() {
        return delegationUserHierarchyList;
    }

    public void setDelegationUserHierarchyList(List<AIMLUserDirectsDelegatesData> delegationUserHierarchyList) {
        this.delegationUserHierarchyList = delegationUserHierarchyList;
    }
}

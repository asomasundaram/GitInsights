package com.apple.ist.aiml.insights.repository.bean;

import java.util.List;
import java.util.Map;

public class AIMLUserDelegationHierarchy {

    private AIMLUserData userData;
    private List<AIMLUserData> directs;
    private List<AIMLUserDelegation> delegatedUserData;


    public AIMLUserData getUserData() {
        return userData;
    }

    public void setUserData(AIMLUserData userData) {
        this.userData = userData;
    }

    public List<AIMLUserData> getDirects() {
        return directs;
    }

    public void setDirects(List<AIMLUserData> directs) {
        this.directs = directs;
    }

    public List<AIMLUserDelegation> getDelegatedUserData() {
        return delegatedUserData;
    }

    public void setDelegatedUserData(List<AIMLUserDelegation> delegatedUserData) {
        this.delegatedUserData = delegatedUserData;
    }
}
package com.apple.ist.aiml.insights.constants;

public class AIMLInsightsConstants {

    /*
     * Constants for formatters.
     */
    public static final String CHARSET_UTF_8 = ";charset=utf-8";
    public static final String DATE_FORMAT = "dd/MM/yyyy HH:mm:ss";

    public static final String INIT_LOCALE = "locale";

    public static final String BUSINESS_UNIT_ID = "AIML";

    /*
     * Constants for status and codes.
     */
    public static final String FAILURE = "FAILURE";
    public static final String SUCCESS = "SUCCESS";
    public static final Integer STATUS_SUCCESS = 200;
    public static final Integer STATUS_FAILURE = 400;

    public static final String EQUALS_TO = "=";
    public static final String COMMA = ",";
    public static final String STATUS = "status";
    public static final String STATUS_CODE = "statusCode";
    public static final String ERROR_MESSAGE = "errorMessage";

    public static final String OBJECT_ID = "_id";

    public static final String ID = "id";

    public static final String FIRST_NAME = "firstName";

    public static final String LAST_NAME = "lastName";

    public static final String DSID = "dsid";

    public static final String INPUT_DSID = "inputDsid";

    public static final String EMAIL_ADDRESS = "emailAddress";

    public static final String COOKIE = "&cookie=";

    public static final String IP = "&ip=";

    public static final String INPUT_ROLE_ID = "roleId";

    public static final String INPUT_LOCALE = "locale";

    public static final String CHARESET_UTF_8 = "UTF-8";

    public static final String PERSON_ID = "prsId";

    public static final String APPLE_CONNECT_USER_DETAILS = "APPLE_CONNECT_USER_DETAILS";

    public static final String AIML_USER_EXPIRY_TIME = "AIML_USER_EXPIRY_TIME";

    public static final String HEALTH_CHECK_GSLB = "/health/check/gslb";

    public static final String GSLB_PATH = "gslb";

    public static final String HEALTH_CHECK = "/health/check";

    public static final String HEALTH_CHECK_SUFFIX = ".healthcheck";

    public static final String HEALTH_CHECK_UP = "UP";

    public static final String HEALTH_CHECK_DOWN = "DOWN";

    public static final String HEALTH_CHECK_COLLECTION = "default.healthcheck";

    public static final String GSLB_PROPERTY_KEY = "GSLBHealthCheck";

    public static final String SESSION_TIMEOUT_PATH = "sessiontimeout";

    public static final String SESSION_EXPIRED = "session expired";

    public static final String TOTAL_INVALIDATE_SESSION_REQUEST_RESPONSE_TIME = "TOTAL_INVALIDATE_SESSION_REQUEST_RESPONSE_TIME={}";

    public static final String SESSION_INVALIDATE_REQUEST = "Input request for invalidateSession={}";

    public static final String SESSION_INVALIDATE_RESPONSE = "Response for invalidateSession={}";

    public static final String CG_AUTHORISED_USER_EXPIRY_TIME = "CG_AUTHORISED_USER_EXPIRY_TIME";

    public static final String NICK_NAME_OR_PREFERRED_NAME = "nickName";

    public static final String EXCEPTION_ACCESS_GROUP = "exceptionAccessGroup";

    public static final String ALL_GROUPS = "allGroups";

    public static final String PRS_TYPE_CODE = "prsTypeCode";

    public static final String REDIRECTION_PATH = "?path=permissionmanager";

    public static final String NOT_A_VALID_USER = "Not a valid user";

    public static final String CG_CSRF_SESSION_TIMEOUT = "CG_CSRF_SESSION_TIMEOUT";

    public static final String PLAN_STATE_COMPLETED = "COMPLETED";

    public static final String PLAN_STATE_IN_PROGRESS = "IN_PROGRESS";

    public static final String PLAN_STATE_CANCELLED = "CANCELLED";

    public static final String PLAN_STATE_DRAFT = "DRAFT";
    public static final String PLAN_ALREADY_EXISTS = "A plan already exists for this planDsid, month and year";
    public static final String PLAN_SAVED_SUCCESSFULLY = "Plan saved Successfully.";
    public static final String PLAN_UPDATED_SUCCESSFULLY = "Plan updated Successfully.";
    public static final String PLAN_DELETED_SUCCESSFULLY = "Plan deleted Successfully.";
    public static final String PLAN_VALIDATED_SUCCESSFULLY = "Plan validated Successfully.";
    public static final String ACTIVE_PLAN_EXISTS = "An Active plan already exists for the given dsid";
    public static final String PLAN_SAVE_FAILED = "Failure in Plan save.";
    public static final String PLAN_UPDATE_FAILED = "Failure in Plan update.";
    public static final String PLAN_DELETE_FAILED = "Failure in Plan delete.";
    public static final String PLAN_VALIDATE_FAILED = "Failure in Plan validate.";
    public static final String NO_PLAN_AVAILABLE = "A valid Plan does not exist for the given id, month and year";
    public static final String NO_PLAN_AGGREGATE = "The plan aggregate data is not available";
    public static final String NO_TASK_AGGREGATE = "The task aggregate data is not available";
    public static final String INVALID_TASK_DUEDATE = "The TaskDueDate in the plan does not meet required criteria";
    public static final String INVALID_TASK_SIZE = "The number of Tasks in the plan does not meet required criteria";
    public static final String INVALID_BEHAVIOR_SIZE = "The number of Behaviors in the plan does not meet required criteria";
    public static final String INVALID_COMPETENCY_SIZE = "The number of Competencies in the plan does not meet required criteria";
    public static final String INVALID_FOCUS_AREA_METRICS_SIZE = "The number of focus area metrics in the plan does not meet required criteria";
    public static final String INVALID_DATES_NO_PLAN = "The plan validation failed for no plan type";
    public static final String INVALID_DATES_DRAFT_STATE = "The plan validation failed for draft state";
    public static final String INVALID_DATES = "The plan start date and plan end date does not meet required criteria";
    public static final String UPDATE_PLAN_INVALID_ROLE = "The plan can be modified only by a TL or an analyst";
    public static final String INVALID_TASK_UPDATE = "Tasks cannot be added to the plan until 10 days before plan end-date";
    public static final String CREATE_PLAN_INVALID_ROLE = "Plan cannot be created by this role. Please contact Administrator.";
    public static final String DELETE_PLAN_COMMENTS_REQUIRED = "Closure rating is required to complete a plan";
    public static final String TASK_OWNER_AND_STATUS = "Task owner and task status fields are mandatory";
    public static final String NO_PLAN_TYPE = "aiml_planType_no_plan";
    public static final  String DELETE_PLAN_INVALID_ROLE = "Plan can be deleted only by TL or STL";

    public static final  String NO_TASKS_AVAILABLE = "Valid tasks do not exist for the given Id, month and year";
    public static final  String  DATE_TIME_FORMATTE_MM_DD_YYYY="MM/dd/yyyy";

    public static final String TASK_UPDATED_SUCCESSFULLY = "Task updated Successfully.";
    public static final String TASK_UPDATED_FAILED = "Failure in task update";
    
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String APPLICATION_JSON = "application/json";
    public static final String ACCEPT = "Accept";
    public static final String AUTHORIZATION = "Authorization";
    public static final String DEFAULT_LOCALE = "en_US";

    public static final String NO_USER_DATA = "No user data available for the given id";
    public static final  String CONCURRENT_USER_UPDATES_STATUS = "Another user has modified the data, please reload the page and try again";
}

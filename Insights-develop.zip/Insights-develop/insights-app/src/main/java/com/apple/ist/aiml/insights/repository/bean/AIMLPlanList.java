package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;
import java.util.List;

public class AIMLPlanList implements Serializable {

    private String planDsid;

    List<AIMLPlans> plansList;

    public String getPlanDsid() {
        return planDsid;
    }

    public void setPlanDsid(String planDsid) {
        this.planDsid = planDsid;
    }

    public List<AIMLPlans> getPlansList() {
        return plansList;
    }

    public void setPlansList(List<AIMLPlans> plansList) {
        this.plansList = plansList;
    }
}

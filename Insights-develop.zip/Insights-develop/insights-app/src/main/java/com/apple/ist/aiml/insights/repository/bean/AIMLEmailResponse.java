package com.apple.ist.aiml.insights.repository.bean;

import java.io.Serializable;
import java.util.List;

public class AIMLEmailResponse implements Serializable{
	private static final long serialVersionUID = 1L;
	private String planState;
	private String planMonth;
	private String planYear;
	private String createdBy;
	private String planStartDate;
	private String planEndDate;
	private String planType;
	private List<AIMLBehaviors> behaviors;
	private List<AIMLTasks> tasks;
	private List<AIMLFocusAreaMetrics> focusAreaMetrics;
	private AIMLCompetencyFocus competencyFocus;
	private List<AIMLUserData> userDetails;
	private List<AIMLUserData> taskOwnerDetails;
	private List<String> locale;
	private String planNotes;
	private String createdByFirstName;
	private String createdByLastName;
	private String createdByEmail;
	
	
	public String getPlanState() {
		return planState;
	}

	public void setPlanState(String planState) {
		this.planState = planState;
	}

	public String getPlanMonth() {
		return planMonth;
	}

	public void setPlanMonth(String planMonth) {
		this.planMonth = planMonth;
	}

	public String getPlanYear() {
		return planYear;
	}

	public void setPlanYear(String planYear) {
		this.planYear = planYear;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getPlanStartDate() {
		return planStartDate;
	}

	public void setPlanStartDate(String planStartDate) {
		this.planStartDate = planStartDate;
	}

	public String getPlanEndDate() {
		return planEndDate;
	}

	public void setPlanEndDate(String planEndDate) {
		this.planEndDate = planEndDate;
	}

	public String getPlanType() {
		return planType;
	}

	public void setPlanType(String planType) {
		this.planType = planType;
	}

	public List<AIMLBehaviors> getBehaviors() {
		return behaviors;
	}

	public void setBehaviors(List<AIMLBehaviors> behaviors) {
		this.behaviors = behaviors;
	}

	public List<AIMLTasks> getTasks() {
		return tasks;
	}

	public void setTasks(List<AIMLTasks> tasks) {
		this.tasks = tasks;
	}

	public List<AIMLFocusAreaMetrics> getFocusAreaMetrics() {
		return focusAreaMetrics;
	}

	public void setFocusAreaMetrics(List<AIMLFocusAreaMetrics> focusAreaMetrics) {
		this.focusAreaMetrics = focusAreaMetrics;
	}

	public AIMLCompetencyFocus getCompetencyFocus() {
		return competencyFocus;
	}

	public void setCompetencyFocus(AIMLCompetencyFocus competencyFocus) {
		this.competencyFocus = competencyFocus;
	}

	public List<AIMLUserData> getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(List<AIMLUserData> userDetails) {
		this.userDetails = userDetails;
	}

	public List<AIMLUserData> getTaskOwnerDetails() {
		return taskOwnerDetails;
	}

	public void setTaskOwnerDetails(List<AIMLUserData> taskOwnerDetails) {
		this.taskOwnerDetails = taskOwnerDetails;
	}

	public List<String> getLocale() {
		return locale;
	}

	public void setLocale(List<String> locale) {
		this.locale = locale;
	}

	public String getPlanNotes() {
		return planNotes;
	}

	public void setPlanNotes(String planNotes) {
		this.planNotes = planNotes;
	}
	
	public String getCreatedByFirstName() {
		return createdByFirstName;
	}

	public void setCreatedByFirstName(String createdByFirstName) {
		this.createdByFirstName = createdByFirstName;
	}

	public String getCreatedByLastName() {
		return createdByLastName;
	}

	public void setCreatedByLastName(String createdByLastName) {
		this.createdByLastName = createdByLastName;
	}
	
	public String getCreatedByEmail() {
		return createdByEmail;
	}

	public void setCreatedByEmail(String createdByEmail) {
		this.createdByEmail = createdByEmail;
	}
}

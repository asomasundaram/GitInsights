import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import stylelint from 'vite-plugin-stylelint'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    vue({
      template: {
        compilerOptions: {
          isCustomElement: (tag) => tag.startsWith('bricks-')
        }
      }
    }),
    stylelint({
      fix: true
    })
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  server: {
    proxy: {
      '/api': {
        target: 'https://aiml-insights-dev.mdn.apple.com',
        changeOrigin: true,
        secure: false,
        headers: { cookie: 'SESSION=065b5553-40b2-4693-8957-3d42b4decfa9' }
      }
    },
    watch: {
      usePolling: true
    }
  },
  build: {
    assetsDir: 'dist/assets'
  }
})

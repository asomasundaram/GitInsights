import type { Employee } from '@/classes/Employee'
import type { Plan } from '@/classes/Plan'

export type InsightsAPIResponse = {
  id?: string
  data: object
  status: string
  statusCode: number
  errorMessage?: string
  customErrorMessage?: string
}

export type InsightsConfig = {
  environment: string
  behaviors: InsightsBehavior[]
  competencyFocus: InsightsCompetencyFocus[]
  focusMetrics: InsightsFocusMetric[]
  planTypes: string[]
  tasks: InsightsTask[]
  userData: Employee
}

export type DelegationHierarchy = {
  managerData: Employee
  delegatesData: Employee[]
}

export type InsightsHierarchyResponse = {
  userData: Employee
  directs: Employee[]
  delegatedUserData: DelegationHierarchy[]
}

export type InsightsMessagesResponse = {
  supportedLanguages: [{ locale: string; messages: { [key: string]: string } }]
}

export type InsightsBehavior = {
  businessUnitId: string
  behaviorCode: string
  behaviorDescription: string
}

export type InsightsTask = {
  businessUnitId: string
  taskCode: string
  taskDescription: string
  taskType: string
}

export type InsightsFocusMetric = {
  businessUnitId: string
  focusArea: string
  focusAreaMetrics: string
}

export type InsightsCompetencyFocus = {
  id: string
  factorName: string
  categoryList: InsightsCompetencyFocusCategory[]
}

export type InsightsCompetencyFocusCategory = {
  categoryName: string
  focusList: string[]
}

export type InsightsPlanBehavior = {
  id: string
  behaviorCode?: string
  behaviorDescription?: string
  behaviorMetricCode: string
}

export type InsightsPlanSupportingTask = {
  id: string
  taskCode?: string
  taskDescription?: string
  taskType?: string
  taskOwner: string
  taskDueDate: string
  taskStatus: string
}

export type InsightsPlanFocusArea = {
  focusArea: string
  focusAreaMetrics: string[]
}

export type InsightsPlanCompetencyFocusArea = {
  comments?: string
  competencies: InsightsPlanCompetency[]
}

export type InsightsPlanCompetency = {
  factorName: string
  categoryName: string
  focusArea: string
}

export type InsightsPlanCard = {
  dsid: string
  cardType: string
  currentPlan?: Plan
  currentDraft?: Plan
}

export type InsightsPlanDeleteBody = {
  id: string
  lastModifiedBy: string | number
  lastModifiedTime: string
  closureRating: string
  closureComments: string
}

export type InsightsTaskUpdateRequestBody = {
  planId: string
  taskId: string
  lastModifiedBy: string
  taskStatus: string
  taskDueDate: string
}

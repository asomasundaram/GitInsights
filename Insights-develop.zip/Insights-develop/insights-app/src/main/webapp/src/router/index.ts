import { createRouter, createWebHistory } from 'vue-router'
import PlansView from '@/views/PlansView.vue'
import { useSidebarStore } from '@/stores/sidebar'
import { useEmployeeStore } from '@/stores/employee'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/plans/:employee?',
      name: 'plans',
      alias: ['/', '/application'],
      component: PlansView
    },
    {
      path: '/tasks/:employee?',
      name: 'tasks',
      // Lazy-load Plan Builder only when the path is loaded
      component: () => import('@/views/TasksView.vue')
    },
    {
      path: '/plan_builder/:employee?',
      name: 'plan_builder',
      // Lazy-load Plan Builder only when the path is loaded
      component: () => import('@/views/PlanBuilder.vue')
    },
    {
      path: '/logout',
      name: 'logout',
      //redirect: '../public/loggedout.html'
      component: () => import('@/views/LogoutView.vue'),
      props: { isPublic: true }
    }
  ]
})

router.beforeEach((to) => {
  const sidebarStore = useSidebarStore()
  const employeeStore = useEmployeeStore()

  if (to.params.employee) {
    const employeeDSID = to.params.employee as string
    sidebarStore.setSelectedEmployee(employeeDSID)
  }
})

export default router

import { createI18n } from 'vue-i18n'

const i18n = createI18n({
  allowComposition: true,
  fallbackLocale: 'en-US',
  globalInjection: true,
  datetimeFormats: {
    'en-US': {
      monthOnly: { month: 'long' },
      monthAndYear: { month: 'long', year: 'numeric' }
    }
  }
})

export default i18n

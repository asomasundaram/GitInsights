<script setup lang="ts">
import LogoutView from '@/components/commons/Logout.vue'
</script>

<template>
  <LogoutView />
</template>

<script setup lang="ts">
import PlansView from '@/components/plans/PlansView.vue'
</script>

<template>
  <PlansView />
</template>

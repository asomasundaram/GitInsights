<script setup lang="ts">
import PlanBuilder from '@/components/plan_builder/PlanBuilder.vue'
</script>

<template>
  <PlanBuilder />
</template>

<script setup lang="ts">
import UnAuthorizedView from '@/components/commons/UnAuthorizedView.vue'
</script>

<template>
  <UnAuthorizedView />
</template>

<script setup lang="ts">
import { computed } from 'vue'
import TasksView from '@/components/tasks/TasksView.vue'
import SeniorTaskView from '@/components/tasks/SeniorTaskView.vue'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import { useSidebarStore } from '@/stores/sidebar'

const sidebarStore = useSidebarStore()

const currentUser = computed(() => {
  return EmployeeHelper.currentUser()
})

const selectedUser = computed(() => {
  return EmployeeHelper.findEmployee(sidebarStore.selectedEmployee)
})

const showSeniorManagerView = computed(() => {
  if (currentUser.value.applicationRoleLevel == 'level_10') return false
  // If the sidebar selection is a Senior Team Lead, show the view
  return selectedUser.value.applicationRoleLevel == 'level_30'
})
</script>

<template>
  <SeniorTaskView v-if="showSeniorManagerView" />
  <TasksView v-else />
</template>

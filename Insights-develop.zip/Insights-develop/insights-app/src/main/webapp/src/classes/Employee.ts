export class Employee {
  dsid: string
  managerDsid: string
  firstName: string
  preferredName?: string
  lastName: string
  email: string
  status: string
  roleId: string
  roleName: string
  siteId: string
  siteName: string
  locale: string
  locale2: string
  locale3: string
  locale4: string
  locale5: string
  businessUnitId: string
  applicationRoleLevel: string
  directs?: string[]

  constructor(employeeData: any) {
    this.dsid = employeeData.dsid
    this.managerDsid = employeeData.managerDsid
    this.firstName = employeeData.firstName
    this.preferredName = employeeData.preferredName
    this.lastName = employeeData.lastName
    this.email = employeeData.emailAddress
    this.status = employeeData.employeeStatus
    this.roleId = employeeData.roleId
    this.roleName = employeeData.roleName
    this.siteId = employeeData.siteId
    this.siteName = employeeData.siteName
    this.locale = employeeData.l1Locale
    this.locale2 = employeeData.l2Locale
    this.locale3 = employeeData.l3Locale
    this.locale4 = employeeData.l4Locale
    this.locale5 = employeeData.l5Locale
    this.businessUnitId = employeeData.businessUnitId
    this.applicationRoleLevel = employeeData.applicationRoleLevel
  }

  fullName() {
    return `${this.name()} ${this.lastName}`
  }

  name() {
    return this.preferredName || this.firstName
  }

  initials() {
    const firstInitial = this.name()[0]
    const lastInitial = this.lastName[0]
    return (firstInitial + lastInitial).toUpperCase()
  }
}

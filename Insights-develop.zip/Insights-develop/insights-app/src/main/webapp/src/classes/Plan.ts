import type { Employee } from '@/classes/Employee'
import type {
  InsightsPlanBehavior,
  InsightsPlanCompetencyFocusArea,
  InsightsPlanFocusArea,
  InsightsPlanSupportingTask
} from '@/types/InsightsTypes'

export class Plan {
  id: string
  draftUUID?: string
  businessUnitId: number
  behaviors: Array<InsightsPlanBehavior>
  closureComments?: string
  closureRating?: string
  competencyFocus: InsightsPlanCompetencyFocusArea
  createdBy: string
  focusAreaMetrics: InsightsPlanFocusArea[]
  lastModifiedBy: string
  lastModifiedTime: string
  planEndDate: string
  planDsid: string
  planMonth: string | number
  planNotes: string
  planOutput?: string
  planStartDate: string
  planState: string
  planType: string
  planTypeReason?: string
  planYear: string | number
  publishedDateTime?: string
  tasks: Array<InsightsPlanSupportingTask>

  constructor(planData: any) {
    this.id = planData.id
    this.businessUnitId = planData.businessUnitId
    this.behaviors = planData.behaviors
    this.closureComments = planData.closureComments
    this.closureRating = planData.closureRating
    this.competencyFocus = planData.competencyFocus
    this.createdBy = planData.createdBy
    this.draftUUID = planData.draftUUID
    this.focusAreaMetrics = planData.focusAreaMetrics
    this.lastModifiedBy = planData.lastModifiedBy
    this.lastModifiedTime = planData.lastModifiedTime
    this.planDsid = planData.planDsid
    this.planEndDate = planData.planEndDate
    this.planNotes = planData.planNotes
    this.planMonth = planData.planMonth
    this.planOutput = planData.planOutput
    this.planState = planData.planState
    this.planStartDate = planData.planStartDate
    this.planType = planData.planType
    this.planTypeReason = planData.planTypeReason
    this.planYear = planData.planYear
    this.publishedDateTime = planData.publishedDateTime
    this.tasks = planData.tasks
  }
}

export class PlanAggregate {
  dsid: string
  lastModifiedTime: number
  firstName: string
  lastName: string
  siteId: string
  siteName: string
  roleId: string
  roleName: string
  totalPlans: string
  completedPlans: string
  applicationRoleLevel: string
  planTypes: { [key: string]: string }

  constructor(aggregateData: any, lastModifiedTime?: string | number) {
    this.dsid = aggregateData.dsid
    this.lastModifiedTime = lastModifiedTime ? parseInt(lastModifiedTime as string) : Date.now()
    this.firstName = aggregateData.firstName
    this.lastName = aggregateData.lastName
    this.siteId = aggregateData.siteId
    this.siteName = aggregateData.siteName
    this.roleId = aggregateData.roleId
    this.roleName = aggregateData.roleName
    this.totalPlans = aggregateData.totalPlans
    this.completedPlans = aggregateData.completedPlans
    this.applicationRoleLevel = aggregateData.applicationRoleLevel
    this.planTypes = aggregateData.planTypes
  }
}

export class PlanTask {
  planId: string
  planMonth: string
  planYear: string
  planState: string
  planStartDate: string
  planEndDate: string
  publishedDateTime: string
  planType: string
  taskId: string
  taskDescription: string | null
  taskCode: string | null
  taskStatus: string
  taskOwnerDsid: string
  taskDueDate: string
  taskOwnerFirstName: string | null
  taskOwnerLastName: string | null

  constructor(taskData: any) {
    this.planId = taskData.planId
    this.planMonth = taskData.planMonth
    this.planYear = taskData.planYear
    this.planState = taskData.planState
    this.planStartDate = taskData.planStartDate
    this.planEndDate = taskData.planEndDate
    this.publishedDateTime = taskData.publishedDateTime
    this.planType = taskData.planType
    this.taskId = taskData.taskId
    this.taskDescription = taskData.taskDescription
    this.taskCode = taskData.taskCode
    this.taskStatus = taskData.taskStatus
    this.taskOwnerDsid = taskData.taskOwnerDsid
    this.taskDueDate = taskData.taskDueDate
    this.taskOwnerFirstName = taskData.taskOwnerFirstName
    this.taskOwnerLastName = taskData.taskOwnerLastName
  }
}

export class TaskAggregate {
  dsid: string
  firstName: string
  lastName: string
  roleId: string
  applicationRoleLevel: string
  siteId: string
  siteName: string
  overdue?: string
  dueSoon?: string
  closed?: string

  constructor(aggregateData: any) {
    this.dsid = aggregateData.dsid
    this.firstName = aggregateData.firstName
    this.lastName = aggregateData.lastName
    this.roleId = aggregateData.roleId
    this.applicationRoleLevel = aggregateData.applicationRoleLevel
    this.siteId = aggregateData.siteId
    this.siteName = aggregateData.siteName
    this.overdue = aggregateData.overdue
    this.dueSoon = aggregateData.dueSoon
    this.closed = aggregateData.closed
  }
}

import { createApp } from 'vue'
import UnAuthorizedView from '@/views/UnAuthorizedView.vue'

const app = createApp(UnAuthorizedView)
app.mount('#app')

import axios from 'axios'
import MockInitResponseJson from '@/mock_data/init_response.json'
import MockUserHierarchyResponseJson from '@/mock_data/user_hierarchy_response.json'
import type { InsightsAPIResponse, InsightsConfig } from '@/types/InsightsTypes'

// TODO: Switch out production url in ELSE statement
const APIHost = window.location.origin || ''
const APIPath = '/api/v1/aiml/'

const InsightsAPI = {
  get: async function (endpoint: string) {
    const url = `${APIHost}${APIPath}${endpoint}`
    console.log('InsightsAPI: GET', url)
    return axios
      .get<InsightsAPIResponse>(url)
      .then((response) => {
        console.log('InsightsAPI.get: Request returned.', endpoint, response)
        return response.data
      })
      .catch((error) => {
        // TODO: Proper error handling
        // This will probably only fail if the server can't be reached or has an
        // internal error that doesn't return our custom body
        console.log('InsightsAPI.get: Error with GET request', error)
        throw error
      })
  },
  post: async function (endpoint: string, body: object) {
    const url = `${APIHost}${APIPath}${endpoint}`
    console.log('InsightsAPI: POST', url, body)
    return axios
      .post<InsightsAPIResponse>(url, body)
      .then((response) => {
        console.log('InsightsAPI.POST: Response received', endpoint, response)
        return response.data
      })
      .catch((error) => {
        // TODO: Proper error handling
        console.log('InsightsAPI.POST: Error with POST request', error)
        throw error
      })
  },
  put: async function (endpoint: string, body: object) {
    const url = `${APIHost}${APIPath}${endpoint}`
    console.log('InsightsAPI: PUT', url, body)
    return axios
      .put<InsightsAPIResponse>(url, body)
      .then((response) => {
        console.log('InsightsAPI.PUT: Response received', endpoint, response)
        return response.data
      })
      .catch((error) => {
        // TODO: Proper error handling
        console.log('InsightsAPI.PUT: Error with PUT request', error)
        throw error
      })
  },
  mock: {
    get: function (endpoint: string) {
      // TODO: Mock fetch
    },
    init: function (dsid: string) {
      return new Promise((resolve) => {
        // Introduce delay to mock API response
        setTimeout(() => {
          const mockResponseData = MockInitResponseJson
          // const currentUserData = new Employee(mockResponseData.data.userData)
          // employeeStore.currentUser = currentUserData
          // employeeStore.allEmployees

          resolve(MockInitResponseJson)
        }, 500)
      })
    },
    userHierarchy: async function (dsid: string) {
      return new Promise((resolve) => {
        // Introduce delay to mock API response
        setTimeout(() => {
          const mockUserHierarchy = MockUserHierarchyResponseJson
          // const hierarchyManagerDsid = parseInt(mockUserHierarchy.data.userData.dsid)
          // const mappedDirects = mockUserHierarchy.data.directs.map((direct) => new Employee(direct))
          // employeeStore.allEmployees[hierarchyManagerDsid].directs = mappedDirects
          // // add directs to Employee store
          // for (let direct of mappedDirects) {
          //   employeeStore.allEmployees[direct.dsid] = direct
          // }
          // resolve(mappedDirects)
        }, 500)
      })
    }
  },
  delete: async function (endpoint: string, body: object) {
    const url = `${APIHost}${APIPath}${endpoint}`
    return axios
      .delete<InsightsAPIResponse>(url, { data: body })
      .then((response) => {
        return response.data
      })
      .catch((error) => {
        throw error
      })
  }
}

export default InsightsAPI

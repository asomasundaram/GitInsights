import InsightsAPI from '@/helpers/InsightsAPI'
import { useEmployeeStore } from '@/stores/employee'
import { useSidebarStore } from '@/stores/sidebar'
import { usePlansStore } from '@/stores/plans'
import DateHelper from '@/helpers/DateHelper'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import { Employee } from '@/classes/Employee'
import { Plan, PlanAggregate, PlanTask, TaskAggregate } from '@/classes/Plan'
import type {
  InsightsAPIResponse,
  InsightsConfig,
  InsightsHierarchyResponse,
  DelegationHierarchy,
  InsightsMessagesResponse,
  InsightsPlanDeleteBody,
  InsightsTaskUpdateRequestBody
} from '@/types/InsightsTypes'
import i18n from '@/i18n'

// Use Mock API if running in development
// const API = import.meta.env.DEV ? InsightsAPI.mock : InsightsAPI
const API = InsightsAPI
var employeeStore: any
var sidebarStore: any
var plansStore: any

const APIHelper = {
  init: async function () {
    // Configure global stores
    // We configure these in Init rather than as a global variable to ensure
    // the global store is already loaded and prepared to accept data
    employeeStore = useEmployeeStore()
    sidebarStore = useSidebarStore()
    plansStore = usePlansStore()
    console.log('APIHelper.init: Initializing application')
    // Fetch default library data and AppleConnect user from API
    return API.get('init')
      .then(checkAPIResponseForErrors)
      .then(async (response) => {
        const config = response.data as InsightsConfig
        console.log('APIHelper.init: Data returned', config)
        const currentUser = new Employee(config.userData)
        this.setLoggedInUser(currentUser)
        await this.setSelectedManager(currentUser)
        // Fetch localizations
        await this.fetchAndSetLocale()

        plansStore.setLibraryData(
          config.behaviors,
          config.competencyFocus,
          config.focusMetrics,
          config.planTypes,
          config.tasks
        )
        // Set Configuration data in the Plan store
        return true
      })
  },
  // Creating a separate function here to allow us to mask the current user
  // in the future
  // TODO: Add True DSID to state, masked dsid, etc.
  setLoggedInUser: function (currentUser: Employee) {
    console.log('ApiHelper: Setting True DSID for LoggedInUser', currentUser)
    // Quick validation to ensure the Employee Data isn't `NaN` or missing
    // TODO: Remove from testing
    if (!currentUser.dsid || currentUser.dsid == '') return
    employeeStore.setLoggedInUser(currentUser.dsid)
    employeeStore.cacheEmployees([currentUser])
  },
  changeSelectedManager: async function (dsid: string) {
    console.log('APIHelper.changeSelectedManager: DSID', dsid)
    return this.fetchHierarchyForDSID(dsid).then(() => {
      const employeeInfo = employeeStore.findEmployeeByDSID(dsid)
      return this.setSelectedManager(employeeInfo)
    })
  },
  // Set the selected manager in the sidebar.
  // Will be used in the future to allow for senior managers to search and view
  // other team leads under them
  setSelectedManager: async function (employee: Employee) {
    sidebarStore.setSelectedManager(employee.dsid)
    sidebarStore.setSelectedEmployee(employee.dsid)

    // When the manager changes, clear current direct reports and fetch them
    // from the API
    sidebarStore.setDirectReports([])
    const directs = await this.fetchHierarchyForDSID(employee.dsid)
    sidebarStore.setDirectReports(directs)
    const dsids = directs.map((direct) => direct.dsid)
    // return this.fetchAndSetPlansFor(dsids)
  },
  browserLanguage: function () {
    // Browser language is returned as 'xx-XX', except for Japan which is just
    // 'ja'
    const language = window.navigator.language
    return language || 'en-US'
  },
  fetchCurrentUser: function (dsid: string) {},
  fetchHierarchyForDSID: async function (dsid: string) {
    return API.get(`userHierarchy/${dsid}`)
      .then(checkAPIResponseForErrors)
      .then(async (response) => {
        const hierarchyData = response.data as InsightsHierarchyResponse
        // Update Cache for returned DSID data
        const userData = new Employee(hierarchyData.userData)
        employeeStore.cacheEmployees([userData])
        console.log('APIHelper.fetchHierarchyForDSID', dsid, response)
        const directs = hierarchyData.directs
        const delegatedUserData = hierarchyData.delegatedUserData

        if (directs.length) {
          employeeStore.setDirects(dsid, directs)
          // Fetch hierarchy for any TLs that report to the user
          await Promise.all(
            directs.map((direct) => {
              if (direct.applicationRoleLevel == 'level_20') return this.fetchHierarchyForDSID(direct.dsid)
              return Promise.resolve()
            })
          )
        }

        if (delegatedUserData.length) {
          delegatedUserData.forEach((delegation) => employeeStore.setDelegation(delegation))
        }

        return directs
      })
  },
  fetchPersonData: async function (dsid: string | undefined) {
    if (!dsid || dsid == '') return

    return API.get(`person/${dsid}`)
      .then(checkAPIResponseForErrors)
      .then((response) => {
        var employeeData = response.data as any
        console.log('APIHelper.fetchPersonData: employeeData:', employeeData)
        // If no employee exists in Maestro, cache data for `unknownEmployee` to
        // avoid re-fetching the data every time it's called by UI
        if (!employeeData.dsid) {
          console.warn(
            `APIHelper.fetchPersonData: No data found in Maestro for DSID ${dsid}, setting as Unknown Employee`
          )
          employeeData = JSON.parse(JSON.stringify(employeeStore.unknownEmployee))
          employeeData.dsid = dsid
        }
        const employee = new Employee(employeeData)
        employeeStore.setEmployee(employee)
        return employee
      })
      .catch((error) => {
        console.log('APIHelper.fetchPersonData: Error fetching data', error)
        throw error
      })
  },
  fetchAndSetLocale: async function (locale?: string) {
    // If no locale provided to override browser, use browser locale
    if (!locale) {
      const browserLanguage = this.browserLanguage()
      locale = browserLanguage
    }
    // Reformat Locale for AppTranslator
    const appTranslatorLocale = locale.replace('-', '_')
    console.log('APIHelper.fetchAndStoreLocalizations: Fetching localizations', locale)
    return this.fetchLocalizations(appTranslatorLocale).then((localizations) => {
      console.log('APIHelper.fetchAndStoreLocalizations: localizations returned', localizations)
      // Set each locale in the global state. API should return current locale
      // and en-US as fallback, re-set both in case localizations have changed
      for (let localizationData of localizations) {
        // Reformat returned locale names to match what the browser window
        // will return
        const dataLocale = localizationData.locale.replace('_', '-')
        const messages = localizationData.messages
        // Set returned messages
        i18n.global.setLocaleMessage(dataLocale, messages)
      }
      // Set global state to desired locale
      i18n.global.locale = locale
    })
  },
  fetchLocalizations: async function (locale: string) {
    return API.get(`messages/${locale}`)
      .then(checkAPIResponseForErrors)
      .then((response) => {
        const apiResponse = response.data as InsightsMessagesResponse
        return apiResponse.supportedLanguages
      })
  },
  fetchAndSetPlansFor: async function (dsids: string[], limit: number = 15) {
    plansStore.isLoadingPlans = true
    const planData = await this.fetchPlansFor(dsids, true, true, limit)
    plansStore.setPlansFromAPI(planData)
    plansStore.isLoadingPlans = false
    // Store in PlansStore
  },
  fetchPlansFor: async function (
    dsids: string[],
    includeCurrent: boolean = true,
    includeDrafts: boolean = true,
    limit: number = 3
  ) {
    const body = {
      createdFor: dsids,
      includeCurrent,
      includeDrafts,
      limit
    }
    return API.post(`plans`, body)
      .then(checkAPIResponseForErrors)
      .then((response) => {
        console.log('APIHelper.fetchPlans: Response', response)
        return response.data
      })
  },
  fetchRecentPlans: async function (dsid: string, startDate: string, limit: number = 3) {
    if (!dsid || !startDate) return
    const body = {
      dsid,
      planStartDate: startDate,
      limit
    }

    return API.post('fetchRecentPlans', body)
      .then(checkAPIResponseForErrors)
      .then((response) => {
        console.log('APIHelper.fetchRecentPlans: Response', response)
        const plans = response.data as Plan[]
        return plans
      })
      .catch((error) => {
        console.log('APIHelper.fetchRecentPlans: Error fetching plans', error)
        throw error
      })
  },
  fetchPlanAggregatesFor: async function (dsids: string[], date?: string) {
    if (!dsids || dsids.length < 1) {
      console.warn('APIHelper.fetchPlanAggregatesFor: No DSIDS supplied!', dsids, date)
      return []
    }
    if (!date) {
      const today = new Date()
      // Get the current Date, then set the day to be the first day in the
      // month and cast it to a string in MM/DD/YYYY format
      const thisMonth = new Date(today.setDate(1))
      date = DateHelper.shortFormat(thisMonth)
    }
    const body = {
      dsid: dsids,
      month: date
    }
    return API.post('planAggregate', body)
      .then(checkAPIResponseForErrors)
      .then((response) => {
        console.log('APIHelper.fetchPlanAggregates: Aggregate data returned', response)
        const rawAggregates = response.data as object[]
        const sortedAggregates  = rawAggregates.sort((a, b) => 
          (EmployeeHelper.fullNameFor(a["dsid"]) > EmployeeHelper.fullNameFor(b["dsid"])) ? 1 : 
          (EmployeeHelper.fullNameFor(a["dsid"]) <  EmployeeHelper.fullNameFor(b["dsid"])) ? -1 :
          0
        );
        return sortedAggregates.map((aggregateData) => new PlanAggregate(aggregateData))
      })
      .catch((error) => {
        console.log('APIHelper.fetchPlanAggregatesFor: Error fetching plan aggregates', error)
        throw error
      })
  },
  fetchTaskAggregatesFor: async function (dsids: string[], date?: string) {
    if (!dsids || dsids.length < 1) {
      console.warn('APIHelper.fetchTaskAggregatesFor: No DSIDS supplied!', dsids, date)
      return []
    }
    if (!date) {
      const today = new Date()
      // Get the current Date, then set the day to be the first day in the
      // month and cast it to a string in MM/DD/YYYY format
      const thisMonth = new Date(today.setDate(1))
      date = DateHelper.shortFormat(thisMonth)
    }
    const body = {
      dsid: dsids,
      month: date
    }
    return API.post('taskAggregate', body)
      .then(checkAPIResponseForErrors)
      .then((response) => {
        console.log('APIHelper.fetchTaskAggregates: Aggregate data returned', response)
        const rawAggregates = response.data as object[]
        return rawAggregates.map((aggregateData) => new TaskAggregate(aggregateData))
      })
      .catch((error) => {
        console.log('APIHelper.fetchTaskAggregatesFor: Error fetching task aggregates', error)
        throw error
      })
  },
  reloadPlansForDSID: async function (dsid: string) {
    console.log('APIHelper.reloadPlansforDSID', dsid)
    const employeeData = EmployeeHelper.findEmployee(dsid)
    // Guard against no employee found or Unknown Employee
    if (!employeeData || employeeData.dsid == 0) return
    const dsids = employeeData.directs || []
    switch (employeeData.applicationRoleLevel) {
      case 'level_30':
        return this.fetchPlanAggregatesFor(dsids)
      case 'level_20':
        return this.fetchAndSetPlansFor(dsids)
      default:
        return this.fetchAndSetPlansFor([employeeData.dsid])
    }
  },
  fetchAllTasks: async function (dsids: string[]) {
    if (!dsids.length) return
    return API.post('tasks', { dsid: dsids })
      .then(checkAPIResponseForErrors)
      .then((response) => {
        const rawTasks = response.data as object[]
        return rawTasks.map((taskData) => new PlanTask(taskData))
      })
      .catch((error) => {
        console.log('APIHelper.fetchAllTasks: Error fetching all tasks', error)
        throw error
      })
  },
  updateTask: async function (taskData: InsightsTaskUpdateRequestBody) {
    if (!taskData || !Object.keys(taskData).length) return
    return API.put('updateTask', { ...taskData })
      .then(checkAPIResponseForErrors)
      .then((response) => {
        if (response.id) return response.id
      })
      .catch((error: Error) => {
        throw error
      })
  },
  plans: {
    saveOrUpdatePlan: async function (planData: Plan) {
      planData.lastModifiedTime = String(Date.now())
      if (planData.id) {
        return this.updatePlan(planData)
      }
      return this.savePlan(planData)
    },
    savePlan: async function (planData: Plan) {
      return API.post('saveAIMLPlan', planData)
        .then(checkAPIResponseForErrors)
        .then((response) => {
          console.log('APIHelper.plans.saveNewPlan: SaveNewPlan respone', response)
          return response.id
        })
        .catch((error) => {
          console.log('APIHelper.plans.saveOrUpdatePlan: Error saving plan', error)
          // Re-throw the error from the API and let the UI handle it to display
          // an error message to the user
          throw error
        })
    },
    updatePlan: async function (planData: Plan) {
      return API.put('updateAIMLPlan', planData)
        .then(checkAPIResponseForErrors)
        .then((response) => {
          console.log('APIHelper.plans.updatePlan: updatePlan response', response)
          return response.id
        })
        .catch((error: Error) => {
          console.log('APIHelper.plans.updatePlan: Error updating plan', error)
          // Re-throw the error from the API and let the UI handle it to display
          // an error message to the user
          throw error
        })
    },
    loadForCurrentTeam: async function () {
      const sidebarDSIDs = sidebarStore.directReports.map((direct: Employee) => direct.dsid)
      console.log('APIHelper.plans.loadForCurrentTeam: Loading plans for:', sidebarDSIDs)
      APIHelper.fetchAndSetPlansFor(sidebarDSIDs)
    },
    deletePlan: async (params: InsightsPlanDeleteBody) => {
      return API.delete('deleteAIMLPlan', params)
        .then(checkAPIResponseForErrors)
        .then((response: InsightsAPIResponse) => {
          return response.id
        })
        .catch((error: Error) => {
          // Re-throw the error from the API and let the UI handle it to display
          // an error message to the user
          throw error
        })
    }
  }
}

function checkAPIResponseForErrors(response: InsightsAPIResponse) {
  if (response.statusCode !== 200) {
    console.log('APIHelper.checkAPIResponseForErrors: Response NOT 200', response)
    // Check for an error message
    const errorMessage = response.customErrorMessage || response.errorMessage
    if (errorMessage) throw new Error(errorMessage)
  }

  // // Check for an error message despite success response
  // const errorMessage = response.customErrorMessage || response.errorMessage
  // if (errorMessage) throw new Error(errorMessage)

  return response
}

export default APIHelper

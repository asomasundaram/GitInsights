import type {
  InsightsPlanBehavior,
  InsightsPlanCompetencyFocusArea,
  InsightsPlanFocusArea,
  InsightsPlanSupportingTask,
  InsightsPlanCard
} from '@/types/InsightsTypes'
import { Plan } from '@/classes/Plan'
import { usePlansStore } from '@/stores/plans'
import { useEmployeeStore } from '@/stores/employee'
import DateHelper from '@/helpers/DateHelper'
import i18n from '@/i18n'

var plansStore: any
var employeeStore: any
var t: any

const PlanHelper = {
  setupStore: function () {
    if (!plansStore) plansStore = usePlansStore()
    if (!employeeStore) employeeStore = useEmployeeStore()
    if (!t) t = i18n.global.t
  },
  planCardDataForDsids: function (dsids: string[]) {
    this.setupStore()
    console.log('PlanHelper.planCardDataForDsids', dsids)
    const mappedData = dsids.map((dsid: string) => {
      const currentPlan = plansStore.currentPlanFor(dsid)
      const currentDraft = plansStore.currentDraftFor(dsid)

      // Get the current month and year as strings from the Date Helper
      const currentDate = new Date()
      const currentMonth = DateHelper.realMonth(currentDate)
      const currentYear = DateHelper.numericYear(currentDate)
      // Search the Plan Store to see if a plan exists for the month and year.
      // We can use this to check if the employee has a `Exception - No Plan`
      // plantype to determine whether or not they need a plan
      const planForMonth = this.findPlanForMonthAndYear(dsid, currentMonth, currentYear)

      const cardType = currentPlan
        ? currentPlan.planType
        : planForMonth
        ? 'aiml_planType_no_plan'
        : 'planType_needs_plan'

      return {
        dsid: dsid,
        cardType,
        currentPlan,
        currentDraft
      } as InsightsPlanCard
    })
    return mappedData
  },
  findPlanForMonthAndYear: function (dsid: string, month: string | number, year: string | number) {
    const plansForAdvisor = plansStore.plansForDsid(dsid)
    if (!plansForAdvisor || plansForAdvisor.length < 1) return false

    const plansForYear = plansForAdvisor.filter((plan: Plan) => plan.planYear == year)
    const planForMonth = plansForYear.find((plan: Plan) => plan.planMonth == month)

    return planForMonth
  },
  sortPlanMonthAndYear: function (filteredPlans: Plan[], order: string) {
    if (order == 'ascending') {
      return filteredPlans.sort(
        (a, b) => new Date(`${a.planYear}/01/${a.planMonth}`).getTime() - new Date(`${b.planYear}/01/${b.planMonth}`).getTime()
      )
    } else {
      return filteredPlans.sort(
        (a, b) =>  new Date(`${b.planYear}/01/${b.planMonth}`).getTime() -  new Date(`${a.planYear}/01/${a.planMonth}`).getTime()
      )
    }
  },
  duplicatePlan: function (planId: string, draftUUID: string) {
    this.setupStore() // Make sure Store is setup and accessible

    const planToDuplicate = plansStore.findPlan(planId)
    const currentUserDsid = employeeStore.currentUser?.dsid

    if (!planToDuplicate || !currentUserDsid)
      return console.error(
        'Unable to duplicate plan, unable to find plan or employee',
        planToDuplicate,
        currentUserDsid
      )

    const today = new Date()
    const oneMonthAway = new Date(today.getTime() + 1000 * 60 * 60 * 24 * 30)

    const newData = new Plan({
      ...planToDuplicate,
      // Set creation and modification DSIDs to current user
      createdBy: currentUserDsid,
      closureRating: null,
      closureComments: null,
      lastModifiedBy: currentUserDsid,
      lastModifiedTime: today.getTime(),
      // Reset identifiers
      id: undefined,
      draftUUID: draftUUID,
      // Ensure state is set to DRAFT
      planState: 'DRAFT',
      // Reset start and ene dates
      planStartDate: DateHelper.shortFormat(today),
      planEndDate: DateHelper.shortFormat(oneMonthAway),
      planMonth: DateHelper.realMonth(today),
      planNotes: '',
      planYear: DateHelper.numericYear(today),
      publishedDateTime: null
    })

    // Replace Behavior UUIDs with new IDs to prevent issues in db
    newData.behaviors = newData.behaviors.map((behavior: InsightsPlanBehavior) => {
      behavior.id = window.crypto.randomUUID()
      return behavior
    })

    // Reset nested competency comments
    newData.competencyFocus.comments = ''

    // Reset Task Due Dates and Statuses
    newData.tasks = newData.tasks.map((task: InsightsPlanSupportingTask) => {
      // Assign a new UUID
      task.id = window.crypto.randomUUID()
      // Reset task status to IN_PROGRESS
      task.taskStatus = 'IN_PROGRESS'
      // Set DueDate to 1 month in the future
      task.taskDueDate = DateHelper.shortFormat(oneMonthAway)
      return task
    })

    console.log('duplicated data:', newData)

    return newData
  },
  cloneObject: function (object: any) {
    return JSON.parse(JSON.stringify(object))
  },
  completedTasks: function (currentPlan: Plan | undefined) {
    this.setupStore()
    if (!currentPlan || !currentPlan.tasks || currentPlan.tasks.length < 1) return ''

    const completeTasks = currentPlan.tasks.filter(
      (task: InsightsPlanSupportingTask) => task.taskStatus == 'COMPLETED'
    ).length
    const totalTasks = currentPlan.tasks.filter(
      (task: InsightsPlanSupportingTask) => task.taskStatus !== 'CANCELLED'
    ).length
    return t('completed_tasks_count', { count: completeTasks, totalCount: totalTasks })
  },
  planStatuses: function () {
    this.setupStore()
    return {
      IN_PROGRESS: t('task_status_in_progress'),
      CANCELLED: t('task_status_cancelled'),
      COMPLETED: t('task_status_complete')
    }
  },
  taskStatuses: function () {
    this.setupStore()
    return {
      IN_PROGRESS: t('task_status_in_progress'),
      ON_HOLD: t('task_status_on_hold'),
      INCOMPLETE: t('task_status_incomplete'),
      CANCELLED: t('task_status_cancelled'),
      COMPLETED: t('task_status_complete')
    }
  },
  taskFilterOptions: function () {
    this.setupStore()
    return {
      DUE_SOON: t('due_soon_label'),
      OVERDUE: t('overdue_label'),
      COMPLETED: t('task_status_complete'),
      IN_PROGRESS: t('task_status_in_progress'),
      ON_HOLD: t('task_status_on_hold'),
      INCOMPLETE: t('task_status_incomplete'),
      CANCELLED: t('task_status_cancelled')
    }
  },
  taskGroupByOptions: function () {
    this.setupStore()
    return {
      TODAY: t('today_label'),
      THIS_WEEK: t('this_week_label'),
      OTHERS: t('other_label')
    }
  },
  groupByOptions: function () {
    this.setupStore()
    return { ...this.taskGroupByOptions(), ...this.taskFilterOptions() }
  },
  validate: {
    planMonthAndYear: function (
      uuid: string,
      planMonth: number | string,
      planYear: number | string,
      plans: Plan[]
    ) {
      console.log('PlanHelper.validate.planMonthAndYear', uuid, planMonth, planYear, plans)
      const plansWithoutCurrentDraft = plans.filter((plan) => (plan.draftUUID || plan.id) != uuid)
      const plansForMonthAndYear = plansWithoutCurrentDraft.filter(
        (p) => p.planMonth == planMonth && p.planYear == planYear
      )
      console.log(
        'PlanHelper.validate.planMonthAndYear: Plans for month and year',
        plansForMonthAndYear
      )
      if (plansForMonthAndYear.length > 0)
        return t('error_validation_plan_exists_for_month_and_year')

      return null
    },
    behaviors: function (behaviorData: InsightsPlanBehavior[]) {
      if (!Array.isArray(behaviorData) || behaviorData.length === 0) {
        return t('error_validation_plan_must_have_behaviors')
      }

      if (behaviorData.filter((b) => !b.behaviorCode).length > 0)
        return t('error_validation_behavior_description_required')
      if (behaviorData.filter((b) => !b.behaviorMetricCode).length > 0)
        return t('error_validation_behavior_metric_required')

      return null
    },
    competencyFocus: function (competencyFocusArea: InsightsPlanCompetencyFocusArea) {
      const focuses = competencyFocusArea.competencies
      const maxLength = 3
      const minLength = 1
      if (!Array.isArray(focuses) || focuses.length < minLength)
        return t('error_validation_competency_focus_required', { minLength })
      if (focuses.length > maxLength)
        return t('error_validation_competency_focus_maximum', { maxLength })
    },
    planDates: function (dateData: { planStartDate: string; planEndDate: string }) {
      const planStartDate = dateData.planStartDate
      const planEndDate = dateData.planEndDate

      // Check for existance and empty strings
      // TODO: Localize messages
      if (!planStartDate || !planEndDate || planStartDate == '' || planEndDate == '')
        return t('error_validation_plan_start_and_end_required')
      if (isNaN(Date.parse(planStartDate))) return t('error_validation_plan_start_invalid')
      if (isNaN(Date.parse(planEndDate))) return t('error_validation_plan_end_invalid')

      const startDate = new Date(planStartDate)
      const endDate = new Date(planEndDate)

      if (planStartDate == planEndDate) return t('error_validation_plan_start_and_end_different')
      if (endDate < startDate) return t('error_validation_plan_start_before_end')

      // Ensure start and end dates can be converted to actual dates and are
      // valid.
      // TODO: Check if dates are within the month selected on the plan?
      // TODO: Check if we need additional date validation, for example, should
      // they not be certain dates?
      // try {

      // } catch (error) {
      //   console.warn('PlanHelper.validate.planDates: Invalid Plan Dates', error)
      //   return false
      // }

      return null
    },
    focusAreaMetrics: function (focusAreaData: InsightsPlanFocusArea[]) {
      console.log('PlanHelper.validate.focusAreaMetrics:', focusAreaData)
      const errors = {}
      if (focusAreaData) {
        for (let focusArea of focusAreaData) {
          if (focusArea.focusAreaMetrics.length < 1)
            errors[focusArea.focusArea] = t('error_validation_focus_area_metric_required')
        }
      } else {
        return t('error_validation_focus_area_required')
      }

      return Object.keys(errors).length > 0 ? errors : null
    },
    tasks: function (planData: Plan) {
      const tasks: InsightsPlanSupportingTask[] = planData.tasks
      const minimumTasks = 1
      if (!Array.isArray(tasks) || tasks.length < minimumTasks)
        return t('error_validation_supporting_tasks_required', { minimumTasks })
      const taskErrors = [] as any[]
      for (let task of tasks) {
        const errors = PlanHelper.validate.task(task, planData.planStartDate, planData.planEndDate)
        if (Object.keys(errors).length > 0) taskErrors.push(errors)
        console.log('Task Errors', errors, taskErrors)
      }
      if (taskErrors.length > 0) return t('error_validation_plan_tasks_have_errors')

      return null
    },
    task: function (taskData: InsightsPlanSupportingTask, startDate: string, endDate: string) {
      const errors = {} as { taskDescription?: string; taskOwner?: string; taskDueDate?: string }
      // Task code/description errors
      const taskText = taskData.taskCode || taskData.taskDescription
      if (!taskText || taskText == '')
        errors.taskDescription = t('error_validation_supporting_task_description_required')

      // Task owner errors
      if (!taskData.taskOwner)
        errors.taskOwner = t('error_validation_supporting_task_owner_required')
      // Task date validation messages are handled by the date picker, but we
      // don't want to proceed if there is an error

      // Task due date falls within the plan's start and end date
      const taskDueDate = taskData.taskDueDate

      if (taskDueDate < startDate || taskDueDate > endDate)
        errors.taskDueDate = t('error_validation_supporting_task_date_outside_plan')
      console.log('PlanHelper.validate.task', taskData, errors)
      return errors
    },
    plan: function (planData: Plan) {
      PlanHelper.setupStore()
      const errors = {
        planMonthAndYear: undefined as undefined | string,
        planDates: undefined as undefined | string,
        focusArea: undefined as undefined | string,
        behaviors: undefined as undefined | string,
        competency: undefined as undefined | string,
        supportingTasks: undefined as undefined | string
      }

      const plansForAdvisor = plansStore.plansForDsid(planData.planDsid)
      const planMonthAndYear = PlanHelper.validate.planMonthAndYear(
        planData.draftUUID || planData.id,
        planData.planMonth,
        planData.planYear,
        plansForAdvisor
      )
      if (planMonthAndYear) errors.planMonthAndYear = planMonthAndYear

      // Validate Plan Start and End Date
      const dateErrors = PlanHelper.validate.planDates({
        planStartDate: planData.planStartDate,
        planEndDate: planData.planEndDate
      })
      if (dateErrors) errors.planDates = dateErrors

      // Validate Behaviors
      const behaviorErrors = PlanHelper.validate.behaviors(planData.behaviors)
      if (behaviorErrors) errors.behaviors = behaviorErrors

      // Validate Focus Areas
      const focusAreaErrors = PlanHelper.validate.focusAreaMetrics(planData.focusAreaMetrics)
      if (focusAreaErrors) errors.focusArea = t('error_validation_focus_area_one_or_more_errors')

      // Validate Competency Focuses
      const competencyErrors = PlanHelper.validate.competencyFocus(planData.competencyFocus)
      if (competencyErrors) errors.competency = competencyErrors

      // Validate  Supporting Tasks
      const supportingTaskErrors = PlanHelper.validate.tasks(planData)
      if (supportingTaskErrors) errors.supportingTasks = supportingTaskErrors

      return errors
    }
  },
  disableStatus: function (status: string) {
    return ['CANCELLED', 'COMPLETED'].includes(status)
  }
}

export default PlanHelper

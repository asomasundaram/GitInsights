import { Employee } from '@/classes/Employee'
import type { Plan } from '@/classes/Plan'
import { useEmployeeStore } from '@/stores/employee'
import { useSidebarStore } from '@/stores/sidebar'
import APIHelper from '@/helpers/APIHelper'
var employeeStore

const EmployeeHelper = {
  setupStore: () => {
    if (employeeStore) return
    // We have to make sure the store is set up after the application is
    // fully initialized or it will not use the global store
    employeeStore = useEmployeeStore()
  },
  currentUser: function () {
    this.setupStore()
    return employeeStore.currentUser as Employee
  },
  findEmployee: function (dsid: string | undefined) {
    this.setupStore()
    const employeeData = employeeStore.findEmployeeByDSID(dsid)

    // If returned as Unknown
    if (employeeData.dsid == 0) {
      console.log('EmployeeHelper.findEmployee: Data not in store. Checking API.')
      APIHelper.fetchPersonData(dsid)
    }

    return employeeData
  },
  fullNameFor: function (dsid: string | undefined) {
    this.setupStore()

    const employeeData = this.findEmployee(dsid)
    return employeeData.fullName()
  },
  employeeDsidsForTasks: function (plan: Plan) {
    this.setupStore()
    // Available employees for the tasks list should be:
    // - Plan Analyst
    // - Manager for Analyst
    // - Current user, if different than manager or analyst

    const planUser = this.findEmployee(plan.planDsid)

    const employeeList = [plan.planDsid]
    // Make sure the Planuser wasn't returned as `Unknown User`, then push the
    // manager's DSID to the list
    if (planUser.managerDsid !== 0) employeeList.push(planUser.managerDsid)

    // Get the current user's DSID and add it to the list of available people
    // if it is not already in the list.
    const currentUserDsid = employeeStore.currentUser.dsid
    if (!employeeList.includes(currentUserDsid)) employeeList.push(currentUserDsid)

    console.log('EmployeeHelper.employeeDsidsForTasks: employeeList', employeeList)

    return employeeList
  },
  directsForDsid: function (dsid: string) {
    if (!dsid) return []
    const employee = this.findEmployee(dsid)
    return (employee.directs || []) as string[]
  }
}

export default EmployeeHelper

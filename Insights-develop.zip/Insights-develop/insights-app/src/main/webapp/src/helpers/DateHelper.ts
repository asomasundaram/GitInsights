const DateHelper = {
  convertEPOCTimestamp: function (epocTime: string | number) {
    if (typeof epocTime == 'string') epocTime = parseInt(epocTime)
    return this.newDate(epocTime)
  },
  newDate: function (dateString: string | number | undefined) {
    if (!dateString || dateString == '' || dateString == 'undefined') return new Date()
    return new Date(dateString)
  },
  shortFormat: function (date: string | Date) {
    if (typeof date == 'string') date = this.newDate(date)
    return date.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })
  },
  numericYear: function (date: string | Date) {
    if (typeof date == 'string') date = this.newDate(date)
    return date.toLocaleDateString('en-US', { year: 'numeric' })
  },
  monthAsShortString: function (date: string | Date) {
    if (typeof date == 'string') date = this.newDate(date)
    return date.toLocaleDateString('default', { month: 'short' })
  },
  realMonth: function (date: string | Date) {
    if (typeof date == 'string') date = this.newDate(date)
    return date.toLocaleDateString('en-US', { month: '2-digit' })
  },
  dateFromPlanMonthAndYear: function (
    planMonth: string | number | undefined,
    planYear: string | number | undefined
  ) {
    // Guard against a non-string date, or an undefined variable converted to
    // a string
    if (
      !planMonth ||
      planMonth == '' ||
      planMonth == 'undefined' ||
      !planYear ||
      planYear == '' ||
      planYear == 'undefined'
    )
      return new Date()
    return this.newDate(planMonth + '/01/' + planYear)
  },
  shortMonth: function (date: string | Date) {
    if (typeof date == 'string') date = this.newDate(date)
    return date.toLocaleDateString('default', { month: 'short' })
  },
  shortMonthNumericYear: function (
    planMonth: string | number | undefined,
    planYear: string | number | undefined
  ) {
    const date = this.dateFromPlanMonthAndYear(planMonth, planYear)
    return date.toLocaleDateString('default', { month: 'short', year: '2-digit' })
  },
  isPastDate: function (date: string) {
    // +new Date - Gives epoch time and 86400 * 1000 is milliseconds of a day
    const planStartEpochTime = +this.newDate(date)
    const currentShortDate = new Date().toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric'
    })
    const currentDateEpochTime = +new Date(currentShortDate)

    if (currentDateEpochTime - planStartEpochTime >= 86400000) {
      return currentShortDate
    }
    return date
  },
  currentDateEpochTime: function () {
    const currentShortDate = new Date().toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric'
    })
    const currentDateEpochTime = +new Date(currentShortDate)
    return currentDateEpochTime
  },
  isDateInThisWeek: function (date: string | Date) {
    const givenDate = new Date(date)
    const firstDayOfWeek = new Date(givenDate.setDate(givenDate.getDate() - givenDate.getDay()))
    const lastDayOfWeek = new Date(firstDayOfWeek)
    lastDayOfWeek.setDate(lastDayOfWeek.getDate() + 6)

    return date >= firstDayOfWeek && date <= lastDayOfWeek
  }
}

export default DateHelper

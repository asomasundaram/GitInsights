<script setup lang="ts">
import { usePlansStore } from '@/stores/plans'
import { computed, ref } from 'vue'
import { useSidebarStore } from '@/stores/sidebar'
import type { TaskAggregate } from '@/classes/Plan'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import DateHelper from '@/helpers/DateHelper'
import SeniorTaskViewCard from '@/components/tasks/SeniorTaskViewCard.vue'
import PlanHelper from '@/helpers/PlanHelper'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
const sidebarStore = useSidebarStore()
const plansStore = usePlansStore()
const isFetchingAggregates = ref(false)
const lastRefresh = ref(0)

const selectedMonth = computed(() => {
  // TODO: Make this dynamic
  const today = new Date()
  today.setDate(1)
  today.setHours(0, 0, 0, 0)
  const thisMonth = new Date(today)
  return DateHelper.shortFormat(thisMonth)
})

const taskAggregates = computed(() => {
  const selectedManager = EmployeeHelper.findEmployee(sidebarStore.selectedManager)
  console.log('taskaggregates', selectedManager)
  // Guard against no direct reports
  if (!selectedManager.directs || selectedManager.directs.length < 1) return []

  // Duplicate directs array to detach from selected manager object
  // Guard against no direct reports
  if (!selectedManager.directs || selectedManager.directs.length < 1) {
    return []
  }
  const directs = PlanHelper.cloneObject(selectedManager.directs)

  const aggregates = plansStore.taskAggregatesFor(directs, selectedMonth.value)
  checkForRefresh(aggregates, directs)

  return aggregates
})

function checkForRefresh(aggregates: TaskAggregate[], directs: string[]) {
  console.log('SeniorTaskView.checkForRefresh: Checking if data needs refreshed...')
  // Check to see if any aggregates need to be refreshed
  const aggregateDsids = aggregates.map((agg: TaskAggregate) => agg.dsid)
  // console.log('SeniorTaskView.checkForRefresh: Existing Aggregates for:', aggregateDsids)

  const missingAggregates = directs.filter((direct: string) => !aggregateDsids.includes(direct))
  // console.log('SeniorTaskView.checkForRefresh: Missing Aggregates for: ', missingAggregates)

  const fiveMinutesAgo = Date.now() - 5 * 60 * 1000

  if (lastRefresh.value > fiveMinutesAgo)
    return console.log('SeniorManagerView.checkForRefresh: Last refresh within 5 minutes')

  // console.log('SeniorTaskView.checkForRefresh: Old aggregate data', oldAggregateData)
  // const needsRefresh = [...missingAggregates, ...oldAggregateData]
  const needsRefresh = [...aggregateDsids, ...missingAggregates]
  if (needsRefresh.length == 0)
    return console.log('SeniorTaskView.checkForRefresh: No need to refresh')
  console.log('SeniorTaskView.checkForRefresh: Refreshing aggregates for:', needsRefresh)
  refreshAggregates(needsRefresh)
}

function refreshAggregates(dsids: string[]) {
  console.log('SeniorTaskView.refreshAggregates: Refreshing aggregates', dsids)
  if (!dsids || dsids.length == 0)
    return console.log('SeniorTaskView.refreshAggregates: No DSIDs to refresh')
  if (isFetchingAggregates.value)
    return console.log('SeniorTaskView.refreshAggregates: Already refreshing...')
  isFetchingAggregates.value = true

  plansStore.refreshtaskAggregatesFor(dsids, selectedMonth.value).then((response) => {
    console.log('SeniorTaskView.refreshAggregates: Aggregates refreshed')
    lastRefresh.value = Date.now()
    isFetchingAggregates.value = false
  })
}
</script>

<template>
  <div class="taskview">
    <header>
      <h3 class="tasks-title">{{ t('tasks_label') }}</h3>
    </header>
    <div class="tasks-cards-sec-div">
      <SeniorTaskViewCard
        v-for="aggregate of taskAggregates"
        :aggregate-data="aggregate"
      ></SeniorTaskViewCard>
    </div>
  </div>
</template>

<style scoped>
.tasks-title {
  color: rgb(0 0 0 / 85%);
  font-size: 34px;
  font-weight: 700;
  letter-spacing: -0.82px;
  line-height: 34px;
}

.tasks-cards-sec-div {
  display: flex;
  flex-wrap: wrap;
}

.taskview {
  padding: 1rem 2.5rem;
}
</style>

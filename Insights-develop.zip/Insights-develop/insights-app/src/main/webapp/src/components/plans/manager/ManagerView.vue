<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { usePlansStore } from '@/stores/plans'
import { useI18n } from 'vue-i18n'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import PlanHelper from '@/helpers/PlanHelper'
import APIHelper from '@/helpers/APIHelper'
import PlanCard from '@/components/plans/manager/PlanCard.vue'
import type { InsightsPlanCard } from '@/types/InsightsTypes'

const props = defineProps({
  dsid: {
    type: String,
    required: true
  },
  selectedPlanType: {
    type: String,
    required: true
  }
})

const orderedPlanTypeData = {
  aiml_planType_documented_coaching: [] as InsightsPlanCard[],
  aiml_planType_action_plan: [] as InsightsPlanCard[],
  aiml_planType_additional_development: [] as InsightsPlanCard[],
  aiml_planType_standard_coaching: [] as InsightsPlanCard[],
  aiml_planType_no_plan: [] as InsightsPlanCard[],
  planType_needs_plan: [] as InsightsPlanCard[]
}

const { t } = useI18n()
const plansStore = usePlansStore()

const cardDataForDirects = computed(() => {
  const directDsids = EmployeeHelper.directsForDsid(props.dsid)
  return PlanHelper.planCardDataForDsids(directDsids)
})

const cardsByPlanType = computed(() => {
  // Clone orderedPlanTypeData so we're not persisting data
  console.log('ManagerView : Inside Cards By Plan Type')
  const orderedPlans = PlanHelper.cloneObject(orderedPlanTypeData) as typeof orderedPlanTypeData
  let filteredCardsByType = {} as typeof orderedPlanTypeData

  cardDataForDirects.value.forEach((directData) => {
    if (!orderedPlans[directData.cardType]) orderedPlans[directData.cardType] = []
    orderedPlans[directData.cardType].push(directData)
    orderedPlans[directData.cardType].sort((plan1, plan2) => {
      const plan1Anayst = EmployeeHelper.fullNameFor(plan1.dsid)
      const plan2Analyst = EmployeeHelper.fullNameFor(plan2.dsid)
      return plan1Anayst.localeCompare(plan2Analyst)
    })
  })

  if (!props.selectedPlanType || props.selectedPlanType === 'none') return orderedPlans

  const currentDate = new Date().getTime()
  for (const planType in orderedPlanTypeData) {
    orderedPlans[planType].forEach((plan: InsightsPlanCard) => {
      // If the filter is set to `pending_completion`, check whether or not the
      // plan card has a current plan before proceeding
      if (props.selectedPlanType == 'pending_completion' && plan.currentPlan) {
        const planEndDate = new Date(plan.currentPlan.planEndDate).getTime()
        const diffTime = planEndDate - currentDate
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
        // If the current plan's due date is within 10 days or in the past,
        // count it as pending completion
        if (diffDays <= 10) {
          if (!filteredCardsByType[planType]) filteredCardsByType[planType] = []
          filteredCardsByType[planType].push(plan)
        }
      } else if (props.selectedPlanType == 'pending_upcoming' && !plan.currentDraft) {
        // If the filter is set to `pending_upcoming`, check whether or not the
        // plan card has a currentDraft. If there is no current draft then the
        // advisor is in a `pending_upcoming` state regardless of the state of
        // their current plan
        if (!filteredCardsByType[planType]) filteredCardsByType[planType] = []
        filteredCardsByType[planType].push(plan)
      }
    })
  }

  return filteredCardsByType
})

const filteredCardLength = computed(() => {
  // Get the total of number of cards matching the filter regardless of their
  // plan type. To do this we get all values, which will return an arrays of
  // plans from all types, and then flatten it into a single array
  return Object.values(cardsByPlanType.value).flat().length
})

onMounted(() => {
  const directs = EmployeeHelper.directsForDsid(props.dsid)
  APIHelper.fetchAndSetPlansFor(directs)
})
</script>

<template>
  <div class="cards" v-for="(cards, planType) in cardsByPlanType" :key="planType">
    <div class="main-title" v-if="cards.length">
      {{
        t('plan_type_header_x_of_plans', {
          planType: t(planType),
          planTypeCount: cards.length,
          totalCount: filteredCardLength
        })
      }}
    </div>
    <div class="clear"></div>
    <div class="team-lead-task">
      <PlanCard
        v-for="card in cards"
        :key="card.dsid"
        :direct="EmployeeHelper.findEmployee(card.dsid)"
        :currentPlan="card.currentPlan"
        :currentDraft="card.currentDraft"
        :lastThreeMonths="plansStore.lastThreeMonths(card.dsid)"
        :completedTasks="PlanHelper.completedTasks(card.currentPlan)"
      />
      <div class="clear"></div>
    </div>
    <div class="clear"></div>
  </div>
</template>

<style scoped>
.main-title {
  padding: 23px 3px 20px;
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 700;
  letter-spacing: -0.34px;
  line-height: 22px;
  opacity: 0.5;
}

.clear {
  clear: both;
}
</style>

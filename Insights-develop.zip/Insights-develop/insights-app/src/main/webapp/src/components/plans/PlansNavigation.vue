<script setup lang="ts">
import { computed, ref, type PropType } from 'vue'
import { useI18n } from 'vue-i18n'
import { Employee } from '@/classes/Employee'

const { t } = useI18n()
const activeTab = ref('current')

const emits = defineEmits(['updateTab', 'update-plan-filter'])

const filterSelection = ref(['none'])
const updatePlanFilter = (event: CustomEvent) => {
  let newFilterValue = event.detail.value
  if (newFilterValue.length == 0) newFilterValue = ['none']
  console.log('Updating Plan Filter:', newFilterValue)
  filterSelection.value = newFilterValue
  // Emit event
  emits('update-plan-filter', filterSelection.value[0])
}

const updateTab = (tabName: string) => {
  activeTab.value = tabName
  emits('updateTab', tabName)
}
const props = defineProps({
  selectedUser: {
    type: Object as PropType<Employee>,
    required: true
  }
})
const isSelectedEmployeeAnalyst = computed(() => {
  if (props.selectedUser.applicationRoleLevel === 'level_10') {
    return true
  }
  return false
})
</script>
<template>
  <div class="plans-filter-row">
    <div class="plan-type-filter">
      <bricks-tab-group visual-style="underline" label="underline" content-fit="fixed">
        <bricks-tab
          active
          @click="updateTab('current')"
          :data-activetab="activeTab === 'current'"
          >{{ t('current_label') }}</bricks-tab
        >
        <bricks-tab
          panel="drafts"
          @click="updateTab('draft')"
          :data-activetab="activeTab === 'draft'"
          >{{ t('drafts_label') }}</bricks-tab
        >
      </bricks-tab-group>
    </div>

    <div class="plans-filters" v-if="activeTab === 'current' && !isSelectedEmployeeAnalyst">
      <bricks-label>{{ t('filter_plans_by_label') }}</bricks-label>
      <bricks-selector
        accessible-title="Plan Filter Box"
        @bricks-selector-change="updatePlanFilter"
        :value="filterSelection"
      >
        <bricks-menu-item value="none">{{ t('none_label') }}</bricks-menu-item>
        <bricks-menu-item value="pending_completion">{{
          t('aiml_pending_completion_label')
        }}</bricks-menu-item>
        <bricks-menu-item value="pending_upcoming">{{
          t('plan_filter_pending_upcoming')
        }}</bricks-menu-item>
      </bricks-selector>
    </div>
  </div>
</template>

<style scoped>
.plans-filter-row {
  display: flex;
  flex-direction: row;
  align-items: start;
  justify-content: space-between;
  padding-top: 1rem;
}

bricks-tab[data-activetab='true'] {
  border-bottom: 2px solid #007aff;
}

bricks-tab {
  --bricks-tab-underline-active-color: #007aff;
}

bricks-tab::part(base)::after {
  width: auto;
}
</style>

<script setup lang="ts">
import { ref, computed, defineProps, defineEmits, type PropType } from 'vue'
import type { InsightsPlanSupportingTask } from '@/types/InsightsTypes'
import { type IBricks } from '@nexus/bricks-vue'
import { usePlansStore } from '@/stores/plans'
import { useI18n } from 'vue-i18n'
import DateHelper from '@/helpers/DateHelper'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import PlanHelper from '@/helpers/PlanHelper'
import type { Plan } from '@/classes/Plan'

const emit = defineEmits(['addNewTask', 'hideNewTaskModal'])
const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  },
  openTaskModal: Boolean
})
const plansStore = usePlansStore()
const openNewTaskModal = ref(false)
const newTask = ref({ taskStatus: 'IN_PROGRESS', taskType: '' } as InsightsPlanSupportingTask)
const taskDueDate = ref(DateHelper.shortFormat(props.planData.planEndDate))
const newTaskDatePicker = ref(null)
const taskLibrary = plansStore.taskLibrary
const { t } = useI18n()

const defaultTaskValidationState = {
  taskDescription: { status: 'valid', message: '' } as IBricks.FieldValidationState,
  taskOwner: { status: 'valid', message: '' } as IBricks.FieldValidationState,
  taskDueDate: { status: 'valid', message: '' } as IBricks.FieldValidationState
}

const newTaskValidation = ref({ ...defaultTaskValidationState })
const assignableEmployees = computed(() => {
  const list = EmployeeHelper.employeeDsidsForTasks(props.planData)

  return list.map((dsid: string) => EmployeeHelper.findEmployee(dsid))
})

function resetValidation() {
  newTaskValidation.value = { ...defaultTaskValidationState }
}

function validateFields() {
  const taskErrors = PlanHelper.validate.task(
    newTask.value,
    props.planData.planStartDate,
    props.planData.planEndDate
  )
  // If task has errors, set errors
  for (let item in newTaskValidation.value) {
    if (Object.keys(taskErrors).length && Object.keys(taskErrors).includes(item)) {
      newTaskValidation.value[item] = {
        status: 'invalid',
        message: taskErrors[item],
        showIcon: true
      }
    } else {
      newTaskValidation.value[item] = {
        status: 'valid',
        message: ''
      }
    }
  }

  const datePicker = newTaskDatePicker.value as HTMLElement | null
  const datePickerInvalid = datePicker ? datePicker.getAttributeNames().includes('invalid') : true
  if (datePickerInvalid) newTaskValidation.value['taskDueDate'] = { status: 'invalid' }
}

function closeNewTaskModal() {
  openNewTaskModal.value = false
  newTask.value = { taskStatus: 'IN_PROGRESS', taskType: '' } as InsightsPlanSupportingTask
  emit('hideNewTaskModal')
  resetValidation()
}

function onFieldChange(field: string, event: CustomEvent) {
  const fieldValue =
    field === 'taskDueDate' ? DateHelper.shortFormat(event.detail.value) : event.detail.value[0]

  newTask.value.id = window.crypto.randomUUID()

  if (field == 'taskCode') {
    let taskCode = event.detail.element.selectedItems[0]?.value
    // if (!taskCode) newTask.value.taskDescription = newValue
    newTask.value.taskDescription = event.detail.element.selectedItems[0]?.textContent
    newTask.value.taskCode = taskCode
  } else {
    newTask.value[field] = fieldValue
  }

  validateFields()
}

function addTask() {
  validateFields()
  if (
    Object.keys(
      PlanHelper.validate.task(
        newTask.value,
        props.planData.planStartDate,
        props.planData.planEndDate
      )
    ).length
  )
    return

  const taskToAdd = { ...newTask.value }
  if (!taskToAdd.taskDueDate) taskToAdd.taskDueDate = DateHelper.shortFormat(taskDueDate.value)
  emit('hideNewTaskModal')
  emit('addNewTask', newTask.value)
}

const inputEvt = (e) => {
  if ((e.ctrlKey || e.metaKey) && (e.keyCode === 91 || e.keyCode === 67)) {
    return true
  }
  e.preventDefault()
  return false
}
</script>
<template>
  <bricks-dialog
    behavior="modal"
    .isOpen="openTaskModal"
    class="supporting-task-new-task-modal"
    @bricks-dialog-close="closeNewTaskModal"
  >
    <strong slot="header">{{ t('add_new_task_label') }}</strong>
    <span slot="body">
      <bricks-label>{{ t('task_description_label') }}</bricks-label>
      <bricks-selector
        :accessible-title="t('select_task_label')"
        class="new-task-selector"
        filter
        hoist
        :value="newTask.taskCode"
        :fieldValidationState="newTaskValidation.taskDescription"
        @bricks-selector-change="onFieldChange('taskCode', $event)"
      >
        <bricks-menu-item v-for="task of taskLibrary" :key="task.taskCode" :value="task.taskCode">
          {{ t(task.taskCode) }}
        </bricks-menu-item>
      </bricks-selector>

      <bricks-label>{{ t('task_owner_label') }}</bricks-label>
      <bricks-selector
        :accessible-title="t('select_task_owner_label')"
        hoist
        class="new-task-selector"
        :value="newTask.taskOwner"
        :fieldValidationState="newTaskValidation.taskOwner"
        @bricks-selector-change="onFieldChange('taskOwner', $event)"
      >
        <bricks-menu-item
          v-for="employee of assignableEmployees"
          :key="employee.dsid"
          :value="employee.dsid"
        >
          {{ employee.fullName() }}
        </bricks-menu-item>
      </bricks-selector>

      <bricks-label>{{ t('task_due_date_label') }}</bricks-label>
      <bricks-date-picker
        .value="taskDueDate"
        :min-date="DateHelper.isPastDate(planData.planStartDate)"
        :max-date="planData.planEndDate"
        ref="newTaskDatePicker"
        @bricks-date-picker-change="onFieldChange('taskDueDate', $event)"
        @input="inputEvt"
        @keydown="inputEvt"
        position="auto"
      />
    </span>
    <bricks-button slot="footer-primary" default visual-style="primary" @bricks-click="addTask">
      {{ t('add_label') }}
    </bricks-button>
    <bricks-button
      slot="footer-secondary"
      @bricks-click="closeNewTaskModal"
      visual-style="secondary"
    >
      {{ t('cancel_label') }}
    </bricks-button>
  </bricks-dialog>
</template>
<style scoped>
bricks-selector {
  --bricks-selector-box-width: 375px;

  margin-bottom: 15px;
}

bricks-selector::part(base) {
  --bricks-selector-box-menu-max-height: 250px;
}

bricks-date-picker {
  --bricks-date-picker-field-width: 375px;

  margin-bottom: 15px;
}

bricks-dialog::part(modal) {
  width: 430px;
  max-height: fit-content;
}

bricks-label::part(label) {
  font-size: 18px;
}

bricks-dialog::part(footer) {
  padding: 0 8px;
  margin-top: 15px;
}
</style>

<script setup lang="ts">
import { ref, computed } from 'vue'
import PlanState from '@/components/plan_view/PlanState.vue'
import PlanHelper from '@/helpers/PlanHelper'
import ArrowUpRight from '../icons/sfsymbols/arrow.up.right.vue'
import ChevronRight from '@/components/icons/sfsymbols/chevron.right.vue'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import { PlanTask } from '@/classes/Plan'
import { useI18n } from 'vue-i18n'
import { usePlansStore } from '@/stores/plans'
import DateHelper from '@/helpers/DateHelper'

/**
 * Will refactor this with API Integration
 * Passed both planData and individual entities for now
 */
const props = defineProps({
  tasks: {
    type: Array<PlanTask>,
    required: true
  },
  filterdTasks: {
    type: Object,
    required: true
  },
  tasksStatusCountByPlan: {
    type: Object,
    required: true
  }
})
const plansStore = usePlansStore()
const { t, d } = useI18n()
const isOpen = ref([] as String[])
const emit = defineEmits(['task-status-change'])

const planStateChange = (status: string, identifier: string) => {
  emit('task-status-change', status, identifier)
}

const taskPlanIds = computed(() => {
  const planIds = [] as string[]
  props.tasks.length &&
    props.tasks.forEach((task) => {
      if (!planIds.includes(task.planId)) {
        planIds.push(task.planId)
      }
    })
  return planIds
})

const getPlanFocusAreaMetrics = computed(() => {
  const planFocusAreaMetrics = {} as object

  plansStore.plans.forEach((plan) => {
    if (taskPlanIds.value.includes(plan.id) && !planFocusAreaMetrics[plan.id]) {
      planFocusAreaMetrics[plan.id] = plan.focusAreaMetrics
    }
  })
  return planFocusAreaMetrics
})

const expandTask = (id: string) => {
  if (isOpen.value.includes(id)) {
    isOpen.value = isOpen.value.filter((i) => i !== id)
    return
  }
  isOpen.value.push(id)
}

const joinFocusAreaMetrics = (planId: string) => {
  const plansKeys = Object.keys(getPlanFocusAreaMetrics.value)
  if (plansKeys.includes(planId)) {
    const metrics = JSON.parse(
      JSON.stringify(getPlanFocusAreaMetrics.value[planId][0].focusAreaMetrics)
    )

    return metrics.length && metrics.map((metric: string) => t(metric)).join(', ')
  }
  return ''
}

const taskStatuses = PlanHelper.taskStatuses()

function planMonthDateObj(planMonth: string, planYear: string) {
  const date = DateHelper.dateFromPlanMonthAndYear(planMonth, planYear)
  return date
}
</script>
<template>
  <tr v-for="task in tasks" :key="task.taskOwnerDsid + Math.random()">
    <td>{{ task.taskDueDate }}</td>
    <td>{{ EmployeeHelper.fullNameFor(task.taskOwnerDsid) }}</td>
    <td>{{ task.taskCode ? t(task.taskCode) : task.taskDescription }}</td>
    <td>
      <PlanState
        @plan-state-change="planStateChange"
        :identifier="task.taskId"
        :status="taskStatuses"
        :activeState="taskStatuses[task.taskStatus]"
        :isStatusCompleted="PlanHelper.disableStatus(task.taskStatus)"
      />
    </td>
    <td>
      <router-link
        :to="{
          name: 'plans',
          params: { employee: task.taskOwnerDsid },
          query: { plan: task.planId }
        }"
      >
        <ArrowUpRight />
        {{ d(new Date(planMonthDateObj(task.planMonth, task.planYear)), 'monthAndYear') }} -
        {{ t(task.planType) }}
      </router-link>
    </td>
    <td>
      <ChevronRight
        :class="{
          'expand-task-up': isOpen.includes(task.taskId),
          'expand-task-down': !isOpen.includes(task.taskId)
        }"
        @click="expandTask(task.taskId)"
      />
    </td>
    <div class="task-description-section" v-show="isOpen.includes(task.taskId)">
      <div class="task-details">
        <div class="focus-areas">
          <p class="heading">{{ t('focus_areas_label') }}</p>
          <p>
            {{ joinFocusAreaMetrics(task.planId) }}
          </p>
        </div>
        <div class="tasks">
          <p class="heading">{{ t('tasks_label') }}</p>
          <p>
            {{
              t('count_of_total_tasks_completed', {
                count: tasksStatusCountByPlan[task.planId][task.taskStatus],
                total: tasksStatusCountByPlan[task.planId].TOTAL_NO_OF_TASKS
              })
            }}
          </p>
        </div>
      </div>
    </div>
  </tr>
</template>
<style scoped>
tr {
  display: flex;
  width: 99%;
  flex-wrap: wrap;
  align-items: center;
  border-radius: 5px;
  margin-bottom: 15px;
  background-color: #fff;
  box-shadow: rgb(99 99 99 / 20%) 0 1px 6px 2px;
}

td {
  padding: 12px 23px;
  font-size: 14px;
}

td:first-child {
  width: 10%;
  border-bottom-left-radius: 8px;
  border-top-left-radius: 8px;
}

td:nth-child(2) {
  width: 18%;
}

td:nth-child(3) {
  width: 28%;
}

td:nth-child(4) {
  width: 15%;
}

td:nth-child(5) {
  width: 20%;
}

td:not(:first-child) {
  padding-left: 0;
}

td:nth-child(6) {
  width: 9%;
  padding-right: 27px;
  border-bottom-right-radius: 8px;
  border-top-right-radius: 8px;
  text-align: right;
}

a {
  text-decoration: none;
}

.icon {
  width: 12px;
  fill: #007aff;
}

.expand-task-up {
  width: 10px;
  transform: rotate(-90deg);
}

.expand-task-down {
  width: 10px;
  transform: rotate(90deg);
}

.task-description-section {
  width: 100%;
  padding: 15px 0;
  border-top: 1px solid #979797;
  margin: 0 25px;
}

.task-details {
  display: flex;
  margin-left: 8.5%;
}

.focus-areas {
  margin-right: 100px;
}

.task-details p {
  color: #3a3a3a;
  font-size: 14px;
}

.heading {
  font-weight: bold;
}

@media screen and (width <= 1480px) {
  td {
    padding: 12px 10px;
    font-size: 14px;
  }

  td:first-child {
    width: 14%;
  }

  td:nth-child(3) {
    width: 24%;
  }

  td:nth-child(4) {
    width: 18%;
  }

  td:nth-child(5) {
    width: 22%;
  }

  td:nth-child(6) {
    width: 4%;
    padding-right: 16px;
  }

  bricks-menu-button {
    --bricks-menu-button-box-width: 120px;
  }
}
</style>

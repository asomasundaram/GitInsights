<script setup lang="ts">
import { computed, type PropType } from 'vue'
import { type PlanAggregate } from '@/classes/Plan'
import { useI18n } from 'vue-i18n'
import Avatar from '@/components/icons/Avatar.vue'
import EmployeeHelper from '@/helpers/EmployeeHelper'

const { t } = useI18n()

const props = defineProps({
  aggregateData: {
    type: Object as PropType<PlanAggregate>,
    required: true
  }
})

const managerData = computed(() => {
  const maestroPerson = EmployeeHelper.findEmployee(props.aggregateData.dsid)
  return maestroPerson
})

// Create a normalized percentage of closed plans.
// The Bricks Progress Bar does not round percentages, so 5/7 plans will show
// as 71.42857142857143% instead of rounding to 71 or 72%. We are manually
// rounding here to ensure we can control the decimal places.
const normalizedClosedPercentage = computed(() => {
  const aggregateData = props.aggregateData
  const percentage = parseInt(aggregateData.completedPlans) / parseInt(aggregateData.totalPlans)
  const normalizedPercentage = percentage * 100
  const roundedPercentage = Math.round(normalizedPercentage)
  return roundedPercentage
})
</script>
<template>
  <div class="teamlead-item">
    <div class="senior-team-data">
      <div class="team-name-data">
        <Avatar :employee="managerData" slot="trigger" />
        <p class="team-name">{{ managerData.fullName() }}</p>
        <p class="team-role" :alt="managerData.siteName">{{ managerData.siteName }}</p>
        <p class="team-role">
          {{ t('total_headcount_label', { count: managerData.directs?.length || 0 }) }}
        </p>
      </div>
      <div class="plan-data">
        <p class="team-plan-title">{{ t('total_plans_label') }}</p>
        <p class="team-plan-count">{{ aggregateData.totalPlans }}</p>
      </div>
    </div>
    <div v-for="(value, key) of aggregateData.planTypes" class="plan-data-details">
      <p class="plan-data-no">{{ value }}</p>
      <p class="plan-data-name">{{ t(key) }}</p>
    </div>
    <p class="closed-plan-title">{{ t('closed_plans_label') }}</p>
    <bricks-progress-bar
      variant="determinate"
      :value="normalizedClosedPercentage"
      maxValue="100"
      showLabel="true"
      class="progress-bar"
    ></bricks-progress-bar>
    <router-link
      :to="{
        name: 'plans',
        params: { employee: aggregateData.dsid }
      }"
      class="view-team-link"
    >
      {{ t('view_team_label') }}</router-link
    >
  </div>
</template>
<style scoped>
.senior-team-data {
  display: flex;
  justify-content: space-between;
  padding-bottom: 12px;
  border-bottom: 1px solid rgb(151 151 151 / 50%);
}

.img-avatar {
  width: 55px;
  height: 55px;
  border-radius: 50%;
  background-color: lightgrey;
}

.team-plan-count {
  color: rgb(0 0 0 / 85%);
  font-size: 34px;
  font-weight: 600;
  letter-spacing: 0.54px;
  line-height: 34px;
  text-align: right;
}

.team-role {
  padding-bottom: 0.5px;
  color: rgb(0 0 0 / 85%);
  font-size: 12px;
  font-weight: 500;
  letter-spacing: 0.19px;
  line-height: 26px;
  opacity: 0.5;
  word-wrap: none;
}

.team-plan-title {
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 400;
  letter-spacing: 0.22px;
  line-height: 26px;
  opacity: 0.5;
}

.plan-data-name {
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 400;
  letter-spacing: 0.22px;
  line-height: 34px;
  opacity: 0.5;
}

.plan-data-no {
  padding-right: 11.5px;
  color: rgb(0 0 0 / 85%) !important;
  font-size: 24px;
  font-weight: 400;
  letter-spacing: 0.38px;
  line-height: 34px;
  text-align: center;
}

.plan-data-details {
  display: flex;
  padding-top: 14px;
}

.progress-bar {
  --bricks-progress-bar-foreground-color: #9dca97;
  --bricks-progress-bar-bg-color: #eee;
  --bricks-progress-bar-height: 12px;

  margin-top: 0;
}

.view-team-link {
  display: block;
  color: #007aff;
  font-size: 16px;
  font-weight: 400;
  letter-spacing: 0.26px;
  line-height: 26px;
  text-align: right;
  text-decoration: none;
}

.team-name-data {
  width: 70%;
}

.plan-data {
  width: 30%;
}
</style>

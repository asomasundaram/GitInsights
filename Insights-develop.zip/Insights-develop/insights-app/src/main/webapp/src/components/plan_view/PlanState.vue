<script setup lang="ts">
import { computed, ref } from 'vue'
import Check from '@/components/icons/sfsymbols/check.vue'

const props = defineProps({
  activeState: String,
  status: Object,
  identifier: String,
  isStatusCompleted: Boolean,
  planStatus: String,
  isEditing: Boolean
})

const emit = defineEmits(['planStateChange'])
const planState = ref(props.activeState)
function planStateSelect(e: CustomEvent) {
  planState.value = e.detail.value.textContent.trim()

  // Emit data to any Parent where it is needed
  emit('planStateChange', e.detail.value.value, props.identifier)
}

const isPlanStatusCompleted = computed(() => props.planStatus === 'COMPLETED')
const statusColorClassName = computed(() =>
  planState.value?.replace(/[_ ]/g, '').toLocaleLowerCase()
)
const isStatusInEditMode = computed(() => !props.isEditing && props.planStatus === 'COMPLETED')
</script>

<template>
  <template v-if="isPlanStatusCompleted">
    <p :class="['task-status-btn', { 'task-completed': isPlanStatusCompleted }]">
      {{ planState }}
    </p>
  </template>
  <template v-else>
    <bricks-menu-button>
      <bricks-button
        slot="trigger"
        variation="standard"
        size="small"
        visual-style="alternative"
        caret="true"
        :class="['bricks-button', `bricks-${statusColorClassName}`]"
        >{{ planState }}
      </bricks-button>
      <bricks-menu @bricks-menu-select="planStateSelect">
        <template v-for="(state, key) in status" :key="key">
          <bricks-menu-item .value="key" :disabled="isStatusInEditMode">
            <span class="box-check">
              <Check
                :class="{ 'disable-check': isStatusInEditMode }"
                v-if="state === props.activeState"
              />
            </span>
            {{ state }}
          </bricks-menu-item>
        </template>
      </bricks-menu>
    </bricks-menu-button>
  </template>
</template>

<style scoped>
@import url('@/assets/variables.css');

bricks-menu-button {
  --bricks-menu-button-box-width: 170px;
}

.bricks-button {
  --bricks-button-alternative-border-color: transparent;
  --bricks-button-alternative-hover-border-color: transparent;
}

.bricks-button.bricks-inprogress {
  --bricks-button-alternative-bg-color: var(--action-plan-bg-color);
  --bricks-button-alternative-hover-bg-color: var(--action-plan-bg-color);
}

.bricks-button.bricks-cancelled {
  --bricks-button-alternative-bg-color: var(--documented-coaching-bg-color);
  --bricks-button-alternative-hover-bg-color: var(--documented-coaching-bg-color);
}

.bricks-button.bricks-completed {
  --bricks-button-alternative-bg-color: var(--task-complete-bg-color);
  --bricks-button-alternative-hover-bg-color: var(--task-complete-bg-color);
}

.bricks-button.bricks-onhold {
  --bricks-button-alternative-bg-color: var(--task-on-hold-bg-color);
  --bricks-button-alternative-hover-bg-color: var(--task-on-hold-bg-color);
}

.bricks-button.bricks-incomplete {
  --bricks-button-alternative-bg-color: var(--task-in-complete-bg-color);
  --bricks-button-alternative-hover-bg-color: var(--task-in-complete-bg-color);
}

bricks-button.bricks-incomplete::part(caret),
bricks-button.bricks-incomplete::part(title) {
  color: black;
}

bricks-button::part(base) {
  width: 140px;
  padding: 2px 15px 3px;
  border-radius: 15px;
}

bricks-button::part(title) {
  padding-right: 5px;
  color: white;
}

bricks-button::part(caret) {
  color: white;
}

.box-check {
  display: inline-block;
  width: 16px;
  height: 16px;
}

.disable-check {
  fill: rgb(134 134 139);
}

@media screen and (width <= 1480px) {
  bricks-button::part(base) {
    width: 120px;
    padding: 2px 8px 3px;
  }
}
</style>

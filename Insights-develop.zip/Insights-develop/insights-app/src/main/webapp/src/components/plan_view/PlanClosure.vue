<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { usePlansStore } from '@/stores/plans'
import { type Plan } from '@/classes/Plan'
import PlanState from './PlanState.vue'
import APIHelper from '@/helpers/APIHelper'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import type { InsightsPlanSupportingTask } from '@/types/InsightsTypes'
import { useI18n } from 'vue-i18n'
import PlanHelper from '@/helpers/PlanHelper'

const props = defineProps({
  openPlanClosureModal: Boolean,
  dsId: String,
  planStatus: String
})
const emit = defineEmits(['hidePlanClosureModal'])
const route = useRoute()
const changedTaskStatuses = ref({})
const planClosureRating = ref(['none'])
const planClosureComments = ref('')
const errorNotifier = ref()
const toastMessage = ref('')
const isUpdateSuccessful = ref(false)
const bricksDialogRef = ref(null as HTMLBricksDialogElement | null)
const plansStore = usePlansStore()
const { t } = useI18n()
const router = useRouter()

const planId = route.query.plan as string
const currentPlan = computed(() => plansStore.findPlan(planId))

const tasks = computed(() => {
  // Make sure to call tasks whenever the modal is `open`
  if (currentPlan.value && props.openPlanClosureModal) {
    return currentPlan.value.tasks
  }
  return
})

const hide = () => {
  emit('hidePlanClosureModal')
  // On close of the modal when the update is unsuccessful, revert the state of the component to initial
  if (!isUpdateSuccessful.value) {
    planClosureComments.value = ''
    planClosureRating.value = ['none']
  }
}

const planStateChange = (status: string, identifier: string) => {
  changedTaskStatuses.value[identifier] = status
}

const handleCommentsChange = (e: CustomEvent) => {
  planClosureComments.value = e.detail.value
}

function handleRatingChange(e: CustomEvent) {
  planClosureRating.value = e.detail.value
}

function mapChangedTaskStatusToStoreTasks() {
  const tasksCopy = [...(tasks.value as Array<InsightsPlanSupportingTask>)]
  tasksCopy.forEach((task) => {
    if (Object.keys(changedTaskStatuses.value).includes(task.taskCode as string)) {
      task.taskStatus = changedTaskStatuses.value[task.taskCode as string]
    }
  })

  return tasksCopy
}

function errorCbFn(message: string) {
  isUpdateSuccessful.value = false
  toastMessage.value = message
  invokeNotification()
}

const updatePlan = () => {
  const updatedTasks = mapChangedTaskStatusToStoreTasks()
  // Spread the currentPlan from PlanStore in to a new object, which avoids
  // mutating the original source plan in the Store
  const updatedPlan = {
    ...currentPlan.value,
    tasks: updatedTasks,
    closureRating: planClosureRating.value[0],
    closureComments: planClosureComments.value,
    planState: props.planStatus as string
  } as Plan

  console.log('PlanClosure.updatePlan: Updated Plan Data', updatedPlan)
  const deletePlanParams = {
    id: planId,
    lastModifiedBy: updatedPlan.lastModifiedBy,
    lastModifiedTime: updatedPlan.lastModifiedTime,
    closureRating: planClosureRating.value[0],
    closureComments: planClosureComments.value
  }

  if (updatedPlan.planState === 'CANCELLED') {
    APIHelper.plans
      .deletePlan(deletePlanParams)
      .then((planId: string | undefined) => {
        emit('hidePlanClosureModal', true)
        isUpdateSuccessful.value = true
        toastMessage.value = t('plan_deleted_label')
        invokeNotification()
        router.push({
          name: 'plans',
          params: { employee: updatedPlan.planDsid },
          force: true,
          replace: true
        })
      })
      .catch((error: Error) => {
        errorCbFn(error.message)
      })
  } else {
    APIHelper.plans
      .saveOrUpdatePlan(updatedPlan)
      .then((planId: string | undefined) => {
        isUpdateSuccessful.value = true
        toastMessage.value = t('updates_saved_label')

        // Update the plan in the PlansStore to reflect saved changes
        plansStore.updatePlan(updatedPlan.id, updatedPlan)
        invokeNotification()
        bricksDialogRef.value?.hide()
        emit('hidePlanClosureModal', true)
      })
      .catch((error: Error) => {
        errorCbFn(error.message)
      })
  }
}

function invokeNotification() {
  errorNotifier.value.queue()
}

const taskStatuses = PlanHelper.taskStatuses()
const selectedPlanStatus = computed(() =>
  props.planStatus === 'CANCELLED' ? t('task_status_cancelled') : t('task_status_complete')
)
</script>
<template v-if="openPlanClosureModal">
  <bricks-dialog
    behavior="modal"
    .isOpen="openPlanClosureModal"
    @bricks-dialog-close="hide"
    max-content-size="large"
    ref="bricksDialogRef"
  >
    <span slot="body">
      <h4 class="title">{{ t('mark_plan_as_label', { status: ` ${selectedPlanStatus}` }) }}</h4>
      <div class="each-plan-section">
        <p class="sub-title">{{ t('supporting_tasks_label') }}</p>
        <div v-for="task in tasks" :key="task.taskCode" class="each-plan">
          <PlanState
            @plan-state-change="planStateChange"
            :identifier="task.taskCode"
            :status="taskStatuses"
            :activeState="taskStatuses[task.taskStatus]"
            class="plan-state"
          />
          <p class="description">{{ task.taskCode ? t(task.taskCode) : task.taskDescription }}</p>
          <p class="task-owner">{{ EmployeeHelper.fullNameFor(task.taskOwner) }}</p>
          <p>{{ task.taskDueDate }}</p>
        </div>
      </div>
      <div class="rating-section">
        <p class="sub-title">{{ t('plan_rating_label') }}</p>
        <bricks-selector
          :accessible-title="t('plan_rating_label')"
          .value="planClosureRating"
          @bricks-selector-change="handleRatingChange"
        >
          <bricks-menu-item value="none" disabled>{{ t('select_one_label') }}</bricks-menu-item>
          <bricks-menu-item value="aiml_planClosureRating_meets_expectations">
            {{ t('aiml_planClosureRating_meets_expectations') }}
          </bricks-menu-item>
          <bricks-menu-item value="aiml_planClosureRating_needs_improvement">
            {{ t('aiml_planClosureRating_needs_improvement') }}
          </bricks-menu-item>
        </bricks-selector>
      </div>
      <bricks-text-area
        label="Standard"
        :place-holder-text="t('additional_comments_optional_label')"
        resize="both"
        @bricks-text-area-change="handleCommentsChange"
      ></bricks-text-area>
    </span>
    <bricks-button slot="footer-primary" default visual-style="primary" @bricks-click="updatePlan">
      {{ t('save_label') }}
    </bricks-button>
    <bricks-button slot="footer-secondary" visual-style="secondary" @bricks-click="hide">
      {{ t('cancel_label') }}
    </bricks-button>
  </bricks-dialog>
  <div class="component-holder">
    <bricks-toast
      class="regular-toast top-right"
      :class="{ 'error-updating': !isUpdateSuccessful }"
      ref="errorNotifier"
      duration="4000"
    >
      {{ toastMessage }}
    </bricks-toast>
  </div>
</template>

<style scoped>
.rating-section .sub-title,
.each-plan-section .sub-title {
  padding-bottom: 0;
  margin: 20px 0 5px;
  color: #3a3a3a;
  font-size: 1.125rem;
}

.each-plan {
  display: flex;
  align-items: center;
  padding: 5px 20px;
  border-radius: 5px;
  margin-bottom: 10px;
  box-shadow: rgb(99 99 99 / 20%) 0 1px 6px 2px;
}

.each-plan p:not(:last-child) {
  margin-right: 80px;
}

.plan-state {
  margin-right: 70px;
}

.rating-section {
  margin-top: 30px;
}

.description {
  width: 500px;
}

.task-owner {
  width: 250px;
}

bricks-dialog::part(modal) {
  max-height: 700px;
}

bricks-dialog {
  --bricks-dialog-width: 800px;
}

bricks-selector {
  --bricks-selector-box-width: 300px;
}

bricks-text-area {
  margin-top: 5px;

  --bricks-text-area-width: 100%;
}

bricks-text-area::part(base) {
  border-radius: 5px;
}
</style>

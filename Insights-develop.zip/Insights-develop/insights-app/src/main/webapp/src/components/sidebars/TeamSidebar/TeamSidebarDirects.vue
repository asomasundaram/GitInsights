<script setup lang="ts">
import { computed } from 'vue'
import TeamSidebarSection from './TeamSidebarSection.vue'
import { Employee } from '@/classes/Employee'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const props = defineProps({
  collapsed: Boolean,
  activeEmployees: {
    type: Array<Employee>,
    default: null
  },
  inactiveEmployees: {
    type: Array<Employee>,
    default: null
  },
  selectedEmployee: String
})

const activeSubheader = computed(() => t('active_count', { count: props.activeEmployees.length }))

const inactiveSubheader = computed(() =>
  t('inactive_count', { count: props.inactiveEmployees.length })
)

const showInactive = computed(() => props.inactiveEmployees.length > 0)

defineEmits(['update-selected-employee'])
</script>

<template>
  <TeamSidebarSection
    :collapsed="collapsed"
    :directs="activeEmployees"
    :sectionHeader="activeSubheader"
    :selectedEmployee="selectedEmployee"
    @update-sidebar-selection="(dsid: string) => $emit('update-selected-employee', dsid)"
  />
  <div class="team-inactive-section">
    <TeamSidebarSection
      :collapsed="collapsed"
      :directs="inactiveEmployees"
      :sectionHeader="inactiveSubheader"
      :selectedEmployee="selectedEmployee"
      @update-sidebar-selection="(dsid: string) => $emit('update-selected-employee', dsid)"
      v-if="showInactive"
    />
  </div>
</template>

<style scoped>
.team-inactive-section {
  border-top: solid 1px #979797;
  margin-top: 12px;
}
</style>

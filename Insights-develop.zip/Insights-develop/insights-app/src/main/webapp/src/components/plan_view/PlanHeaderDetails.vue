<script setup lang="ts">
import { ref, computed, type PropType, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import DateHelper from '@/helpers/DateHelper'
import { Plan } from '@/classes/Plan'
import PlanState from './PlanState.vue'
import PlanClosure from './PlanClosure.vue'
import ChevronRight from '../icons/sfsymbols/chevron.right.vue'
import PlanHelper from '@/helpers/PlanHelper'
import { usePlansStore } from '@/stores/plans'
import type { InsightsPlanSupportingTask } from '@/types/InsightsTypes'
import { useEmployeeStore } from '@/stores/employee'

const route = useRoute()

const emit = defineEmits(['save-plan-view-flag', 'cancel-plan-update'])
const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  },
  lastThreeMonths: Array<Plan>,
  tasksInEditMode: {
    type: Array,
    required: true
  },
  individualTaskSaveFlag: {
    type: Boolean,
    required: true
  },
  userCanUpdatePlan: {
    type: Boolean,
    required: true
  }
})

/**
 * There might be errors at `update` and we need the initial plan state in that case to revert.
 * And there's no DRAFT status, so we need to mark it as IN_PROGRESS
 */
let INITIAL_PLANSTATE =
  props.planData.planState === 'DRAFT' ? 'IN_PROGRESS' : (props.planData.planState as string)

const planState = ref(INITIAL_PLANSTATE)
const openPlanClosureModal = ref(false)
const employeeRefData = ref({} as { [key: string]: any })
const showSpinner = ref(false)
const errorNotifier = ref()
const toastMessage = ref('')
const isUpdateSuccessful = ref(false)
const selectedPlanEndDate = ref(props.planData.planEndDate)
const planEndDateChanged = ref(false)
const planEndDateRef = ref(null as HTMLBricksDatePickerElement | null)
const showPlanEndDateDatePicker = ref(false)
const { t, d } = useI18n()
const plansStore = usePlansStore()
const employeeStore = useEmployeeStore()

const planTitle = computed(() => {
  const planDate = DateHelper.dateFromPlanMonthAndYear(
    props.planData.planMonth,
    props.planData.planYear
  )
  const dateString = d(planDate, 'monthAndYear')
  return dateString + ' - ' + t(props.planData.planType)
})

const employeeData = computed(() => {
  const employee = EmployeeHelper.findEmployee(props.planData.planDsid)
  return (employeeRefData.value = employee)
})

const employeeFullName = computed(() => {
  return EmployeeHelper.fullNameFor(props.planData.planDsid)
})

const lastThreeMonthsData = computed(() => {
  return props.lastThreeMonths?.map((plan) => t(`${plan.planType}_short`))
})

const originalTaskData = ref(PlanHelper.cloneObject(props.planData.tasks))

// originalTaskData will not update if individualTaskSaveFlag changes, so, we need to watch the flag for updates.
watch(
  () => props.individualTaskSaveFlag,
  (value) => {
    if (value) {
      originalTaskData.value = PlanHelper.cloneObject(props.planData.tasks)
    }
  },
  { immediate: true }
)

const tasksDidChange = computed(() => {
  const originalTasks = originalTaskData.value
  const currentTasks = props.planData?.tasks

  // Quick check to see if anything has been added or removed
  if (originalTasks.length !== currentTasks.length) return true

  const originalTaskUUIDs = originalTasks.map((task: InsightsPlanSupportingTask) => task.id)
  if (currentTasks) {
    for (let task of currentTasks) {
      // Check if a task has been added that doesn't exist in the original array
      if (!originalTaskUUIDs.includes(task.id)) return true

      const originalData = originalTasks.find((ot: InsightsPlanSupportingTask) => ot.id == task.id)
      // Check if data is not present or check for individual task field and return if there's change
      if (!originalData) return true
      if (originalData.taskDueDate !== task.taskDueDate) return true
      if (originalData.taskOwner !== task.taskOwner) return true
      if (originalData.taskStatus !== task.taskStatus) return true
      if (originalData.taskCode !== task.taskCode) return true
    }
  }
  return false
})

// Assuming the data is needed in Parent, emitted an event from Child
const planStateChange = (status: string) => {
  planState.value = status
  if (status === 'CANCELLED' || status === 'COMPLETED') openPlanClosureModal.value = true
}

const hidePlanClosureModal = (updateSuccessful: Boolean | undefined) => {
  openPlanClosureModal.value = false

  // If the update fails for some reason, restore previous `planState`
  if (!updateSuccessful) planState.value = INITIAL_PLANSTATE
}

function savePlan() {
  const originalPlanData = PlanHelper.cloneObject(props.planData)
  let planData: Plan
  if (selectedPlanEndDate.value != originalPlanData.planEndDate) {
    planData = {
      ...props.planData,
      planEndDate: selectedPlanEndDate.value
    } as Plan
  } else {
    planData = props.planData as Plan
  }
  if (planData) {
    plansStore
      .updatePlanData(planData)
      .then(() => {
        showSpinner.value = false
        isUpdateSuccessful.value = true
        toastMessage.value = t('updates_saved_label')
        if (tasksDidChange) {
          emit('save-plan-view-flag', true)
          // Keep `originalTaskData` in sync with updated `planData.tasks` if success
          originalTaskData.value = PlanHelper.cloneObject(props.planData.tasks)
        }
        if (selectedPlanEndDate.value != originalPlanData.planEndDate) {
          planEndDateChanged.value = false
          showPlanEndDateDatePicker.value = false
          plansStore.updatePlan(planData.id, planData)
        }
        invokeNotification()
      })
      .catch((error: Error) => {
        showSpinner.value = false
        isUpdateSuccessful.value = false
        toastMessage.value = error.message
        if (tasksDidChange) {
          emit('save-plan-view-flag', false)
        }
        invokeNotification()
      })
  }
}

function invokeNotification() {
  errorNotifier.value.queue()
}

function onDateChange(e: CustomEvent) {
  if (!planEndDateRef.value?.invalid) {
    selectedPlanEndDate.value = DateHelper.shortFormat(e.detail.value)

    if (selectedPlanEndDate.value !== props.planData.planEndDate) {
      planEndDateChanged.value = true
    } else {
      planEndDateChanged.value = false
    }
  }
}

function showPlanEndDateDatePickerFn() {
  if (props.userCanUpdatePlan) {
    showPlanEndDateDatePicker.value = true
  }
}

function cancelPlanUpdate() {
  showPlanEndDateDatePicker.value = false
  planEndDateChanged.value = false
  selectedPlanEndDate.value = props.planData.planEndDate
  emit('cancel-plan-update', true)
}

const planStatuses = PlanHelper.planStatuses()
</script>
<template>
  <section class="plan-header-section">
    <div class="top-header">
      <div class="left-section">
        <router-link
          :to="{
            name: 'plans',
            params: { employee: route.params.employee }
          }"
        >
          <bricks-button
            variation="icon-only"
            size="medium"
            :accessible-title="t('back_to_plans_label')"
            class="plan-header-back-button"
          >
            <bricks-icon slot="icon">
              <ChevronRight />
            </bricks-icon>
          </bricks-button>
        </router-link>
        <PlanState
          @plan-state-change="planStateChange"
          :status="planStatuses"
          :activeState="planState && planStatuses[planState]"
          :key="planState"
          :plan-status="planState"
          :isStatusCompleted="PlanHelper.disableStatus(INITIAL_PLANSTATE)"
        />
      </div>
      <div class="right-section">
        <bricks-date-picker
          v-if="showPlanEndDateDatePicker"
          visual-style="floating"
          :label="t('end_date_label')"
          .value="selectedPlanEndDate"
          :min-date="props.planData.planEndDate"
          @bricks-date-picker-change="onDateChange"
          ref="planEndDateRef"
          position="auto"
        />
        <template v-if="tasksDidChange || planEndDateChanged">
          <bricks-button visual-style="primary" @bricks-click="savePlan">
            {{ t('update_plan_label') }}
          </bricks-button>
          <bricks-button visual-style="secondary" @bricks-click="cancelPlanUpdate">
            {{ t('cancel_label') }}
          </bricks-button>
        </template>
      </div>
    </div>
    <h2 class="title">
      {{ planTitle }}
    </h2>
    <div class="container-fluid">
      <div class="row">
        <div class="col">
          <h5>{{ t('aiml_analyst_label') }}</h5>
          <p>{{ employeeFullName }}</p>
          <p class="sub-text">
            {{ employeeData?.roleName }}, {{ employeeData?.locale.toUpperCase() }}
          </p>
        </div>
        <div class="col">
          <h5>{{ t('start_date_label') }}</h5>
          <p class="fw-bold">{{ d(DateHelper.newDate(planData.planStartDate)) }}</p>
        </div>
        <div class="col">
          <h5>{{ t('end_date_label') }}</h5>
          <div class="end-date-wrapper">
            <p class="fw-bold">{{ d(DateHelper.newDate(planData.planEndDate)) }}</p>
            <bricks-button
              v-if="planData.planState !== 'COMPLETED' && userCanUpdatePlan"
              visual-style="tertiary"
              :accessible-title="t('edit_label')"
              class="'bricks-button"
              :class="{ 'disable-edit': showPlanEndDateDatePicker }"
              :disabled="showPlanEndDateDatePicker"
              @bricks-click="showPlanEndDateDatePickerFn"
              >{{ t('edit_label') }}</bricks-button
            >
          </div>
        </div>
        <div class="col">
          <h5>{{ t('aiml_last_three_months_label') }}</h5>
          <div class="three-months-section">
            <template v-for="eachData in lastThreeMonthsData" :key="eachData">
              <p :class="['plan-color-' + eachData.toLocaleLowerCase()]">{{ eachData }}</p>
            </template>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid focus-area-section">
      <div class="row">
        <div class="col-3">
          <h5>{{ t('plan_type_label') }}</h5>
          <p>{{ t(planData.planType) }}</p>
        </div>
        <div
          class="col-3"
          v-for="focusData in planData.focusAreaMetrics"
          :key="focusData.focusArea"
        >
          <h5>{{ t('focus_area_label') }}</h5>
          <p>{{ t(focusData?.focusArea) }}</p>
          <template v-for="(metrice, index) in focusData?.focusAreaMetrics" :key="metrice">
            <span class="sub-text">
              {{ t(metrice) }}{{ focusData?.focusAreaMetrics.length !== index + 1 ? ', ' : '' }}
            </span>
          </template>
        </div>
      </div>
    </div>
  </section>
  <PlanClosure
    :open-plan-closure-modal="openPlanClosureModal"
    :ds-id="employeeData.dsid"
    :plan-status="planState"
    @hide-plan-closure-modal="hidePlanClosureModal"
  />
  <bricks-spinner size="44" fullScreen isOverlay v-if="showSpinner"></bricks-spinner>
  <div class="component-holder">
    <bricks-toast
      class="regular-toast top-right"
      :class="{ 'error-updating': !isUpdateSuccessful }"
      ref="errorNotifier"
      duration="4000"
    >
      {{ toastMessage }}
    </bricks-toast>
  </div>
</template>

<style scoped>
.plan-header-back-button {
  margin-right: 15px;
  transform: rotate(180deg);
}

.plan-header-section .container-fluid {
  padding: 0;
  margin-top: 10px;
}

.container-fluid + .container-fluid {
  margin-top: 25px;
}

.focus-area-section .col-3 {
  margin-bottom: 15px;
}

.plan-header-section h5 {
  margin-bottom: 0;
  color: #a09f9f;
  font-size: 12px;
  font-weight: bold;
}

.three-months-section {
  display: flex;
}

.three-months-section p + p {
  margin-left: 7px;
}

.plan-header-section .three-months-section p {
  width: 38px;
  height: 38px;
  padding: 7px;
  border-radius: 100%;
  margin-top: 5px;
  font-weight: bold;
  text-align: center;
}

.plan-header-section .col p,
.plan-header-section .col-3 p {
  color: #3a3a3a;
  font-size: 14px;
}

bricks-menu-button {
  --bricks-menu-button-box-width: 170px;
}

.title {
  margin-top: 15px;
  font-size: 1.5rem;
}

.sub-text {
  color: #3a3a3a;
  opacity: 0.6;
}

.top-header,
.top-header .left-section {
  display: flex;
}

.top-header {
  align-items: center;
}

.top-header .right-section {
  display: flex;
  align-items: center;
  margin-left: auto;
}

.right-section bricks-date-picker {
  margin-right: 20px;
}

.end-date-wrapper {
  display: flex;
  align-items: center;
}

.end-date-wrapper bricks-button {
  margin-left: 15px;
}

.right-section bricks-button + bricks-button {
  margin-left: 15px;
}

.disable-edit::part(base) {
  opacity: 0.5;
}

.end-date-wrapper bricks-button::part(base) {
  padding: 0;
  border: none;
  background-color: transparent;
  color: red;
  text-decoration: none;
}

.end-date-wrapper bricks-button::part(base):hover,
.end-date-wrapper bricks-button::part(base):active {
  padding: 0;
  border: none;
  background-color: transparent;
}
</style>

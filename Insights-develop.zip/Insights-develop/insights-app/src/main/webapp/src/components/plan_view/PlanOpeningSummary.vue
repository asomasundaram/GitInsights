<script setup lang="ts">
import { type PropType } from 'vue'
import { Plan } from '@/classes/Plan'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

defineProps({
  planData: Object as PropType<Plan>
})
</script>

<template>
  {{ planData?.planNotes }}
</template>

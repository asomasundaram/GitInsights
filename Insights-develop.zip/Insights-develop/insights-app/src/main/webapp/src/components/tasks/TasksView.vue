<script setup lang="ts">
import { onUnmounted, ref, computed, onMounted, watch } from 'vue'
import { useSidebarStore } from '@/stores/sidebar'
import Triangle from '@/components/icons/sfsymbols/triangle.vue'
import IndividualTask from './IndividualTask.vue'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import TaskCard from './TaskCard.vue'
import { useI18n } from 'vue-i18n'
import APIHelper from '@/helpers/APIHelper'
import { PlanTask } from '@/classes/Plan'
import DateHelper from '@/helpers/DateHelper'
import { usePlansStore } from '@/stores/plans'
import { useEmployeeStore } from '@/stores/employee'
import { Employee } from '@/classes/Employee'
import { useRoute } from 'vue-router'
import type { InsightsTaskUpdateRequestBody } from '@/types/InsightsTypes'
import PlanHelper from '@/helpers/PlanHelper'
import NoTasksToShow from '@/components/tasks/NoTasksToShow.vue'
import TaskError from '@/components/tasks/TaskError.vue'

const sidebarStore = useSidebarStore()
const plansStore = usePlansStore()
const employeeStore = useEmployeeStore()
const route = useRoute()

const { t } = useI18n()
const sortByAnalystRef = ref('ascending')
const sortByStatusRef = ref('ascending')
const sortByDateRef = ref('ascending')
const tasks = ref([] as PlanTask[])
const selectedFilters = ref([] as String[])
const showSpinner = ref(false)
const maxTries = ref(0)
const toastMessage = ref('')
const toastNotifier = ref()
const isUpdateSuccessful = ref(false)

const loading = computed(() => plansStore.isLoadingPlans)
const currentUser = computed(() => employeeStore.currentUser as Employee)

function getTasks() {
  /**
   * The code with `unknownEmployee` is causing issues as it holds `dsid` value as 0 which shouldn't happen.
   * Becuase of that, BE is throwing 400 which again is not expected.
   * With current application behaviour, we are still getting all descendants.
   * To tackle that, have put some conditions which should be fine with current behaviour of the application.
   * When everything is set, we can remove the condition of 0.
   */
  if (currentUser.value.dsid === '') {
    showSpinner.value = false
    return
  }

  let allDsIds = [] as string[]
  if (route.params.employee) {
    const routeEmployee = EmployeeHelper.findEmployee(route.params.employee as string)
    // If the selected employee has direct reports, include them in the dsid
    // array to ensure we're pulling tasks for directs
    if (routeEmployee.directs?.length) {
      allDsIds = allDsIds.concat(routeEmployee.directs)
    }
    allDsIds.push(route.params.employee as string)
  } else {
    // Include the tasks of the loggedIn user and also the descendants if any
    allDsIds = [currentUser.value.dsid.toString(), ...sidebarStore.getAllDirectReportdDsIDs()]
  }
  if (allDsIds.length) {
    APIHelper.fetchAllTasks(allDsIds)
      .then((allTasks) => {
        if (allTasks?.length) {
          tasks.value = allTasks
        }
        showSpinner.value = false
        isUpdateSuccessful.value = true
      })
      .catch((error: Error) => {
        isUpdateSuccessful.value = false
        toastMessage.value = error.message
        showSpinner.value = false
        invokeNotification()
      })
  } else {
    recursivelyCallGetTasks()
  }
}

function invokeNotification() {
  toastNotifier.value.queue()
}

/**
 * dsIds are necessary to fetch the tasks.
 * But dsIds will only be available after we load sidebarStore is ready with the data.
 * Hence, called the function to recursively check for dsIds when the taks page is refreshed from browser.
 */
function recursivelyCallGetTasks() {
  showSpinner.value = true

  // Plans are still loading
  if (loading.value) {
    maxTries.value += 1
    if (maxTries.value > 3) {
      throw new Error('Unable to load tasks.')
    } else {
      setTimeout(() => getTasks(), 1000)
      return
    }
  } else {
    getTasks()
    return
  }
}

watch(
  () => route.params.employee,
  (newDsId, oldDsId) => {
    tasks.value = []
    maxTries.value = 0
    if (newDsId === '0') return
    if (newDsId !== oldDsId) recursivelyCallGetTasks()
  }
)

onMounted(() => {
  maxTries.value = 0
  recursivelyCallGetTasks()
  if (tasks.value.length) {
    sortByDate('ascending')
  }
})

onUnmounted(() => {
  tasks.value = []
})

const isTaskDueSoon = (planStartDate: string, taskDueDate: string) => {
  const startDate = +new Date(planStartDate)
  const endDate = +new Date(taskDueDate)
  const diffInDates = endDate - startDate
  if (diffInDates > 0 && diffInDates < 86400000 * 11) {
    // 86400000 is the total number of seconds per day = 24 * 60 * 60 * 1000
    return true
  }
  return false
}

const isTaskOverdue = (taskDueDate: string) => {
  const endDate = +new Date(taskDueDate)
  const currentDateEpochTime = DateHelper.currentDateEpochTime()
  if (endDate - currentDateEpochTime < 0) {
    return true
  }
  return false
}

const tasksCount = computed(() => {
  const taskStatusCount = {
    DUE_SOON: 0,
    OVERDUE: 0,
    CLOSED: 0,
    IN_PROGRESS: 0,
    ON_HOLD: 0,
    INCOMPLETE: 0,
    CANCELLED: 0,
    COMPLETED: 0
  }

  tasks.value.length &&
    tasks.value.forEach((task) => {
      if (['IN_PROGRESS', 'ON_HOLD'].includes(task.taskStatus)) {
        const endDate = +new Date(task.taskDueDate)
        const currentDateEpochTime = DateHelper.currentDateEpochTime()

        if (endDate - currentDateEpochTime < 0) {
          taskStatusCount['OVERDUE'] += 1
        } else if (isTaskDueSoon(task.planStartDate, task.taskDueDate)) {
          taskStatusCount['DUE_SOON'] += 1
        }
      }
      taskStatusCount[task.taskStatus] += 1
    })

  return taskStatusCount
})

const tasksDataByStatus = computed(() => {
  const tasksByStatus = {
    OVERDUE: [] as PlanTask[],
    TODAY: [] as PlanTask[],
    THIS_WEEK: [] as PlanTask[],
    OTHERS: [] as PlanTask[]
  }

  tasks.value.length &&
    tasks.value.forEach((task: PlanTask) => {
      if (['IN_PROGRESS', 'ON_HOLD'].includes(task.taskStatus)) {
        const endDate = +new Date(task.taskDueDate)
        const currentDateEpochTime = DateHelper.currentDateEpochTime()

        if (endDate === currentDateEpochTime) {
          tasksByStatus['TODAY'].push(task)
        } else if (DateHelper.isDateInThisWeek(task.planStartDate)) {
          tasksByStatus['THIS_WEEK'].push(task)
        } else if (endDate - currentDateEpochTime < 0) {
          tasksByStatus['OVERDUE'].push(task)
        } else {
          tasksByStatus['OTHERS'].push(task)
        }
      }
    })

  const nonEmptyTasksByStatus = {}
  for (const taskCode in tasksByStatus) {
    if (tasksByStatus[taskCode].length) {
      nonEmptyTasksByStatus[taskCode] = tasksByStatus[taskCode]
    }
  }
  return nonEmptyTasksByStatus
})

const filterdTasksData = computed(() => {
  const filteredData = {
    DUE_SOON: [] as PlanTask[],
    OVERDUE: [] as PlanTask[],
    COMPLETED: [] as PlanTask[],
    IN_PROGRESS: [] as PlanTask[],
    ON_HOLD: [] as PlanTask[],
    INCOMPLETE: [] as PlanTask[],
    CANCELLED: [] as PlanTask[]
  }
  if (selectedFilters.value.length && tasks.value.length) {
    const customFilters = ['OVERDUE', 'DUE_SOON', 'COMPLETED']

    // Passing just `string` is throwing TS error. So have put `any`.
    selectedFilters.value.forEach((customFilter: string | any) => {
      if (customFilters.includes(customFilter)) {
        switch (customFilter) {
          case 'OVERDUE':
            filteredData[customFilter] = tasks.value.filter((task) =>
              isTaskOverdue(task.taskDueDate)
            )
            break
          case 'DUE_SOON':
            filteredData[customFilter] = tasks.value.filter((task) =>
              isTaskDueSoon(task.planStartDate, task.planEndDate)
            )
            break
          case 'COMPLETED':
            filteredData[customFilter] = tasks.value.filter(
              (task) => task.taskStatus === 'COMPLETED'
            )
            break
        }
      } else {
        filteredData[customFilter] = tasks.value.filter((task) => task.taskStatus == customFilter)
      }
    })
  }

  const nonEmptyTasksByStatus = {}
  for (const taskCode in filteredData) {
    if (filteredData[taskCode].length) {
      nonEmptyTasksByStatus[taskCode] = filteredData[taskCode]
    }
  }
  return nonEmptyTasksByStatus
})

const sortByAnalyst = (sortBy: string) => {
  const sortedTasks = tasks.value.sort((task1, task2) => {
    const task1Analyst = EmployeeHelper.fullNameFor(task1.taskOwnerDsid)
    const task2Analyst = EmployeeHelper.fullNameFor(task2.taskOwnerDsid)
    if (sortBy === 'ascending') {
      sortByAnalystRef.value = 'descending'
      return task1Analyst.localeCompare(task2Analyst)
    } else {
      sortByAnalystRef.value = 'ascending'
      return task2Analyst.localeCompare(task1Analyst)
    }
  })
  tasks.value = sortedTasks
}
const sortByStatus = (sortBy: string) => {
  const sortedTasks = tasks.value.sort((task1, task2) => {
    if (sortBy === 'ascending') {
      sortByStatusRef.value = 'descending'
      return task1.taskStatus.localeCompare(task2.taskStatus)
    } else {
      sortByStatusRef.value = 'ascending'
      return task2.taskStatus.localeCompare(task1.taskStatus)
    }
  })
  tasks.value = sortedTasks
}
const sortByDate = (sortBy: string) => {
  const sortedTasksByDate = tasks.value.sort((task1: PlanTask, task2: PlanTask) => {
    const task1DueDate = new Date(task1.taskDueDate).getTime()
    const task2DueDate = new Date(task2.taskDueDate).getTime()
    if (sortBy === 'ascending') {
      sortByDateRef.value = 'descending'
      return task1DueDate - task2DueDate
    } else {
      sortByDateRef.value = 'ascending'
      return task2DueDate - task1DueDate
    }
  })
  tasks.value = sortedTasksByDate
}

const selectedFiltersFn = (taskNames: string[]) => (selectedFilters.value = taskNames)

const tasksToIterate = computed(() => {
  if (selectedFilters.value.length) {
    return filterdTasksData.value
  } else {
    return tasksDataByStatus.value
  }
})

const tasksStatusCountByPlan = computed(() => {
  const tasksCountAssoWithPlan = {}
  tasks.value.forEach((task: PlanTask) => {
    if (
      tasksCountAssoWithPlan[task.planId] &&
      tasksCountAssoWithPlan[task.planId][task.taskStatus]
    ) {
      tasksCountAssoWithPlan[task.planId][task.taskStatus] += 1
    } else {
      tasksCountAssoWithPlan[task.planId] = {
        ...tasksCountAssoWithPlan[task.planId],
        [task.taskStatus]: 1
      }
    }
  })

  for (const planId in tasksCountAssoWithPlan) {
    const taskSCountByStatus = Object.values(tasksCountAssoWithPlan[planId]) as number[]
    const sumOfAllTasks = taskSCountByStatus.reduce((a: number, b: number) => a + b, 0 as number)

    tasksCountAssoWithPlan[planId] = {
      ...tasksCountAssoWithPlan[planId],
      TOTAL_NO_OF_TASKS: sumOfAllTasks
    }
  }

  return tasksCountAssoWithPlan
})

function updateTaskStatus(status: string, identifier: string) {
  const taskIndex = tasks.value.findIndex((task: PlanTask) => task.taskId === identifier)
  // If task is not found in all the tasks, then abort.
  if (taskIndex === -1) return

  //There's no chance that `planId` and `taskDueDate` won't be avaialble in tasks with given index
  const taskUpdateRequestBody = {
    planId: tasks.value[taskIndex].planId,
    taskId: identifier,
    lastModifiedBy: currentUser.value.dsid.toString(),
    taskStatus: status,
    taskDueDate: tasks.value[taskIndex].taskDueDate
  } as InsightsTaskUpdateRequestBody
  showSpinner.value = true
  APIHelper.updateTask(taskUpdateRequestBody)
    .then((planId: string | undefined) => {
      if (planId) {
        tasks.value[taskIndex].taskStatus = status
        showSpinner.value = false
        isUpdateSuccessful.value = true
        toastMessage.value = t('task_status_updated_label')
        invokeNotification()
      }
    })
    .catch((error: Error) => {
      toastMessage.value = error.message
      showSpinner.value = false
      isUpdateSuccessful.value = false
      invokeNotification()
    })
}

const groupByOptions = PlanHelper.groupByOptions()
</script>

<template>
  <template v-if="tasks.length">
    <TaskCard
      :tasksCountData="tasksCount"
      v-if="tasks.length"
      @selected-filters="selectedFiltersFn"
    />
    <template v-if="Object.keys(tasksToIterate).length">
      <h3>{{ t('all_tasks_label') }}</h3>
      <section class="body-section" v-for="(tasks, taskCode) in tasksToIterate">
        <p class="status-name">{{ groupByOptions[taskCode] }}</p>
        <!-- Bricks Data Table is looking over complicated to use and on top of it, we have to do CSS customs. This approach is simple and straight -->
        <table>
          <thead>
            <tr>
              <th>
                <span @click="sortByDate(sortByDateRef)" class="sort-cursor">
                  {{ t('task_due_date_label') }}
                  <Triangle
                    :class="['triangle', { 'date-descending': sortByDateRef === 'descending' }]"
                  />
                </span>
              </th>
              <th>
                <span @click="sortByAnalyst(sortByAnalystRef)" class="sort-cursor">
                  {{ t('task_owner_label') }}
                  <Triangle
                    :class="[
                      'triangle',
                      { 'analyst-descending': sortByAnalystRef === 'descending' }
                    ]"
                  />
                </span>
              </th>
              <th>{{ t('task_label') }}</th>
              <th>
                <span @click="sortByStatus(sortByStatusRef)" class="sort-cursor">
                  {{ t('task_status_label') }}
                  <Triangle
                    :class="['triangle', { 'status-descending': sortByStatusRef === 'descending' }]"
                  />
                </span>
              </th>
              <th>{{ t('plan_label') }}</th>
              <th>&nbsp;</th>
            </tr>
          </thead>
          <tbody>
            <IndividualTask
              :tasks="tasks"
              :filterdTasks="tasksDataByStatus"
              :tasksStatusCountByPlan="tasksStatusCountByPlan"
              @task-status-change="updateTaskStatus"
            />
          </tbody>
        </table>
      </section>
    </template>
  </template>
  <template v-else-if="!showSpinner">
    <div v-if="isUpdateSuccessful">
      <NoTasksToShow />
    </div>
    <div v-else>
      <TaskError />
    </div>
  </template>
  <bricks-spinner size="44" fullScreen isOverlay v-if="showSpinner"></bricks-spinner>
  <div class="component-holder">
    <bricks-toast
      class="regular-toast top-right"
      :class="{ 'error-updating': !isUpdateSuccessful }"
      ref="toastNotifier"
      duration="4000"
    >
      {{ toastMessage }}
    </bricks-toast>
  </div>
</template>

<style scoped>
.body-section {
  padding: 5px 20px 25px 25px;
  border-radius: 18px;
}

h3 {
  padding-top: 35px;
  padding-left: 25px;
  margin-left: 20px;
}

table {
  width: 100%;
  border-collapse: separate;
}

th {
  color: black;
  font-size: 12px;
  opacity: 0.5;
}

thead tr {
  display: flex;
  width: 99%;
}

th:first-child {
  width: 10%;
  padding-left: 20px;
}

.body-section .status-name {
  margin: 7px 0 0 20px;
  color: #3a3a3a;
  font-size: 18px;
  font-weight: bold;
  opacity: 0.85;
}

th:nth-child(2) {
  width: 18%;
}

th:nth-child(4) {
  width: 15%;
}

th:nth-child(3) {
  width: 28%;
}

th:nth-child(5) {
  width: 20%;
}

th:last-child {
  width: 9%;
}

.triangle {
  width: 10px;
  height: 10px;
  margin-left: 5px;
}

.date-descending,
.analyst-descending,
.status-descending {
  transform: rotate(-180deg);
}

bricks-spinner {
  --bricks-spinner-overlay: rgb(242 249 244 / 0%);
  --bricks-spinner-native-bg-color: #000300;
}

.error-or-no-tasks-label {
  padding: 15px 20px;
  font-size: 1rem;
  font-weight: 600;
}

.sort-cursor {
  cursor: pointer;
}

@media screen and (width <= 1480px) {
  th:first-child {
    width: 14%;
    padding-left: 10px;
  }

  th:nth-child(3) {
    width: 24%;
  }

  th:nth-child(4) {
    width: 18%;
  }

  th:nth-child(5) {
    width: 22%;
  }

  th:nth-child(6) {
    width: 4%;
  }

  h3 {
    padding-left: 10px;
  }

  .body-section .status-name {
    margin-left: 10px;
  }
}
</style>

<template>
  <div class="logout-message">
    <bricks-card class="card-container" center header="You are logged out..">
      <p class="body-content">Your session is terminated.</p>
      <br />
      <br />
      <br />

      <bricks-button
        visual-style="primary"
        @bricks-click="goBack()"
        accessible-title="Link"
        class="bricks-button"
        >Log In
      </bricks-button>
    </bricks-card>
  </div>
</template>
<script setup lang="ts">
function goBack() {
  window.location.href = '/'
}

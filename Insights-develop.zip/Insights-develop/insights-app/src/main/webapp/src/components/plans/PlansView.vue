<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { onBeforeRouteUpdate, useRoute } from 'vue-router'
import { useSidebarStore } from '@/stores/sidebar'
import { usePlansStore } from '@/stores/plans'
import PlansHeader from '@/components/plans/PlansHeader.vue'
import PlansNavigation from '@/components/plans/PlansNavigation.vue'
import ManagerView from '@/components/plans/manager/ManagerView.vue'
import PlansDraft from '@/components/plans/PlansDraft.vue'
import PlanView from '@/components/plan_view/PlanView.vue'
import APIHelper from '@/helpers/APIHelper'
import EmployeeHelper from '@/helpers/EmployeeHelper'

import DirectView from '@/components/plans/direct/DirectView.vue'
import SeniorManagerView from './senior_manager/SeniorManagerView.vue'
const sidebarStore = useSidebarStore()
const plansStore = usePlansStore()
const route = useRoute()

const selectedTab = ref('current')
const selectedPlanType = ref('none')

const updateTab = (tabName: string) => {
  console.log('PlansViewer.updateTab', tabName)
  selectedTab.value = tabName
}

const planData = computed(() => {
  if (route.query.plan) {
    const planId = route.query.plan as string
    return plansStore.findPlan(planId)
  }
  return
})

const currentUser = computed(() => {
  return EmployeeHelper.currentUser()
})

const selectedUser = computed(() => {
  return EmployeeHelper.findEmployee(sidebarStore.selectedEmployee)
})

const showCreateButton = computed(() => currentUser.value.applicationRoleLevel !== 'level_10')

const showSeniorManagerView = computed(() => {
  // Don't show the Senior Manager View if the current user is an Analyst
  if (currentUser.value.applicationRoleLevel == 'level_10') return false
  // If the sidebar selection is a Senior Team Lead, show the view
  return selectedUser.value.applicationRoleLevel == 'level_30'
})

const showManagerView = computed(() => {
  // Do not show the manager view if the current user is an Analyst
  if (currentUser.value.applicationRoleLevel == 'level_10') return false
  // If the sidebar is selected on a TL, or no Employee exists in the URL,
  // show the Manager view
  if (selectedUser.value.applicationRoleLevel == 'level_20' || !route.params.employee) return true
})

const createPlanDisabled = computed(() => {
  return (
    sidebarStore.selectedEmployee == sidebarStore.selectedManager ||
    selectedUser.value.rapplicationRoleLevel !== 'level_10'
  )
})
const selectedPlanFilter = (filterType: string) => {
  selectedPlanType.value = filterType
}

const directViewDsid = computed(() => {
  if (currentUser.value.applicationRoleLevel == 'level_10') return currentUser.value.dsid
  return route.params.employee as string
})

onMounted(() => {
  // If the user is an Analyst, fetch the plans when the component loads
  if (currentUser.value.applicationRoleLevel == 'level_10') {
    console.log(
      'PlansView.onMounted: User is an Analyst, fetching plans for first time',
      currentUser.value
    )
    const dsid = currentUser.value.dsid
    APIHelper.reloadPlansForDSID(dsid)
  }
})

onBeforeRouteUpdate((to, from) => {
  console.log('PlansView: Route updating', to, from)
  // If the employee has changed, or if the user has gone from a plan back to
  // the plans list, reload plan data for the employee
  if (
    to.params.employee &&
    (to.params.employee !== from.params.employee || (from.query.plan && !to.query.plan))
  ) {
    const dsid = to.params.employee as string
    APIHelper.reloadPlansForDSID(dsid)
  }
})
</script>

<template>
  <div class="plans-view">
    <SeniorManagerView v-if="showSeniorManagerView" />
    <template v-else>
      <template v-if="!planData">
        <PlansHeader
          :show-create-button="showCreateButton"
          :createPlanDisabled="createPlanDisabled"
          :selectedEmployee="sidebarStore.selectedEmployee"
        />

        <PlansNavigation
          @update-tab="updateTab"
          @update-plan-filter="selectedPlanFilter"
          :selected-user="selectedUser"
        />
        <template v-if="selectedTab == 'current'">
          <ManagerView
            v-if="showManagerView"
            :dsid="selectedUser.dsid"
            :selected-plan-type="selectedPlanType"
          />
          <DirectView v-else :dsid="directViewDsid" />
        </template>
        <PlansDraft v-if="selectedTab == 'draft'" />
      </template>
      <template v-else>
        <PlanView :planData="planData" />
      </template>
    </template>
  </div>
</template>

<style scoped>
.plans-view {
  padding-top: 1.5rem;
}
</style>

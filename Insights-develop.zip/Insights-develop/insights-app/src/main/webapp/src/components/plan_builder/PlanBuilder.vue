<script setup lang="ts">
import { onMounted, ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import type { Plan } from '@/classes/Plan'
import { usePlansStore } from '@/stores/plans'
import { useSidebarStore } from '@/stores/sidebar'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import { useRoute, useRouter } from 'vue-router'

import MultipleScreen from '@/components/plan_builder/MultipleScreen.vue'
import PlanBuilderHeader from '@/components/plan_builder/PlanBuilderHeader.vue'
import PlanBuilderNavigation from '@/components/plan_builder/PlanBuilderNavigation.vue'
import APIHelper from '@/helpers/APIHelper'
import PlanHelper from '@/helpers/PlanHelper'
import type { InsightsPlanBehavior } from '@/types/InsightsTypes'

const { t, d } = useI18n()
const route = useRoute()
const router = useRouter()
const sidebarStore = useSidebarStore()
const plansStore = usePlansStore()
const selectedEmployee = computed(() => EmployeeHelper.findEmployee(sidebarStore.selectedEmployee))

const currentDraft = ref({} as Plan)

const componentLoading = ref(true)

const lastThreeMonths = ref([] as Plan[])
const toastNotifier = ref()
const isUpdateSuccessful = ref(false)
const toastMessage = ref('')

const currentScreen = ref(1)
const totalScreens = 3

const reloadTries = ref(0)
const loadingError = ref(undefined as string | undefined)
const planExistForGivenMonth = ref(false)

function loadDraft() {
  console.log('PlanBuilder.loadPlans', route.params, route.query)

  // Don't open PlanBuilder unless there is an employee passed into the route
  // to prevent someone from navigating to it manually
  if (!route.params.employee) {
    console.log('PlanBuilder.LoadPlans: No employee in URL, redirecting')
    return router.replace({ name: 'plans' })
  }

  const existingDraftUUID = route.query?.draft as string | undefined

  if (plansStore.isLoadingPlans) {
    console.log(
      'PlanBuilder.loadDraft: PlanStore is not ready, waiting and retrying',
      reloadTries.value
    )
    reloadTries.value = reloadTries.value + 1
    if (reloadTries.value > 3) {
      loadingError.value = t('error_loading_plans')
      throw new Error('Unable to load plans from Store')
    } else {
      setTimeout(() => loadDraft(), 1000)
      return
    }
  }

  const existingDraft = existingDraftUUID ? plansStore.findDraft(existingDraftUUID) : null

  // If there is an existing draft and the selected sidebar employee doesn't
  // match, or the employee in the url doesn't match the sidebar, load the
  // employee from the draft or URL
  if (
    (existingDraft && selectedEmployee.value.dsid !== existingDraft.planDsid) ||
    selectedEmployee.value?.dsid !== (route.params.employee as string)
  ) {
    const urlEmployee = route.params.employee as string
    const draftDsid = existingDraft?.planDsid
    sidebarStore.setSelectedEmployee(draftDsid || urlEmployee)
  }

  // Set the current draft data in the state. We JSON Parse and Stringify it to
  // ensure we are not mutating the plan that is in the store when we change
  // the draft. It will update in the store when the user saves the draft, or
  // when the user saves it as a plan
  currentDraft.value =
    PlanHelper.cloneObject(existingDraft) ||
    plansStore.createNewDraft(EmployeeHelper.currentUser(), sidebarStore.selectedEmployee)

  const draftId = currentDraft.value.id || currentDraft.value.draftUUID
  if (!route.query.draft || route.query.draft !== draftId) {
    router.replace({ query: { draft: draftId } })
  }

  console.log('PlanBuilder.loadDraft: Current Draft data', currentDraft.value)
  componentLoading.value = false
}

onMounted(() => {
  reloadTries.value = 0
  loadDraft()
})

function toastCb(status: boolean, text: string) {
  isUpdateSuccessful.value = status
  toastMessage.value = text
  toastNotifier.value.queue()
}

const savePlan = (status: string) => {
  if (currentDraft.value.planType.includes('no_plan') && status === 'IN_PROGRESS') {
    status = 'COMPLETED'
  }
  // Transition draft
  const data = { ...currentDraft.value, planState: status }
  if (['IN_PROGRESS', 'COMPLETED'].includes(status)) {
    data.publishedDateTime = String(new Date().getTime())
  }
  // Remove temporary draftUUID field
  delete data.draftUUID
  console.log('PlanBuilder.savePlan: Plan Data', data)

  APIHelper.plans
    .saveOrUpdatePlan(data)
    .then((planId: string | undefined) => {
      if (!planId) return console.warn('PlanBuilder.savePlan: Missing plan ID')

      toastCb(true, t('updates_saved_label'))
      if (currentDraft.value.draftUUID) {
        currentDraft.value.id = planId
        delete currentDraft.value.draftUUID
        currentDraft.value.planState = status
        plansStore.addPlan(currentDraft.value)
      } else {
        plansStore.updatePlan(currentDraft.value.id, currentDraft.value)
      }

      // Update current path with new ID
      if (status === 'IN_PROGRESS') {
        router.push({
          name: 'plans',
          params: { employee: data.planDsid },
          query: { plan: planId }
        })
      } else if (status === 'COMPLETED') {
        router.push({
          name: 'plans',
          params: { employee: data.planDsid },
          force: true,
          replace: true
        })
      } else if (route.query.draft !== planId) {
        router.replace({
          name: 'plan_builder',
          params: { employee: data.planDsid },
          query: { draft: planId }
        })
      }
    })
    .catch((error: Error) => {
      // TODO: Display error to user
      console.error('PlanBuilder.saveOrUpdatePlan: Save or update failed', error.message)
      toastCb(false, error.message)
    })
}

const duplicatePlan = (planId: string) => {
  console.log('PlanBuilder.duplicatePlan: Duplicating plan data', planId)

  const duplicatedData = PlanHelper.duplicatePlan(
    planId,
    currentDraft.value.draftUUID || currentDraft.value.id
  )
  if (!duplicatedData) return
  currentDraft.value = duplicatedData
}

const updateDraftField = ({ field, value }) => {
  currentDraft.value[field] = value
}

const planDataIsValid = computed(() => {
  return false
})

const setScreenTo = (num: number) => {
  currentScreen.value = num
}

function addBehavior() {
  const newBehavior = {
    id: window.crypto.randomUUID(),
    behaviorCode: '',
    behaviorDescription: '',
    behaviorMetricCode: ''
  } as InsightsPlanBehavior

  currentDraft.value.behaviors.unshift(newBehavior)
}
function updateBehavior(behaviorData: InsightsPlanBehavior) {
  const behaviorIndex = currentDraft.value.behaviors.findIndex(
    (behavior) => behavior.id == behaviorData.id
  )

  currentDraft.value.behaviors.splice(behaviorIndex, 1, behaviorData)
}
function deleteBehavior(uuid: string) {
  const behaviorIndex = currentDraft.value.behaviors.findIndex((behavior) => behavior.id == uuid)
  currentDraft.value.behaviors.splice(behaviorIndex, 1)
}
const updatePlanExistRef = (value: boolean) => {
  planExistForGivenMonth.value = value
}
</script>
<template>
  <PlanBuilderHeader
    :planData="currentDraft"
    @save-as-draft="savePlan('DRAFT')"
    @create-plan="savePlan('IN_PROGRESS')"
    :createDisabled="!planDataIsValid"
    :currentScreen="currentScreen"
    :plan-exist-for-given-month="planExistForGivenMonth"
  />
  <div v-if="loadingError">{{ loadingError }}</div>
  <div v-if="!componentLoading" class="plan-builder">
    <MultipleScreen
      :currentScreen="currentScreen"
      :planData="currentDraft"
      :lastThreeMonths="plansStore.lastThreeMonths(currentDraft.planDsid)"
      @add-behavior="addBehavior"
      @delete-behavior="deleteBehavior"
      @duplicate-plan="duplicatePlan"
      @update-behavior="updateBehavior"
      @update-draft-field="updateDraftField"
      @update-month-validation="updatePlanExistRef"
    />
    <PlanBuilderNavigation
      :currentScreen="currentScreen"
      :totalScreens="totalScreens"
      @navigate-screen="setScreenTo"
      :planType="currentDraft.planType"
      :planMonthAndYearError="planExistForGivenMonth"
    />
  </div>
  <div class="component-holder">
    <bricks-toast
      class="regular-toast top-right"
      :class="{ 'error-updating': !isUpdateSuccessful }"
      ref="toastNotifier"
      duration="4000"
    >
      {{ toastMessage }}
    </bricks-toast>
  </div>
</template>

<style scoped>
.plan-builder {
  position: relative;
  width: 100%;
  height: 100%;
}
</style>

<script setup lang="ts">
import { computed, type PropType } from 'vue'
import { useI18n } from 'vue-i18n'
import type { Employee } from '@/classes/Employee'
import type { Plan } from '@/classes/Plan'
import DateHelper from '@/helpers/DateHelper'

console.log('In PlandCard.vue')
const props = defineProps({
  direct: {
    type: Object as PropType<Employee>,
    required: true
  },
  lastThreeMonths: Array<Plan>,
  currentPlan: Object as PropType<Plan>,
  currentDraft: Object as PropType<Plan>,
  completedTasks: String
})

const { t } = useI18n()

const planTypeClass = (planType: string) => {
  return `plan-color-${t(`${planType}_short`).toLowerCase()}`
}

const daysDifference = computed(() => {
  const midnightToday = new Date().setHours(0, 0, 0, 0)
  const planEndDate = props.currentPlan?.planEndDate as string
  const timeDifference = new Date(planEndDate).getTime() - midnightToday
  const daysComputed = Math.floor(timeDifference / (1000 * 60 * 60 * 24))
  return daysComputed
})

const planTaskStatus = computed(() => {
  // If there's no current plan, return false by default
  if (!props.currentPlan || daysDifference.value > 10) return props.completedTasks
  if (daysDifference.value >= 0 && daysDifference.value < 11)
    return t('aiml_pending_completion_label')
  if (daysDifference.value < 0) return t('overdue_label')
})
</script>
<template>
  <div class="card">
    <div class="task-title">
      <span :class="{ 'pending-title': daysDifference <= 10 }">{{ planTaskStatus }}</span>
    </div>
    <p class="title">{{ direct.fullName() }}</p>
    <p class="sub-title">{{ direct.roleName }}</p>
    <div class="card-innersection">
      <div class="float-left last-three">{{ t('aiml_last_three_months_label') }}</div>
      <div class="float-right right-content">
        <div class="last-three-months-circle" v-for="plan in lastThreeMonths" :key="plan.planMonth">
          <p>
            {{
              DateHelper.shortMonth(
                DateHelper.dateFromPlanMonthAndYear(plan.planMonth, plan.planYear)
              )
            }}
          </p>
          <div class="circle" :class="[planTypeClass(plan.planType)]">
            {{ t(`${plan.planType}_short`) }}
          </div>
        </div>
      </div>
    </div>
    <div class="card1">
      <div v-if="currentPlan">
        <div class="float-left">
          <p>{{ t('current_plan_label') }}</p>
          <span class="currentplan-div">
            {{ DateHelper.shortMonthNumericYear(currentPlan.planMonth, currentPlan.planYear) }}
            - {{ currentPlan ? t(currentPlan.planType) : t('no_current_plan') }}
          </span>
        </div>
        <div class="float-right">
          <router-link
            :to="{
              name: 'plans',
              params: { employee: currentPlan.planDsid },
              query: { plan: currentPlan.id }
            }"
          >
            {{ t('view_label') }}
          </router-link>
        </div>
      </div>
      <div v-else>
        <p>{{ t('current_plan_label') }}</p>
        <span class="currentplan-div">{{ t('no_current_plan') }}</span>
      </div>
    </div>
    <div class="card2">
      <div v-if="currentDraft">
        <div class="float-left">
          <p>{{ t('upcoming_plan_label') }}</p>
          <span class="currentdraft-div">
            {{ DateHelper.shortMonthNumericYear(currentDraft.planMonth, currentDraft.planYear) }} -
            {{ currentDraft ? t(currentDraft.planType) : t('no_upcoming_plan') }}
          </span>
        </div>
        <div class="float-right">
          <a class="draft-title">{{ t('drafts_label', 1) }}</a>
          <router-link
            :to="{
              name: 'plan_builder',
              params: { employee: direct.dsid },
              query: { draft: currentDraft.id || currentDraft.draftUUID }
            }"
          >
            {{ t('view_label') }}
          </router-link>
        </div>
      </div>
      <div v-else>
        <div class="float-left">
          <span class="no-upcoming-title">{{ t('no_upcoming_plan') }}</span>
        </div>
        <div class="float-right" v-if="daysDifference <= 10">
          <router-link
            :to="{ name: 'plan_builder', params: { employee: direct.dsid } }"
            v-slot="{ navigate }"
          >
            <button @click="navigate" class="plan-card-create">{{ t('create_now_label') }}</button>
          </router-link>
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</template>

<style scoped>
.card {
  width: 280px;
  height: 290px !important;
  padding: 0 20px;
  border-radius: 8px;
  margin: 0 27px 20px 0;
  background: #fff;
  box-shadow: 0 0 9px 4px rgb(207 207 207 / 3%), 0 0 6px 2px rgb(20 20 20 / 7%);
  float: left;
}

.card:nth-child(4) {
  clear: both;
}

.task-title {
  padding: 10px 0 2px;
  color: rgb(0 0 0 / 85%);
  font-size: 10px;
  font-weight: 400;
  letter-spacing: 0.16px;
  line-height: 12px;
  opacity: 0.64;
  text-align: right;
}

.title {
  color: rgb(0 0 0 / 85%);
  font-size: 18px;
  font-weight: 500;
  letter-spacing: 0.29px;
  line-height: 26px;
}

.sub-title {
  padding-bottom: 7.5px;
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 400;
  letter-spacing: 0.22px;
  line-height: 26px;
  opacity: 0.64;
}

.card-innersection {
  border-top: 0.5px solid lightgray;
  border-bottom: 0.5px solid lightgray;
}

.circle {
  width: 26px;
  height: 26px;
  border-radius: 50%;
  color: rgb(0 0 0 / 85%);
  font-size: 12px;
  font-weight: 500;
  letter-spacing: 0.19px;
  line-height: 26px;
  text-align: center;
}

.right-content div {
  display: inline-block;
}

.right-content p {
  padding: 6.5px 0 3px;
  color: rgb(0 0 0 / 85%);
  font-size: 10px;
  font-weight: 400;
  letter-spacing: 0.16px;
  line-height: 12px;
  opacity: 0.64;
  text-align: center;
}

.last-three {
  padding: 21.5px 0 22px;
  color: rgb(0 0 0 / 85%);
  font-size: 12px;
  font-weight: 400;
  letter-spacing: 0.19px;
  line-height: 12px;
  opacity: 0.64;
}

.card1 {
  margin: 10px 0 15px;
}

.card2 {
  margin-bottom: 20px;
}

.card1,
.card2 {
  padding: 10px 12px 9px 15px;
  border-radius: 8px;
  background: #fff;
  box-shadow: 0 0 9px 4px rgb(207 207 207 / 3%), 0 0 6px 2px rgb(20 20 20 / 7%);
}

.card1 p,
.card2 p {
  color: rgb(0 0 0 / 85%);
  font-size: 12px;
  font-weight: 400;
  letter-spacing: 0.19px;
  line-height: 12px;
  opacity: 0.64;
}

.card1 span,
.card2 span {
  padding: 5px 0 9px;
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 400;
  letter-spacing: 0.22px;
  line-height: 12px;
}

.card1 a,
.card2 a {
  color: #007aff;
  font-size: 12px;
  font-weight: 400;
  letter-spacing: 0.19px;
  line-height: 12px;
  text-align: right;
  text-decoration: none;
}

.draft-title {
  padding-right: 5px;
  color: rgb(0 0 0 / 85%);
  font-size: 10px;
  font-weight: 400;
  letter-spacing: 0.16px;
  line-height: 12px;
  opacity: 0.64;
}

.pending-title {
  color: #ff3b30;
  font-weight: 400;
}

.clear {
  clear: both;
}

.plan-card-create {
  width: 86px;
  padding-top: 5px;
  padding-bottom: 5px;
  border: 2px solid #007aff;
  border-radius: 8px;
  background: #fff;
  box-shadow: 0 0 9px 4px rgb(207 207 207 / 3%), 0 0 6px 2px rgb(20 20 20 / 7%);
  font-size: 12px;
  letter-spacing: 0.19px;
  line-height: 12px;
}

.no-upcoming-title {
  color: rgb(0 0 0 / 85%) !important;
  font-size: 12px !important;
  font-weight: 400 !important;
  letter-spacing: 0.19px !important;
  line-height: 12px !important;
  opacity: 0.64 !important;
}

.currentplan-div,
.currentdraft-div {
  display: block;
  overflow: hidden;
  width: 139px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.last-three-months-circle {
  margin-right: 10px;
}
</style>

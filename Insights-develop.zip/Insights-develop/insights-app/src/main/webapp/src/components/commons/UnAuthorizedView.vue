<template>
  <!-- <el-empty :image-size="200" description="You are not authorized">
    <el-button type="primary" @click="goBack">Try Again</el-button>
  </el-empty> -->
  <div class="customalert-sheet">
    <div class="custom-sheet">
      <!-- <el-empty :image-size="200" description="You are not authorized"> -->
      <h1 class="hss1">Insights</h1>
      <p1 class="pss1">You are not authorized</p1>
      <bricks-button>
        class="try-again" size="extra-small" accessible-title="extra small" @click="goBack" Try
        Again
      </bricks-button>
      <!-- </el-empty> -->
    </div>
  </div>
</template>
<script lang="ts" setup>
import { useRouter } from 'vue-router'

const router = useRouter()
const goBack = () => {
  router.push('/')
}
</script>
<style>
/* .hss1 {
  position: relative;
  top: 300px;
  left: 450px;
}

.pss1 {
  position: relative;
  top: 350px;
  left: 450px;
} */

.customalert-sheet {
  position: relative;
  width: 100%;
  height: 100%;
  background-image: url('@/assets/images/insights-usernotauthorized.jpeg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  box-shadow: 0 0 9px 4px rgb(207 207 207 / 3%), 0 0 6px 2px rgb(20 20 20 / 7%);
}

.custom-sheet {
  position: relative;
  top: 200px;
  left: 400px;
  width: 360px;
  height: 360px;
  background-image: url('@/assets/images/customSheet.png');
  background-position: center;
  background-repeat: no-repeat;
  background-size: contain;
}

.hss1 {
  position: relative;
  top: 100px;
  left: 50px;
  color: blue;
}

.pss1 {
  position: relative;
  top: 150px;
  left: 50px;
}

/* .custom-sheet {
  position: relative;
  top: 272px;
  left: 300px;

  /* width: 31%;
  height: 32%; */

/* width: 220px;
height: 180px; */

/* flex-basis: 23%; */

/* padding: 30px 15px; */

/* border-radius: 8px; */

/* margin-right: 23px;
  margin-bottom: 23px; */

/* background: #fff; */

/* background-image: url('@/assets/images/customSheet.png');
background-position: center; */

/* background-repeat: no-repeat; */

/* background-size: cover; */

/* box-shadow: 0 0 9px 4px rgb(207 207 207 / 3%), 0 0 6px 2px rgb(20 20 20 / 7%); */

/* } */

.try-again {
  /* position: fixed; */
  position: fixed;

  /* top: 545px; */
  top: 480px;
  left: 680px;
  display: flex;
  width: 134px;
  color: #fff;
}
</style>

<script setup lang="ts">
import { ref, onMounted, onErrorCaptured } from 'vue'
import APIHelper from '@/helpers/APIHelper'
import LandingPage from './LandingPage.vue'
import { useI18n } from 'vue-i18n'
const { t } = useI18n()

// Set a loading state while initial data is loaded
const appLoading = ref(true)
const loadingMessage = ref(t('loading_label'))

async function initalizeApplication() {
  // TODO: Get DSID from AppleConnect and pass into Init
  // 2026265615 // Chris Ellis
  // currentUserDsid.value = 1450556490
  const appConfigured = await APIHelper.init()
  appConfigured
    ? console.log('Application Configured Successfully', appConfigured)
    : console.log('Application Not Configured.', appConfigured)
  appLoading.value = !appConfigured
}

onMounted(async () => {
  initalizeApplication()
})

onErrorCaptured((error: Error) => {
  appLoading.value = true
  loadingMessage.value = error.message
})
</script>

<template>
  <div v-if="appLoading">{{ loadingMessage }}</div>
  <template v-if="!appLoading">
    <LandingPage>
      <RouterView />
    </LandingPage>
  </template>
</template>

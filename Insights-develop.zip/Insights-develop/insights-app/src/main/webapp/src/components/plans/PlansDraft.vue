<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { usePlansStore } from '@/stores/plans'
import { computed, ref } from 'vue'
import { useRoute } from 'vue-router'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import DateHelper from '@/helpers/DateHelper'
import NoPlanDraft from './NoPlanDraft.vue'

const route = useRoute()
const plansStore = usePlansStore()
const filteredPlans = computed(() => {
  if (route.params.employee) return plansStore.plansForDsid(route.params.employee.toString())
  return plansStore.plans
})

const { t, d } = useI18n()
const drafts = () => {
  const draftsfor = filteredPlans.value.filter((pd: any) => pd.planState == 'DRAFT')
  const sortedValues = draftsfor.sort((plan1, plan2) => {
    const task1Analyst = EmployeeHelper.fullNameFor(plan1.planDsid)
    const task2Analyst = EmployeeHelper.fullNameFor(plan2.planDsid)
    return task1Analyst.localeCompare(task2Analyst)
  })
  console.log('PlansDraft:drafts()')
  return sortedValues
}
const draftsLength = computed(() => {
  return drafts().length > 0
})
</script>

<template>
  <div v-if="draftsLength">
    <table class="planstable">
      <tr>
        <th>{{ t('name_label') }}</th>
        <th>{{ t('plan_type_label') }}</th>
        <th>{{ t('aiml_plan_month_label') }}</th>
        <th>{{ t('focus_area_label') }}</th>
        <th class="text-align-left">{{ t('date_created_label') }}</th>
        <th></th>
      </tr>
      <tr v-for="plan in drafts()" :key="plan.id || plan.draftUUID">
        <td>{{ EmployeeHelper.fullNameFor(plan.planDsid) }}</td>
        <td>{{ t(plan.planType) }}</td>
        <td>
          {{ DateHelper.shortMonthNumericYear(plan.planMonth, plan.planYear) }}
        </td>
        <td>
          <p v-for="focusArea in plan.focusAreaMetrics" :key="focusArea.focusArea">
            {{ t(focusArea.focusArea) }}
          </p>
        </td>
        <td>{{ d(DateHelper.convertEPOCTimestamp(plan.lastModifiedTime)) }}</td>
        <td>
          <router-link
            :to="{
              name: 'plan_builder',
              params: { employee: plan.planDsid },
              query: { draft: plan.id || plan.draftUUID }
            }"
          >
            {{ t('view_label') }}
          </router-link>
        </td>
      </tr>
    </table>
  </div>

  <div class="no-draft-div" v-else>
    <NoPlanDraft />
  </div>
</template>

<style scoped>
td,
th {
  width: 20%;
  padding: 19px 28px;
  text-align: left;
}

.planstable {
  display: table;
  width: 100%;
  box-sizing: border-box;
  margin-top: 32px;
  border-collapse: collapse;
  font-size: 14px;
  table-layout: fixed;
}

.planstable tr {
  display: block;
  border-radius: 8px;
  margin-bottom: 15px;
  background: #fff;
  box-shadow: 0 0 13px 3px rgb(0 0 0 / 8%);
}

.planstable tr:first-child {
  margin-bottom: 10px;
  background: none;
  box-shadow: none;
  color: #000;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: -0.29px;
  line-height: 15px;
  opacity: 0.5;
}

.planstable td {
  display: table-cell;
}

.text-align-left {
  text-align: left;
}
</style>

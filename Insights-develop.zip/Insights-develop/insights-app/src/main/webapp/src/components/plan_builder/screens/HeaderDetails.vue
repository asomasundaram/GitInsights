<script setup lang="ts">
import { computed, type PropType } from 'vue'
import { useI18n } from 'vue-i18n'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import DateHelper from '@/helpers/DateHelper'
import { Plan } from '@/classes/Plan'
const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  }
})

const { t, d } = useI18n()

const planTitle = computed(() => {
  const planDate = DateHelper.dateFromPlanMonthAndYear(
    props.planData.planMonth,
    props.planData.planYear
  )
  const dateString = d(planDate, 'monthAndYear')
  return dateString + ' - ' + t(props.planData.planType)
})

const planSubheader = computed(() => {
  const employee = EmployeeHelper.findEmployee(props.planData.planDsid)
  const startDate = d(DateHelper.newDate(props.planData.planStartDate))
  const endDate = d(DateHelper.newDate(props.planData.planEndDate))

  return `${employee.fullName()} ${startDate} - ${endDate}`
})
</script>

<template>
  <div>
    <h2 class="title">
      {{ planTitle }}
      <span class="subtext">{{ planSubheader }}</span>
    </h2>
    <div class="box">
      <div class="subbox">
        <div class="box-title">{{ t('plan_type_label') }}</div>
        <div>{{ t(planData.planType) }}</div>
      </div>
      <div class="subbox" v-for="focusArea of props.planData.focusAreaMetrics">
        <div class="box-title">{{ t('metric_label') }}</div>
        <h5>{{ t(focusArea.focusArea) }}</h5>
        <p>
          {{ focusArea.focusAreaMetrics.map((fm: string) => t(fm)).join(', ') }}
        </p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.box {
  display: flex;
  width: 500px;
  margin-top: 20px;
}

.title {
  margin-top: 10px;
  font-size: 1.5rem;
}

.box > * {
  flex: 0 0 33.3333%;
}

.subtext {
  color: lightgray;
  font-size: 18px;
}

.subbox {
  padding: 3px 9px;
  border-radius: 5px;
  margin-right: 20px;
  background: lightgray;
}

.subbox h5 {
  font-size: 1.15rem !important;
}

.subbox .box-title {
  color: rgb(0 136 255);
}

.float-left {
  float: left;
}

.float-right {
  float: right;
}

.clear {
  clear: both;
}

.margin-right-10 {
  margin-right: 10px;
}

.margin-top-40 {
  margin-top: 40px;
}

.margin-bottom-60 {
  margin-bottom: 60px;
}

.button-blue {
  padding: 5px 10px;
  border: none;
  border-radius: 5px;
  background-color: rgb(100 171 237);
}

.button-gray {
  padding: 5px 20px;
  border: none;
  border-radius: 5px;
  background-color: lightgray;
}
</style>

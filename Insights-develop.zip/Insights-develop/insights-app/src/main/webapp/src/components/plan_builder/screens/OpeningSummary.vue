<script setup lang="ts">
import { computed, type PropType } from 'vue'
import type { Plan } from '@/classes/Plan'
import type { IBricks } from '@nexus/bricks-vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  }
})

const emit = defineEmits(['update-draft-field'])

const summary = computed(() => props.planData.planNotes)

function updateOpeningSummary(event: IBricks.TextArea.Events.TextAreaBlur) {
  const newText = event.detail.value

  // If the text is blank, and the planNotes are already blank, do nothing to
  // avoid unnecessary update event
  if (newText == '' && props.planData.planNotes == '') return

  emit('update-draft-field', { field: 'planNotes', value: newText })
}
</script>
<template>
  <div class="label-section">
    <bricks-label class="label-text font-size18">{{ t('opening_summary_label') }}</bricks-label>

    <bricks-text-area
      label="Standard"
      class="full-width"
      :place-holder-text="t('enter_text_optional_label')"
      max-length="400"
      :value="summary"
      resize="none"
      @bricks-text-area-blur="updateOpeningSummary"
    >
    </bricks-text-area>
  </div>
</template>
<style scoped>
.label-text {
  display: block;
  margin: 15px 0 10px 15px;
  text-align: left;
}

bricks-text-area.full-width {
  width: 100%;
  padding-right: 15px;
  border-radius: 5px;
  margin: 0 10px;
}

.text-area .text-area-wrapper {
  border: none !important;
}
</style>

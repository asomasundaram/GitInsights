<script setup lang="ts">
defineProps({
  message: String
})
</script>

<template>
  <div class="error-message">{{ message }}</div>
</template>

<style scoped>
.error-message {
  padding-left: 20px;
}
</style>

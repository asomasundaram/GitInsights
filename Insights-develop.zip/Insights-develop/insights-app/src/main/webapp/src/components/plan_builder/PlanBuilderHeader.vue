<script setup lang="ts">
import { computed, type PropType, ref } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import ChevronRight from '@/components/icons/sfsymbols/chevron.right.vue'
import Preview from '@/components/icons/sfsymbols/preview.vue'
import PlanHelper from '@/helpers/PlanHelper'
import { type Plan } from '@/classes/Plan'
import CheckmarkCircle from '@/components/icons/sfsymbols/checkmark.circle.vue'
import XCircle from '@/components/icons/sfsymbols/x.circle.vue'
import PlanPreview from './screens/PlanPreview.vue'

const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  },
  createDisabled: Boolean,
  currentScreen: {
    type: Number,
    default: 1
  },
  planExistForGivenMonth: Boolean
})

const emits = defineEmits(['save-as-draft', 'create-plan'])
const route = useRoute()

const { t } = useI18n()
const tooltipShowing = ref(false)
const isPreviewOpen = ref(false)
const noPlan = computed(() => props.planData.planType?.includes('no_plan'))

const noPlanErrors = computed(() => {
  let error = true

  if (Object.keys(props.planData).length) {
    const isNoPlan = props.planData.planType === 'aiml_planType_no_plan'
    const planTypeReason = props.planData.planTypeReason !== ''
    const planStartDate = props.planData.planStartDate !== ''
    const planEndDate = props.planData.planEndDate !== ''
    if (isNoPlan && planTypeReason && planStartDate && planEndDate) error = false
  }
  return error
})

function createPlan() {
  // Validate entire plan
  if (
    (noPlan.value && noPlanErrors.value) ||
    (!noPlan.value && planHasErrors.value) ||
    props.planExistForGivenMonth
  )
    return
  emits('create-plan')
}

function createDraft() {
  if (props.planExistForGivenMonth) return
  emits('save-as-draft')
}

const planErrors = computed(() => {
  if (!props.planData || Object.keys(props.planData).length < 1)
    return {
      planMonthAndYear: undefined,
      planDates: undefined,
      behaviors: undefined,
      focusAreaMetrics: undefined,
      competency: undefined,
      supportingTasks: undefined
    }

  return PlanHelper.validate.plan(props.planData)
})

const planHasErrors = computed(() => {
  console.log('PlanErrors Value', Object.values(planErrors.value))
  const definedValues = Object.values(planErrors.value).filter((v) => v)
  if (definedValues.length > 0) return true
  return false
})

const sectionLabel = (section: string) => {
  var locKey
  switch (section) {
    case 'planDates':
      locKey = 'plan_dates_label'
      break
    case 'behaviors':
      locKey = 'behaviors_label'
      break
    case 'focusArea':
    case 'focusAreaMetrics':
      locKey = 'focus_area_label'
      break
    case 'competency':
      locKey = 'aiml_competency_focus_label'
      break
    case 'supportingTasks':
      locKey = 'supporting_tasks_label'
      break
  }

  if (!locKey) return section
  return t(locKey)
}

const showTooltip = () => {
  if (!noPlan.value) tooltipShowing.value = true
}
const hideTooltip = () => {
  tooltipShowing.value = false
}

const enablePlanBtns = computed(() => !noPlanErrors.value || !planHasErrors.value)
function closePreviewModal() {
  isPreviewOpen.value = false
}
</script>
<template>
  <div class="plan-builder-header">
    <div class="plan-builder-header-content">
      <RouterLink :to="{ name: 'plans', params: { employee: route.params.employee } }">
        <bricks-button
          variation="icon-only"
          size="medium"
          :accessible-title="t('back_to_plans_label')"
          class="bricks-button plan-builder-header-back"
        >
          <bricks-icon slot="icon">
            <ChevronRight />
          </bricks-icon>
        </bricks-button>
      </RouterLink>
      <h1 class="plan-builder-header-title">{{ t('create_new_plan_label') }}</h1>
    </div>
    <div class="plan-builder-header-buttons">
      <!-- TODO: Preview functionality needs to be implemented -->
      <bricks-button
        visual-style="link"
        :class="['preview', { 'no-error': enablePlanBtns }]"
        v-if="currentScreen === 3"
        @bricks-click="isPreviewOpen = true"
      >
        <div>
          <bricks-icon color="secondary">
            <Preview />
          </bricks-icon>
        </div>
        {{ t('preview_label') }}
      </bricks-button>
      <bricks-button
        visual-style="secondary"
        :class="['margin-right15', { 'no-error': !planExistForGivenMonth }]"
        :accessible-title="planData.id ? t('update_draft_label') : t('save_as_draft_label')"
        @bricks-click="createDraft"
      >
        {{ planData.id ? t('update_draft_label') : t('save_as_draft_label') }}
      </bricks-button>
      <bricks-popover visual-style="menu" :isOpen="tooltipShowing" placement="bottom">
        <bricks-button
          visual-style="primary"
          hoist
          :accessible-title="t('create_label')"
          :class="{ 'no-error': enablePlanBtns }"
          @bricks-click="createPlan"
          slot="trigger"
          @mouseover="showTooltip"
          @mouseleave="hideTooltip"
        >
          {{ t('create_label') }}
        </bricks-button>
        <div slot="content">
          <div v-for="(error, section) in planErrors" :key="(section as string)">
            <div v-if="error" class="validation-popover-text danger">
              <span>
                <bricks-icon color="primary" size="small" class="validation-popover-icon">
                  <XCircle class="danger" />
                </bricks-icon>
              </span>

              <span>{{ error }}</span>
            </div>
            <div v-else class="validation-popover-text success">
              <span>
                <bricks-icon color="primary" size="small">
                  <CheckmarkCircle class="success" />
                </bricks-icon>
              </span>

              <span>{{ sectionLabel(section) }}</span>
            </div>
          </div>
        </div>
      </bricks-popover>
    </div>
  </div>
  <bricks-dialog
    v-if="isPreviewOpen"
    behavior="quasimodal"
    .isOpen="isPreviewOpen"
    @bricks-dialog-close="closePreviewModal"
    class="preview-modal"
  >
    <span slot="body" class="preview-modal-content">
      <PlanPreview
        :isPreviewOpen="isPreviewOpen"
        :plan-data="planData"
        v-if="Object.keys(planData).length"
      />
    </span>
  </bricks-dialog>
</template>

<style scoped>
.plan-builder-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 1.5rem;
}

.plan-builder-header-back {
  margin-right: 15px;
  transform: rotate(180deg);
}

.plan-builder-header-content {
  display: flex;
  align-items: center;
}

h1.plan-builder-header-title {
  font-size: 24px;
  font-weight: bold;
}

.plan-builder-header-buttons {
  display: flex;
}

.margin-right15 {
  margin-right: 15px;
}

.validation-popover-icon {
  width: 15px;
  height: 15px;
}

.validation-popover-text {
  display: inline-flex;
  align-items: flex-start;
  font-size: 14px;
  line-height: 15px;
}

.validation-popover-text span {
  padding-left: 5px;
}

.success {
  color: green;
  fill: green;
}

.danger {
  color: red;
  fill: red;
}

.plan-builder-header-buttons bricks-button {
  --bricks-button-secondary-border-color: transparent;

  border-radius: 8px;
  color: rgb(0 0 0 / 85%);
  font-size: 18px;
  font-weight: 400;
  letter-spacing: -0.43px;
  line-height: 22px;
  opacity: 0.62;

  --bricks-button-secondary-bg-color: #d8d8d8;
}

.plan-builder-header-buttons bricks-popover bricks-button {
  --bricks-button-secondary-border-color: #007aff;
}

bricks-button.preview {
  margin-right: 20px;
}

bricks-button.preview::part(base) {
  text-decoration: none;
}

bricks-button.preview::part(title) {
  color: #484848;
}

bricks-button.no-error {
  opacity: 1;
}

bricks-button.preview.no-error::part(title),
bricks-button.preview.no-error bricks-icon {
  color: #007aff;
}

.preview div {
  display: inline-flex;
  margin: -3px 5px 0 0;
  vertical-align: middle;
}

.preview-modal {
  --bricks-dialog-width: 90%;
  --bricks-dialog-overflow: auto;

  position: relative;
}

bricks-dialog::part(dialog-close) {
  margin-block: 1% 96%;
  writing-mode: vertical-rl;
}

.preview-modal-content {
  width: 100%;
}
</style>

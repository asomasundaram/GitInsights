<script setup lang="ts">
import { type PropType } from 'vue'
import { type Employee } from '@/classes/Employee'
import CurrentUserProfile from './CurrentUserProfile.vue'
import NavigationButton from './NavigationButton.vue'
import { useRoute, useRouter } from 'vue-router'
import { computed, ref } from 'vue'

const route = useRoute()

const logoutroute = computed(() => {
  if (route.name == 'logout') return true
  return false
})
defineProps({
  currentUser: {
    type: Object as PropType<Employee>,
    required: true
  },
  currentPath: {
    type: String,
    required: true
  },
  pathEmployee: String
})
</script>

<template>
  <div v-if="!logoutroute" class="sidebar-left">
    <nav class="nav-sidebar">
      <RouterLink :to="{ name: 'plans', params: { employee: pathEmployee } }">
        <NavigationButton icon="doc.text" buttonFor="plans" :currentPath="currentPath" />
      </RouterLink>
      <RouterLink :to="{ name: 'tasks', params: { employee: pathEmployee } }">
        <NavigationButton icon="book" buttonFor="tasks" :currentPath="currentPath" />
      </RouterLink>
    </nav>
    <CurrentUserProfile :current-user="currentUser" />
  </div>
</template>

<style scoped>
.sidebar-left {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-bottom: 1rem;
  padding-left: 1rem;
}

.nav-sidebar {
  padding-top: 30px;
}

.nav-sidebar a {
  text-decoration: none;
}
</style>

<script setup lang="ts">
import { computed, type PropType } from 'vue'
import { Plan } from '@/classes/Plan'
import EmployeeHelper from '@/helpers/EmployeeHelper'

import PlanDetailsScreen from '@/components/plan_builder/screens/PlanDetailsScreen.vue'
import PlanFocusAreas from '@/components/plan_builder/screens/PlanFocusAreas.vue'
import BehaviorSection from '@/components/plan_builder/screens/BehaviorSection.vue'
import HeaderDetails from '@/components/plan_builder/screens/HeaderDetails.vue'
import SupportingTasks from '@/components/plan_builder/screens/SupportingTasks.vue'
import CompentencyFocus from '@/components/plan_builder/screens/CompentencyFocus.vue'
import OpeningSummary from './screens/OpeningSummary.vue'

const props = defineProps({
  currentScreen: {
    type: Number,
    default: 1
  },
  planData: {
    type: Object as PropType<Plan>,
    required: true
  },
  lastThreeMonths: Array<Plan>
})

defineEmits([
  'add-behavior',
  'duplicate-plan',
  'delete-behavior',
  'update-behavior',
  'update-draft-field',
  'update-month-validation'
])

const employeeData = computed(() => {
  return EmployeeHelper.findEmployee(props.planData.planDsid)
})
</script>

<template>
  <div class="multiple-screen-header">
    <div v-if="currentScreen < 3" class="centered-employee-info">
      <h2 class="multiple-screen-header-text">{{ employeeData.fullName() }}</h2>
      <div class="multiple-screen-subheader-text">{{ employeeData.roleName }}</div>
    </div>
    <div v-else class="multiple-screen-plan-details">
      <HeaderDetails :plan-data="planData" />
    </div>
  </div>

  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div>
          <div class="screens row">
            <div class="col-md-12">
              <div class="screensSection" v-show="currentScreen === 1">
                <!-- Screen 1 content -->
                <div class="textalign-center">
                  <PlanDetailsScreen
                    :last-three-months="lastThreeMonths"
                    :plan-data="planData"
                    @duplicate-plan="$emit('duplicate-plan', $event)"
                    @update-draft-field="$emit('update-draft-field', $event)"
                    @update-month-validation="$emit('update-month-validation', $event)"
                  />
                </div>
              </div>
              <div class="screensSection" v-show="currentScreen === 2">
                <!-- Screen 2 content -->
                <div class="textalign-center">
                  <PlanFocusAreas
                    :plan-data="planData"
                    @update-draft-field="$emit('update-draft-field', $event)"
                  />
                </div>
              </div>
              <div class="screensSection" v-show="currentScreen === 3">
                <!-- Screen 3 content -->
                <div class="row">
                  <div class="col-md-12">
                    <BehaviorSection
                      :plan-data="planData"
                      @update-draft-field="$emit('update-draft-field', $event)"
                      @add-behavior="$emit('add-behavior')"
                      @update-behavior="$emit('update-behavior', $event)"
                      @delete-behavior="$emit('delete-behavior', $event)"
                    />
                    <CompentencyFocus
                      :plan-data="planData"
                      @update-draft-field="$emit('update-draft-field', $event)"
                    />
                    <SupportingTasks
                      :plan-data="planData"
                      @update-draft-field="$emit('update-draft-field', $event)"
                    />
                    <OpeningSummary
                      :plan-data="planData"
                      @update-draft-field="$emit('update-draft-field', $event)"
                    />
                  </div>
                </div>
              </div>
              <div class="clearfix"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.centered-employee-info {
  padding-top: 1rem;
  text-align: center;
}

h2.multiple-screen-header-text {
  color: var(--header-text-color);
  font-size: 28px;
  font-weight: 500;
  letter-spacing: -0.67px;
  line-height: 22px;
  text-align: center;
}

.multiple-screen-subheader-text {
  margin-top: 10px;
  color: var(--header-text-color);
  font-size: 20px;
  font-weight: 500;
  letter-spacing: -0.48px;
  line-height: 22px;
  opacity: 0.5;
  text-align: center;
}

body {
  padding: 0 24px;
  margin: 0;
  color: #fcbe24;
}

h1,
h2,
h3,
p {
  margin: 0;
}

.textalign-center {
  text-align: center;
}
</style>

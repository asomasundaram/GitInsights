<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useEmployeeStore } from '@/stores/employee'
import { useSidebarStore } from '@/stores/sidebar'

import NavigationSidebar from './sidebars/NavigationSidebar/NavigationSidebar.vue'
import TeamSidebar from './sidebars/TeamSidebar/TeamSidebar.vue'
import APIHelper from '@/helpers/APIHelper'
import { Employee } from '@/classes/Employee'

const employeeStore = useEmployeeStore()
const sidebarStore = useSidebarStore()
const route = useRoute()
const router = useRouter()

const currentUser = computed(() => employeeStore.currentUser as Employee)
const isLoggedInUserAnalyst = computed(() => {
  if (currentUser.value.roleId === 'A') {
    return true
  }
  return false
})

const sidebarCollapsed = ref(false)
const sidebarHidden = computed(() => {
  if (
    route.name == 'plan_builder' ||
    route.name == 'logout' ||
    (route.name === 'plans' && route.query.plan) ||
    (route.name == 'tasks' && currentUser.value.roleId === 'A') ||
    isLoggedInUserAnalyst.value
  )
    return true
  return false
})

const navbarHidden = computed(() => {
  if (route.name == 'logout') return true
  return false
})

const currentPath = computed(() => {
  const currentRouteName = route.name
  return currentRouteName as string
})

const pathEmployee = computed(() => {
  return route.params.employee as string
})

function toggleExpandCollapse() {
  sidebarCollapsed.value = !sidebarCollapsed.value
}

function updateSidebarSelection(dsid: string) {
  // Don't re-select the same employee
  if (sidebarStore.selectedEmployee == dsid) return
  const routeObj = {
    name: route.name as string
  }

  if (sidebarStore.selectedManager !== dsid) {
    routeObj['params'] = { employee: dsid }
  }
  router.push(routeObj)
  sidebarStore.setSelectedEmployee(dsid)
}

const selectedSidebarManager = computed(() => {
  return employeeStore.findEmployeeByDSID(sidebarStore.selectedManager)
})
</script>

<template>
  <main>
    <NavigationSidebar
      :current-path="currentPath"
      :current-user="employeeStore.currentUser"
      :path-employee="pathEmployee"
      :is-hidden="navbarHidden"
    />
    <div class="main-content-wrapper">
      <div class="main-content">
        <slot />
      </div>
    </div>
    <TeamSidebar
      :active-directs="sidebarStore.activeDirects"
      :inactive-directs="sidebarStore.inactiveDirects"
      :is-collapsed="sidebarCollapsed"
      :is-hidden="sidebarHidden"
      :selected-employee="sidebarStore.selectedEmployee"
      :selected-manager="selectedSidebarManager"
      @toggle-expand-collapse="toggleExpandCollapse"
      @update-sidebar-selection="updateSidebarSelection"
    />
  </main>
</template>

<style scoped>
main {
  display: inline-flex;
  width: 100%;
  height: 100vh;
  justify-content: space-between;
}

.main-content-wrapper {
  overflow: auto;
  width: 100%;
  height: 100vh;
  padding: 2rem 1rem 1rem;
}

.main-content {
  height: 100%;
  border-radius: 15px;
  background: #fff;
  overflow-y: scroll;
}
</style>

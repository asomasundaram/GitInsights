<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import { useEmployeeStore } from '@/stores/employee'
import { Employee } from '@/classes/Employee'

const { t } = useI18n()
const props = defineProps({
  showCreateButton: Boolean,
  createPlanDisabled: Boolean,
  selectedEmployee: String
})
const employeeStore = useEmployeeStore()

const selectedEmployeeData = computed(() => {
  return EmployeeHelper.findEmployee(props.selectedEmployee)
})

const employeeName = computed(() => {
  return EmployeeHelper.fullNameFor(props.selectedEmployee)
})
const currentUser = computed(() => employeeStore.currentUser as Employee)
const isLoggedInUserAnalyst = computed(() => {
  if (currentUser.value.applicationRoleLevel === 'level_10') {
    return true
  }
  return false
})
</script>

<template>
  <div class="plans-view-header">
    <h1 class="plans-header-text" v-if="isLoggedInUserAnalyst">
      {{ currentUser.fullName() }}
    </h1>
    <h1 class="plans-header-text" v-else>
      {{ createPlanDisabled ? 'All Plans' : `${employeeName}'s Plans` }}
    </h1>
    <router-link
      :to="{
        name: 'plan_builder',
        params: { employee: selectedEmployee }
      }"
      v-slot="{ navigate }"
      v-if="showCreateButton"
    >
      <bricks-button
        visual-style="primary"
        :accessible-title="t('create_new_plan_label')"
        :disabled="createPlanDisabled"
        @bricks-click="navigate"
      >
        {{ t('create_new_plan_label') }}
      </bricks-button>
    </router-link>
  </div>
  <div v-if="selectedEmployeeData.applicationRoleLevel == 'level_10'">
    <p class="sub-text">{{ selectedEmployeeData.roleName }}, {{ selectedEmployeeData.locale }}</p>
  </div>
</template>

<style scoped>
h1.plans-header-text {
  font-size: 24px;
}

.plans-view-header {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
</style>

<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import PlusCircle from '@/components/icons/sfsymbols/plus.circle.vue'

const { t } = useI18n()
</script>

<template>
  <div class="draft-content-middle">
    <p class="cross-icon">
      <bricks-icon color="primary" size="extra-large">
        <PlusCircle class="cross-icon" />
      </bricks-icon>
    </p>
    <p class="draft-title">{{ t('no_drafts_label') }}</p>
    <p class="draft-subtitle">{{ t('no_drafts_description') }}</p>
  </div>
</template>

<style scoped>
.draft-title {
  color: #3a3a3a;
  font-size: 22px;
  font-weight: 400;
  letter-spacing: -0.53px;
  line-height: 24px;
  text-align: center;
}

.draft-subtitle {
  margin-top: 22px;
  color: #3a3a3a;
  font-size: 18px;
  font-weight: 400;
  letter-spacing: -0.43px;
  line-height: 20px;
  opacity: 0.5;
  text-align: center;
}

.create-button {
  display: block;
  margin: 24px 0;
  text-align: center;
}

.draft-content-middle {
  position: absolute;
  top: 50%;
  right: 50%;
  transform: translateY(-50%);
}

.cross-icon {
  margin: 0 auto 22px;
  color: #3a3a3a;
  fill: #3a3a3a;
  opacity: 0.75;
  text-align: center;
}
</style>

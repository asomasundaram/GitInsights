<script setup lang="ts">
import { type PropType } from 'vue'
import { Plan } from '@/classes/Plan'
import PlanDetailsLastThreeMonths from '@/components/plan_builder/screens/PlanDetailsLastThreeMonths.vue'
import PlanDetailsForm from '@/components/plan_builder/screens/PlanDetailsForm.vue'

defineEmits(['duplicate-plan', 'update-draft-field', 'update-month-validation'])

defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  },
  lastThreeMonths: Array<Plan>
})
</script>

<template>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12"></div>
      <div class="col-md-6">
        <PlanDetailsLastThreeMonths
          :last-three-months="lastThreeMonths"
          :plan-data="planData"
          @duplicate-plan="$emit('duplicate-plan', $event)"
        />
      </div>
      <div class="col-md-6">
        <PlanDetailsForm
          :plan-data="planData"
          @update-draft-field="$emit('update-draft-field', $event)"
          @update-month-validation="$emit('update-month-validation', $event)"
        />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { Plan } from '@/classes/Plan'
import { type PropType } from 'vue'

const props = defineProps({
  planData: Object as PropType<Plan>
})

const { t } = useI18n()
</script>

<template>
  <ol>
    <li v-for="behavior in planData?.behaviors" :key="behavior.behaviorCode">
      {{ behavior.behaviorCode ? t(behavior.behaviorCode) : behavior.behaviorDescription }}
    </li>
  </ol>
</template>

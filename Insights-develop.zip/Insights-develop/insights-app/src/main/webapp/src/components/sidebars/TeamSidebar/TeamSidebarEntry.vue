<script setup lang="ts">
/* eslint-disable vue/no-deprecated-slot-attribute */
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { Employee } from '@/classes/Employee'
import Avatar from '@/components/icons/Avatar.vue'
import ConditionalTooltip from '@/components/icons/ConditionalTooltip.vue'
import Ellipsis from '@/components/icons/sfsymbols/ellipsis.vue'

const { t } = useI18n()
const props = defineProps({
  collapsed: Boolean,
  employee: {
    type: Employee,
    default: null
  },
  selected: Boolean,
  showMenu: Boolean,
  subheader: String
})

const employeeLocales = computed(() => {
  const employee = props.employee
  if (!employee) return ''
  const maxLocales = 5
  const locales = [] as string[]
  for (let i = 1; i <= maxLocales; i++) {
    const localeNumber = 'locale' + (i > 1 ? i : '')
    if (employee[localeNumber] && employee[localeNumber] != '') locales.push(employee[localeNumber])
  }
  return locales.join(', ')
})
</script>

<template>
  <div class="team-sidebar-employee" :class="{ collapsed, selected }">
    <div class="team-sidebar-employee-info">
      <div class="employee-icon">
        <ConditionalTooltip :enableTooltip="collapsed">
          <template v-slot:content>
            <Avatar :employee="employee" slot="trigger" />
          </template>
          <template v-slot:tooltip-content>
            <div class="sidebar-tooltip">
              <div class="bold">{{ employee?.fullName() }}</div>
              <div>{{ employee?.roleName }}</div>
              <div>{{ employeeLocales }}</div>

              <div :alt="subheader" :title="subheader">{{ subheader }}</div>
            </div>
          </template>
        </ConditionalTooltip>
      </div>
      <div class="employee-info" :class="{ collapsed }">
        <div class="employee-name">{{ employee?.fullName() }}</div>
        <div class="employee-subheader">{{ employee?.roleName }}</div>
        <div class="employee-subheader" v-if="subheader" :title="employee?.locale">
          {{ subheader }}
        </div>
      </div>
    </div>
    <div class="team-sidebar-manager-more-button" v-if="showMenu">
      <bricks-menu-button>
        <bricks-button
          class="team-manager-more-button"
          variation="icon-only"
          size="large"
          slot="trigger"
          :accessible-title="t('manager_menu_label')"
          @click="$emit('more-clicked')"
        >
          <bricks-icon slot="icon">
            <Ellipsis class="rotated-icon" />
          </bricks-icon>
        </bricks-button>
        <bricks-menu>
          <slot name="menu-options" />
        </bricks-menu>
      </bricks-menu-button>
    </div>
  </div>
</template>

<style scoped>
.team-sidebar-employee {
  display: inline-flex;
  overflow: hidden;
  width: 100%;
  justify-content: space-between;
  padding: 10px 14px;
  border-radius: 10px;
}

.team-sidebar-employee.selected {
  background-color: #c6ddfd;
}

.team-sidebar-employee-info {
  display: flex;
  width: 100%;
  align-items: center;
}

.employee-info {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  margin-right: auto;
  margin-left: 10px;
}

.employee-info.collapsed {
  display: none;
}

.employee-name {
  margin-bottom: -5px;
  color: #3f4246;
  font-size: 16px;
  font-weight: 700;
}

.employee-subheader {
  overflow: hidden;
  width: 200px;
  color: #535d69;
  font-size: 14px;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.rotated-icon {
  transform: rotate(90deg);
}

.sidebar-tooltip {
  font-size: 12px;
  text-align: left;
}

.bold {
  font-weight: bold;
}
</style>

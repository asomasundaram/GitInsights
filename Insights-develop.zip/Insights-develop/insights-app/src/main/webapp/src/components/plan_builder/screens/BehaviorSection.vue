<script setup lang="ts">
import { computed, ref, type PropType } from 'vue'
import { useI18n } from 'vue-i18n'
import { Plan } from '@/classes/Plan'
import { usePlansStore } from '@/stores/plans'
import ErrorMessage from './ErrorMessage.vue'

import Behavior from '@/components/plan_builder/screens/Behavior.vue'

const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  }
})

const emit = defineEmits(['add-behavior', 'update-behavior', 'delete-behavior'])

const { t } = useI18n()
const plansStore = usePlansStore()

const behaviorLibrary = plansStore.behaviorLibrary
const metricLibrary = plansStore.metrics

const addedBehaviorsLength = computed(() => props.planData.behaviors.length)

function addRow() {
  emit('add-behavior')
}

const isOpen = ref(true)

function toggleAccordion() {
  isOpen.value = !isOpen.value
}
</script>

<template>
  <div id="accordion">
    <div class="accordion-title">
      <div class="float-left margin-top5">
        <div class="float-left margin-right10">
          <h3 class="font-size18">{{ t('behaviors_label') }}</h3>
        </div>
        <div class="float-left" v-if="addedBehaviorsLength >= 1">
          <span class="row-count">
            {{ t('some_behaviors_added_label', addedBehaviorsLength) }}
          </span>
        </div>
        <div class="float-right" v-if="addedBehaviorsLength < 1">
          <ErrorMessage :message="t('error_add_one_behavior')" />
        </div>
      </div>
      <div class="float-right">
        <div class="margin-top5 add-behavior-section">
          <div class="add-behavior-button">
            <bricks-button
              visual-style="alternative"
              :accessible-title="t('add_new_behavior_label')"
              :disabled="!isOpen"
              @bricks-click="addRow"
            >
              {{ t('add_label') }}
            </bricks-button>
          </div>
          <h2 class="cursor-pointer" @click="toggleAccordion">
            {{ isOpen ? '-' : '+' }}
          </h2>
          <div class="clear"></div>
        </div>
      </div>
      <div class="clear"></div>
    </div>

    <div class="accordion-content" v-if="isOpen">
      <table v-if="addedBehaviorsLength">
        <thead>
          <tr>
            <th>{{ t('behavior_label') }}</th>
            <th>{{ t('metric_label') }}</th>
            <th>&nbsp;</th>
          </tr>
        </thead>
        <tbody>
          <Behavior
            v-for="behavior in planData.behaviors"
            :behavior-library="behaviorLibrary"
            :metric-library="metricLibrary"
            :behavior="behavior"
            :key="behavior.id"
            @update-behavior="emit('update-behavior', $event)"
            @delete-behavior="emit('delete-behavior', $event)"
          />
        </tbody>
      </table>
    </div>
  </div>
</template>

<style scoped>
.add-behavior-section {
  display: flex;
  justify-content: end;
}

.add-behavior-button {
  margin-right: 20px;
}

.accordion-title {
  padding: 10px 15px;
  border-top: 2px solid #d1d1d1;

  /* border-bottom: 2px solid #d1d1d1; */
}

.cursor-pointer {
  margin-top: -6px;
  cursor: pointer;
}

table {
  width: 100%;
  border-collapse: separate;
}

th {
  color: grey;
  text-align: left;
}

td {
  padding: 12px;
  text-align: left;
}

th:first-child {
  width: 53%;
  padding-left: 15px;
}

th:last-child {
  width: 20%;
  text-align: right;
}

th:nth-child(2),
tbody tr td:nth-child(2) {
  width: 25%;
}

thead,
tbody {
  display: block;
  padding-top: 0.5rem;
  padding-left: 1rem;
}

/* custom scrollbar styles */
tbody {
  max-height: 285px;
  overflow-y: auto;
  scrollbar-color: #ccc #f2f2f2;
  scrollbar-width: thin;
}

tbody ::-webkit-scrollbar {
  width: 6px;
}

tbody ::-webkit-scrollbar-thumb {
  border-radius: 3px;
  background-color: #ccc;
}

tbody ::-webkit-scrollbar-track {
  background-color: #f2f2f2;
}

thead tr {
  display: inline-flex;
  width: 99%;
  margin-top: 10px;
  margin-bottom: 5px;
}

tbody tr {
  display: inline-flex;
  width: 99%;
  border-radius: 5px;
  margin-bottom: 15px;
  background-color: #fff;
  box-shadow: rgb(99 99 99 / 20%) 0 1px 6px 2px;
}

.row-count {
  display: block;
  color: gray;
}
</style>

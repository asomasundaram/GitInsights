<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { Plan } from '@/classes/Plan'
import { usePlansStore } from '@/stores/plans'
import { computed } from 'vue'
import DateHelper from '@/helpers/DateHelper'
import PlanHelper from '@/helpers/PlanHelper'

const plansStore = usePlansStore()

const { t } = useI18n()

const props = defineProps({
  dsid: {
    type: String,
    required: true
  }
})

const filteredPlans = computed(() => plansStore.plansForDsid(props.dsid))

const sortedYearPlans = computed(() => {
  const plans = filteredPlans?.value.filter((plan) => plan.planState === 'COMPLETED')
  return PlanHelper.sortPlanMonthAndYear(plans, 'ascending')
})

const planTypeShortName = (planType: string) => {
  return t(planType + '_short')
}

const planTypeClass = (planType: string) => {
  return 'plan-color-' + planTypeShortName(planType).toLowerCase()
}
</script>

<template>
  <div class="coaching-plan">
    <h2 class="plan-title">{{ t('coaching_plan_label') }}</h2>
    <div v-for="plan in sortedYearPlans" :key="plan.id || plan.draftUUID">
      <div class="float-left coachingplancard-yearplandiv">
        <p class="year-div">
          {{ DateHelper.shortMonthNumericYear(plan.planMonth, plan.planYear) }}
        </p>
        <router-link
          class="plan-type-link"
          :to="{
            name: 'plans',
            params: { employee: plan.planDsid },
            query: { plan: plan.id }
          }"
        >
          <span class="circle" :class="[planTypeClass(plan.planType)]">
            {{ planTypeShortName(plan.planType) }}
          </span>
        </router-link>
        <p class="name-div" v-if="plan.closureRating">
          {{ t(plan.closureRating + '_short') }}
        </p>
      </div>
    </div>

    <div class="clear"></div>
  </div>
</template>

<style scoped>
.circle {
  display: block;
  width: 40px;
  height: 40px;
  padding: 7px 0;
  border-radius: 50%;
  margin: 0 auto;
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 500;
  letter-spacing: 0.22px;
  line-height: 26px;
  text-align: center;
}

.year-div {
  margin-bottom: 10px;
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 500;
  letter-spacing: 0.22px;
  line-height: 26px;
  text-align: center;
}

.name-div {
  margin-top: 13px;
  color: rgb(0 0 0 / 85%);
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.18px;
  line-height: 13px;
  opacity: 0.85;
  text-align: center;
}

.coachingplancard-yearplandiv {
  margin-right: 19px;
  margin-left: 12px;
}

.float-left p {
  text-align: center;
}

.float-left p:first-child {
  font-weight: bold;
}

.plan-title {
  padding: 29px 0 9px;
  color: rgb(60 60 60 / 85%);
  font-size: 22px;
  font-weight: 700;
  letter-spacing: 0.35px;
  line-height: 26px;
}

.coaching-plan {
  margin-top: 10px;
}

.plan-type-link {
  color: black;
  text-decoration: none;
}
</style>

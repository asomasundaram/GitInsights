<script setup lang="ts">
import { computed, ref, type PropType, watch } from 'vue'
import type { InsightsPlanSupportingTask, InsightsTask } from '@/types/InsightsTypes'
import type { IBricks } from '@nexus/bricks-vue'
import { useI18n } from 'vue-i18n'
import { type Employee } from '@/classes/Employee'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import DateHelper from '@/helpers/DateHelper'
import PlanHelper from '@/helpers/PlanHelper'
import PlanState from '../../plan_view/PlanState.vue'
import { useEmployeeStore } from '@/stores/employee'

const { t, d } = useI18n()

const props = defineProps({
  assignableEmployees: {
    type: Array<Employee>,
    required: true
  },
  planStartDate: {
    type: String,
    required: true
  },
  planEndDate: {
    type: String,
    required: true
  },
  task: {
    type: Object as PropType<InsightsPlanSupportingTask>,
    required: true
  },
  taskLibrary: {
    type: Array<InsightsTask>,
    required: true
  },
  isPlanView: {
    type: Boolean,
    default: false
  },
  planViewSaveFlag: {
    type: Boolean
  },
  planState: String,
  userCanUpdatePlan: Boolean
})

const employeeStore = useEmployeeStore()
const emit = defineEmits(['update-task', 'delete-task', 'edit-task'])
const originalTaskData = PlanHelper.cloneObject(props.task)

const isEditing = ref(false)
const editing = computed(() => {
  emit('edit-task', props.task.id, isEditing.value)
  return isEditing.value
})

const taskStatus = ref(props.task.taskStatus)

watch(
  () => props.planViewSaveFlag,
  (value) => {
    if (value) isEditing.value = false
  }
)

const taskCode = ref([props.task.taskCode || props.task.taskDescription])
const taskCodeError = computed(() => {
  let message: string | undefined
  if (!taskCode.value[0] || taskCode.value[0] == '') message = t('error_task_description_required')
  return { status: message ? 'invalid' : 'valid', message }
})

const taskOwner = ref([props.task.taskOwner])
const taskOwnerError = computed(() => {
  let message: string | undefined
  if (taskOwner.value[0] == '') message = t('error_task_owner_required')

  return { status: message ? 'invalid' : 'valid', message }
})
const taskDueDate = ref(props.task.taskDueDate)
const taskDueDateError = computed(() => {
  let message: string | undefined
  if (!taskDueDate.value[0] || taskDueDate.value[0] == '')
    message = t('error_task_due_date_required')
  return { status: 'valid', message }
})

function updateTaskField(taskField: object) {
  const taskData = {
    ...props.task,
    ...taskField
  }
  emit('update-task', taskData)
}

function updateTaskCode(event: IBricks.Selector.Events.SelectorChange) {
  const newValue = event.detail.value
  taskCode.value = newValue
  if (props.isPlanView) {
    updateTaskField({ taskCode: taskCode.value[0] })
  }
}
function updateTaskOwner(event: IBricks.Selector.Events.SelectorChange) {
  const newValue = event.detail.value
  taskOwner.value = newValue
  if (props.isPlanView) {
    updateTaskField({ taskOwner: taskOwner.value[0] })
  }
}
function updateTaskDueDate(event: IBricks.DatePicker.Events.Change) {
  const newValue = event.detail.value as string
  taskDueDate.value = DateHelper.shortFormat(newValue)
  if (props.isPlanView) {
    updateTaskField({ taskDueDate: DateHelper.shortFormat(newValue) })
  }
}

function planStateChange(status: string) {
  taskStatus.value = status
  if (props.isPlanView) {
    updateTaskField({ taskStatus: status })
  }
}

function editTask() {
  isEditing.value = true
}
function saveTask() {
  // Do not save the task if there are validation errors
  if (
    taskCodeError.value.status == 'invalid' ||
    taskOwnerError.value.status == 'invalid' ||
    taskDueDateError.value.status == 'invalid'
  )
    return

  const taskData = {
    ...props.task,
    taskCode: taskCode.value[0],
    taskOwner: taskOwner.value[0],
    taskDueDate: DateHelper.shortFormat(taskDueDate.value),
    taskStatus: taskStatus.value
  }

  emit('update-task', taskData, true)
  isEditing.value = false
}
function cancelChanges() {
  isEditing.value = false
  taskCode.value = [originalTaskData.taskCode || originalTaskData.taskDescription]
  taskOwner.value = [originalTaskData.taskOwner]
  taskDueDate.value = originalTaskData.taskDueDate
  taskStatus.value = originalTaskData.taskStatus
  if (props.isPlanView) {
    updateTaskField({ ...originalTaskData })
  }
}
function deleteTask() {
  emit('delete-task', props.task.id)
}
const inputEvt = (e) => {
  if ((e.ctrlKey || e.metaKey) && (e.keyCode === 91 || e.keyCode === 67)) {
    return true
  }
  e.preventDefault()
  return false
}

const taskStatuses = PlanHelper.taskStatuses()
const isStatusCompletedOrCancelled = computed(() =>
  PlanHelper.disableStatus(props.planState as string)
)
const currentUserApplicationRoleLevel = computed(() => employeeStore.currentUser.applicationRoleLevel)
</script>
<template>
  <tr v-if="editing">
    <td v-if="isPlanView">
      <PlanState
        @plan-state-change="planStateChange"
        :identifier="task.id"
        :status="taskStatuses"
        :activeState="taskStatuses[taskStatus]"
        :isStatusCompleted="PlanHelper.disableStatus(task.taskStatus)"
        :is-editing="isEditing"
      />
    </td>
    <td>
      <bricks-selector
        filter
        hoist
        :accessible-title="t('task_description_label')"
        class="edit-task-selector"
        visual-style="floating"
        .value="taskCode"
        @bricks-selector-change="updateTaskCode"
        :fieldValidationState="taskCodeError"
      >
        <bricks-menu-item
          v-for="task of taskLibrary"
          :key="task.taskCode || task.taskDescription"
          :value="task.taskCode || task.taskDescription"
        >
          {{ t(task.taskCode) }}
        </bricks-menu-item>
      </bricks-selector>
    </td>

    <td>
      <bricks-selector
        hoist
        :accessible-title="t('task_owner_label')"
        class="edit-task-owner"
        visual-style="floating"
        .value="taskOwner"
        @bricks-selector-change="updateTaskOwner"
        :fieldValidationState="taskOwnerError"
      >
        <bricks-menu-item
          v-for="employee of assignableEmployees"
          :key="employee.dsid"
          :value="employee.dsid"
        >
          {{ employee.fullName() }}
        </bricks-menu-item>
      </bricks-selector>
    </td>
    <td>
      <bricks-date-picker
        hoist
        required
        :label="t('task_due_date_label')"
        visual-style="floating"
        .value="taskDueDate"
        :min-date="planStartDate"
        :max-date="planEndDate"
        :fieldValidationState="taskDueDateError"
        @bricks-date-picker-change="updateTaskDueDate"
        @input="inputEvt"
        @keydown="inputEvt"
        position="auto"
      />
    </td>
    <td>
      <div class="margin-top15">
        <a href="#" @click="saveTask()" class="anchor-link margin-right10">{{ t('save_label') }}</a>
        <a href="#" @click="cancelChanges()" class="anchor-link-delete">{{ t('cancel_label') }}</a>
      </div>
    </td>
  </tr>
  <tr v-else>
    <td v-if="isPlanView">
      <template v-if="currentUserApplicationRoleLevel === 'level_10'">
        <PlanState
          @plan-state-change="planStateChange"
          :identifier="task.id"
          :status="taskStatuses"
          :activeState="taskStatuses[taskStatus]"
          :isStatusCompleted="PlanHelper.disableStatus(task.taskStatus)"
          :is-editing="isEditing"
        />
      </template>
      <p
        :class="[
          'task-status-btn',
          `task-${task.taskStatus?.replace(/[_ ]/g, '').toLocaleLowerCase()}`
        ]"
        v-else
      >
        {{ taskStatuses[task.taskStatus] }}
      </p>
    </td>
    <td>{{ task.taskCode ? t(task.taskCode) : task.taskDescription }}</td>
    <td>{{ EmployeeHelper.fullNameFor(task.taskOwner) }}</td>
    <td :class="{'date-text-align': PlanHelper.disableStatus(planState as string)}">
      {{ d(DateHelper.newDate(task.taskDueDate)) }}
    </td>
    <td>
      <div v-if="!isStatusCompletedOrCancelled && userCanUpdatePlan">
        <a href="#" @click="editTask()" class="anchor-link margin-right10">{{ t('edit_label') }}</a>
        <a href="#" @click="deleteTask()" class="anchor-link-delete">{{ t('delete_label') }}</a>
      </div>
    </td>
  </tr>
</template>

<style scoped>
td {
  padding: 10px 40px 10px 20px;
  text-align: left;
}

td:first-child {
  width: 40%;
}

td:nth-child(2),
td:nth-child(3),
td:nth-child(4) {
  width: 20%;
}

td:not(:first-child) {
  padding-left: 0;
}

td:last-child {
  text-align: right;
}

.support-headers tbody td:first-child {
  width: 15%;
  border-bottom-left-radius: 8px;
  border-top-left-radius: 8px;
}

.support-headers tbody td:nth-child(2) {
  width: 34%;
}

.support-headers tbody td:nth-child(3) {
  width: 22.5%;
}

.support-headers tbody td:nth-child(4) {
  width: 12.5%;
}

.support-headers tbody td:last-child {
  padding-right: 20px;
  border-bottom-right-radius: 8px;
  border-top-right-radius: 8px;
  text-align: right;
}

.support-headers tbody td.date-text-align {
  text-align: left;
}

bricks-selector.edit-task-selector,
bricks-selector .support-headers bricks-selector {
  --bricks-selector-box-width: 93%;

  display: flex;
}

.support-headers .margin-top15 {
  margin-top: 0;
}

bricks-selector.edit-task-selector::part(filter),
.support-headers .edit-task-selector::part(filter) {
  width: 100%;
}
</style>

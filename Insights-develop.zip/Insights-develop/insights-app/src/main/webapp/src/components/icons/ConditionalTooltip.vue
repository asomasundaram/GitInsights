<script setup lang="ts">
defineProps({
  enableTooltip: Boolean,
  triggerEvent: {
    type: String,
    default: 'hover' // 'hover' or 'click'
  },
  delayShow: {
    type: Number,
    default: 0
  },
  delayHide: {
    type: Number,
    default: 0
  }
})
</script>

<template>
  <template v-if="enableTooltip">
    <bricks-tooltip
      :trigger-event="triggerEvent"
      :delayShowTooltip="delayShow"
      :delayHideTooltip="delayHide"
    >
      <slot name="content" />
      <slot name="tooltip-content" />
    </bricks-tooltip>
  </template>
  <template v-else>
    <slot name="content" />
  </template>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { usePlansStore } from '@/stores/plans'
import { useI18n } from 'vue-i18n'

const props = defineProps({
  tasksToAdd: {
    type: Array<String>,
    default: []
  }
})
defineEmits(['add-tasks-from-library'])

const plansStore = usePlansStore()
const { t } = useI18n()
const tasks = plansStore.taskLibrary
const filteredTasks = ref([] as any[])
const taskFilter = ref('all')
const taskSearchString = ref('')
const pageSize = 5
const currentPage = ref(1)

const paginatedTasks = computed(() => {
  const startIndex = (currentPage.value - 1) * pageSize
  const endIndex = startIndex + pageSize
  return filteredTasks.value.slice(startIndex, endIndex)
})

const pageCount = computed(() => Math.ceil(filteredTasks.value.length / pageSize))

function updateTaskFilter(event: CustomEvent) {
  // Only one value for the selection
  const newFilter = event.detail.value[0]
  taskFilter.value = newFilter
  filterTasks()
}
function filterTasks() {
  if (taskFilter.value === 'all') {
    filteredTasks.value = tasks
  } else {
    filteredTasks.value = tasks.filter((t) => t.taskType == taskFilter.value)
  }
}

function updateSelectedTasks(event: CustomEvent) {
  const eventDetails = event.detail
  if (eventDetails.checked) {
    props.tasksToAdd.push(eventDetails.value)
  } else {
    const taskIndex = props.tasksToAdd.indexOf(eventDetails.value)
    props.tasksToAdd.splice(taskIndex, 1)
  }
}

function filterTasksOnSearch(e: CustomEvent) {
  taskSearchString.value = e.detail.value
  filteredTasks.value = tasks.filter((task) => {
    const caseInsensitveDesc = t(task.taskCode).toLocaleLowerCase()
    return caseInsensitveDesc.includes(taskSearchString.value.toLocaleLowerCase())
  })
}

onMounted(() => {
  filterTasks()
})
</script>

<template>
  <div>
    <div class="margin-bottom-60 margin-top-40">
      <div class="float-left">
        <h4 class="title">{{ t('task_library_label') }}</h4>
      </div>
      <div class="float-right">
        <div class="filter-section float-left margin-right10">
          <!-- <bricks-label>Filter Tasks By:</bricks-label> -->
          <bricks-selector
            filter
            id="filter-select-box"
            accessible-title="Filter Tasks"
            class="single-select"
            :value="taskFilter"
            @bricks-selector-change="updateTaskFilter"
          >
            <bricks-menu-item value="all">{{ t('all_tasks_label') }}</bricks-menu-item>
            <bricks-menu-item value="MANAGER">{{ t('manager_task_label') }}</bricks-menu-item>
            <bricks-menu-item value="ANALYST">{{ t('analyst_task_label') }}</bricks-menu-item>
          </bricks-selector>
        </div>
        <div class="filter-section float-left">
          <bricks-text-field
            variation="search"
            place-holder-text="Search"
            show-helper-text="true"
            show-clear-button="true"
            :value="taskSearchString"
            @bricks-text-field-change="filterTasksOnSearch"
          />
        </div>
      </div>
      <div class="clear"></div>
    </div>
    <table>
      <thead>
        <tr>
          <th colspan="3">{{ t('task_label') }}</th>
          <!-- <th>Task Owner</th> -->
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="(task, index) in paginatedTasks"
          :key="index"
          :class="{ selected: task.isSelected }"
        >
          <td :style="{ width: '100%' }">
            <bricks-checkbox
              :value="task.taskCode"
              :label="t(task.taskCode)"
              :checked="tasksToAdd.includes(task.taskCode)"
              @bricks-check-box-change="updateSelectedTasks"
            />
          </td>
          <!-- <td :style="{ width: '150px', marginLeft: 'auto' }">{{ t(task.taskType) }}</td> -->
        </tr>
      </tbody>
    </table>
    <div class="pagination">
      <button :disabled="currentPage === 1" @click="currentPage--">&lt;</button>
      <span>{{ currentPage }} of {{ pageCount }}</span>
      <button :disabled="currentPage === pageCount" @click="currentPage++">&gt;</button>
    </div>
  </div>
</template>

<style scoped>
.filter-bar {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  width: 40%;
  padding: 8px;
  text-align: left;
}

th:first-child,
td:first-child {
  width: 20%;
}

th:last-child,
td:last-child {
  width: 30%;
}

thead,
tbody {
  display: block;
}

thead tr {
  display: flex;
  margin-bottom: 5px;
}

tbody tr {
  display: flex;
  border-radius: 5px;
  margin-bottom: 15px;
  background-color: #fff;
  box-shadow: rgb(99 99 99 / 20%) 0 1px 6px 2px;
}

tr.selected {
  border: 1px solid #2997ff;
}

button {
  border: none;
  margin: 0 5px;
  font-size: 16px;
}

.pagination {
  width: 115px;
  margin: 0 auto;
}

.search-input {
  min-height: 33px;
  padding: 0 0 0 10px;
  border: 1px solid #d1d1d1;
  border-radius: 5px;
}
</style>

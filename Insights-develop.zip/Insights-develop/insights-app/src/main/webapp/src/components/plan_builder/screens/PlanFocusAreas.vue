<script setup lang="ts">
import { computed, type PropType } from 'vue'
import { Plan } from '@/classes/Plan'
import { usePlansStore } from '@/stores/plans'
import { useI18n } from 'vue-i18n'
import PlanDetailsForm from './PlanDetailsForm.vue'
import type { IBricks } from '@nexus/bricks-vue'

const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  }
})

const emit = defineEmits(['update-draft-field'])

const { t } = useI18n()
const plansStore = usePlansStore()

const selectedFocusAreas = computed(() =>
  props.planData.focusAreaMetrics.map((focus) => focus.focusArea)
)

const options = plansStore.focusMetricLibrary

const mainValidationState = computed(() => {
  if (props.planData.focusAreaMetrics.length < 1)
    return {
      status: 'invalid',
      message: t('error_focus_area_required')
    }
  return { status: 'valid', message: '' }
})

function validateFocusAreaMetrics(focusArea: string) {
  const focus = props.planData.focusAreaMetrics.find((focus) => focus.focusArea == focusArea)
  if (!focus) return { status: 'invalid', message: t('error_unknown_error') }

  if (focus.focusAreaMetrics.length < 1)
    return {
      status: 'invalid',
      message: t('error_metric_required')
    }

  return {
    status: 'valid',
    message: ''
  }
}

const focusAreaMetricsFor = (focusArea: string) => {
  console.log('focusAreaMetricsFor', focusArea)
  const focusAreaData = options.find((option) => option.focusArea === focusArea)
  if (!focusAreaData) return []
  return focusAreaData.focusAreaMetrics
}

function updateSelection(event: IBricks.Selector.Events.SelectorChange) {
  const newValue = event.detail.value
  const convertedFocusAreas = newValue.map((focusArea) => {
    const existingFocus = props.planData.focusAreaMetrics.find(
      (focus) => focus.focusArea == focusArea
    )
    return existingFocus
      ? existingFocus
      : {
          focusArea,
          focusAreaMetrics: []
        }
  })
  console.log('UpdateFocusArea', newValue)
  console.log('convertedFocusAreas', convertedFocusAreas)

  emit('update-draft-field', { field: 'focusAreaMetrics', value: convertedFocusAreas })
}

function updateSecondarySelection(
  focusArea: string,
  event: IBricks.Selector.Events.SelectorChange
) {
  const newValue = event.detail.value

  const convertedFocusAreas = props.planData.focusAreaMetrics.map((focus) => {
    if (focus.focusArea != focusArea) return focus
    focus.focusAreaMetrics = newValue
    return focus
  })
  emit('update-draft-field', { field: 'focusAreaMetrics', value: convertedFocusAreas })
}
</script>

<template>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6 pr pl">
        <PlanDetailsForm :planData="planData" readOnly />
      </div>
      <div class="col-md-6 pl pr">
        <div class="metrics-div">
          <h3 class="plan-title">{{ t('focus_area_label') }}</h3>
          <p class="title-name">{{ t('choose_focus_areas_label') }}</p>

          <bricks-selector
            mode="multiple"
            hoist
            class="full-width"
            visual-style="floating"
            :accessible-title="t('select_up_to_three')"
            @bricks-selector-change="updateSelection"
            :value="selectedFocusAreas"
            :fieldValidationState="mainValidationState"
          >
            <template v-for="option in options" :key="option.focusArea">
              <bricks-menu-item :value="option.focusArea">
                {{ t(option.focusArea) }}
              </bricks-menu-item>
            </template>
          </bricks-selector>

          <div
            v-for="focus in planData.focusAreaMetrics"
            class="second-dropdowns"
            :key="focus.focusArea"
          >
            <p class="title-name">
              {{ t(focus.focusArea) }}
            </p>
            <bricks-selector
              mode="multiple"
              hoist
              class="full-width"
              visual-style="floating"
              :accessible-title="t('aiml_choose_focus_metrics')"
              :value="focus.focusAreaMetrics"
              @bricks-selector-change="updateSecondarySelection(focus.focusArea, $event)"
              :fieldValidationState="validateFocusAreaMetrics(focus.focusArea)"
            >
              <template
                v-for="focusAreaMetric in focusAreaMetricsFor(focus.focusArea)"
                :key="focusAreaMetric"
              >
                <bricks-menu-item :value="focusAreaMetric">
                  {{ t(focusAreaMetric) }}
                </bricks-menu-item>
              </template>
            </bricks-selector>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.plan-title {
  color: var(--header-text-color);
  font-size: 20px;
  font-weight: 400;
  letter-spacing: -0.48px;
  line-height: 22px;
  text-align: center;
}

.title-name {
  padding-top: 10px;
  margin-top: 7px;
  margin-bottom: 5px;
  color: var(--header-text-color);
  font-size: 18px;
  font-weight: 400;
  letter-spacing: -0.43px;
  line-height: 22px;
  text-align: left;
}

.second-dropdowns {
  margin-top: 10px;
}

.metrics-div {
  height: 350px;
  align-items: flex-start;
  padding-left: 4rem;
  margin-top: 25px;
  overflow-y: scroll;
  text-align: left;
}

.pl {
  padding-left: 0;
}

.pr {
  padding-right: 0;
}

bricks-selector.full-width {
  display: flex;
  min-width: min-content;
  flex-direction: column;
  border-radius: 8px;
  margin-right: 20px;
  background: #fff;
  text-align: left;

  --bricks-selector-box-border-color: #e7e7e7;
  --bricks-selector-box-width: 100%;
}
</style>

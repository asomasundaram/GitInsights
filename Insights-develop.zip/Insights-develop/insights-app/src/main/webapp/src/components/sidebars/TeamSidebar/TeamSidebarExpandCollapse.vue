<script setup lang="ts">
/* eslint-disable vue/no-deprecated-slot-attribute */
import ChevronRight from '@/components/icons/sfsymbols/chevron.right.vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
defineProps({
  collapsed: {
    type: Boolean,
    default: false
  }
})
</script>

<template>
  <div class="expand-collapse-button" @click="$emit('toggle-sidebar-collapse')">
    <bricks-button
      visual-style="secondary"
      :accessible-title="t('expand_collapse_label')"
      shape="round-rect"
      size="large"
      class="bricks-button"
    >
      <bricks-icon slot="icon">
        <ChevronRight class="icon" :class="{ collapsed }" />
      </bricks-icon>
    </bricks-button>
  </div>
</template>

<style scoped>
.expand-collapse-button {
  width: 100%;
  align-items: start;
  padding: 0;
  margin: 0;
  margin-bottom: 15px;
}

.expand-collapse-button .bricks-button {
  scale: calc(80%);
}

.expand-collapse-button .icon {
  transition-duration: 0.25s;
  transition-property: transform;
  transition-timing-function: ease-in-out;
}

.expand-collapse-button .icon.collapsed {
  transform: rotate(180deg);
}
</style>

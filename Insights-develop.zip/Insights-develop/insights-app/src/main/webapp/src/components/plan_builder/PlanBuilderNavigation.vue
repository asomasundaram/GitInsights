<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
const props = defineProps({
  currentScreen: {
    type: Number,
    default: 1
  },
  totalScreens: Number,
  nextDisabled: Boolean,
  planType: {
    type: String,
    required: true
  },
  planMonthAndYearError: Boolean
})
const emit = defineEmits(['navigate-screen'])
const { t } = useI18n()

const previousScreen = computed(() => {
  return props.currentScreen - 1
})
const nextScreen = computed(() => {
  return props.currentScreen + 1
})
const navigateThroughDots = (index: number) => {
  if (props.planType.includes('no_plan')) return
  emit('navigate-screen', index)
}
</script>
<template>
  <div class="plan-builder-footer">
    <div class="plan-builder-footer-buttons">
      <bricks-button
        visual-style="secondary"
        :accessible-title="t('back_label')"
        class="margin-right15"
        :disabled="currentScreen == 1"
        @bricks-click="$emit('navigate-screen', previousScreen)"
      >
        {{ t('back_label') }}
      </bricks-button>
      <bricks-button
        visual-style="primary"
        :accessible-title="t('next_label')"
        v-if="currentScreen !== 3"
        :disabled="planType?.includes('no_plan') || nextDisabled || planMonthAndYearError"
        @bricks-click="$emit('navigate-screen', nextScreen)"
      >
        {{ currentScreen === 2 ? t('build_plan_label') : t('next_label') }}
      </bricks-button>
    </div>
    <div class="dot-indicators">
      <span
        v-for="i in totalScreens"
        :key="i"
        :class="{
          active: currentScreen === i,
          disabled: planType?.includes('no_plan') || planMonthAndYearError
        }"
        @click="navigateThroughDots(i)"
      >
      </span>
    </div>
  </div>
</template>

<style scoped>
.plan-builder-footer {
  position: relative;
  width: 100%;
  margin-top: 2rem;
}

.margin-right15 {
  margin-right: 15px;
}

.plan-builder-footer-buttons {
  padding-bottom: 10px;
  margin: 0 auto;
  text-align: center;
}

.dot-indicators {
  width: 80px;
  margin: 0 auto;

  /* text-align: center;
    margin-top: 10px; */
}

.dot-indicators span {
  display: inline-block;
  width: 10px;
  height: 10px;
  border-radius: 5px;
  margin: 0 5px;
  background-color: #ccc;
  cursor: pointer;
}

.dot-indicators span.active {
  background-color: #333;
}

.dot-indicators span.disabled {
  background-color: rgb(0 0 0 / 4%);
  cursor: not-allowed;
}
</style>

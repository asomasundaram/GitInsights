<script setup lang="ts">
import { ref, computed, defineEmits, type PropType, onUpdated } from 'vue'
import { type Plan } from '@/classes/Plan'
import { useRoute } from 'vue-router'
import { usePlansStore } from '@/stores/plans'
import Plus from '@/components/icons/sfsymbols/plus.vue'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import AddNewTask from '@/components/commons/AddNewTask.vue'
import type { InsightsPlanSupportingTask } from '@/types/InsightsTypes'
import { useI18n } from 'vue-i18n'
import TasklibraryModal from '@/components/plan_builder/screens/TasklibraryModal.vue'
import PlanHelper from '@/helpers/PlanHelper'
import SupportingTask from '@/components/plan_builder/screens/SupportingTask.vue'

const emit = defineEmits(['addNewTask', 'update-task', 'task-update-success'])
const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  },
  saveFlag: Boolean,
  userCanUpdatePlan: {
    type: Boolean,
    required: true
  }
})

const route = useRoute()
const newTaskModalOpen = ref(false)
const showSpinner = ref(false)
const errorNotifier = ref()
const taskLibraryOpen = ref(false)
const tasksToAdd = ref([] as string[])
const toastMessage = ref('')
const isUpdateSuccessful = ref(false)
const plansStore = usePlansStore()
const planId = route.query.plan as string
const { t } = useI18n()

const taskLibrary = plansStore.taskLibrary

const currentPlan = computed(() => props.planData as Plan)
const tasks = computed(() => {
  if (planId && currentPlan.value) {
    return currentPlan.value.tasks
  }
  return
})

const saveTaskOfPlan = () => {
  if (currentPlan.value) {
    showSpinner.value = true
    plansStore
      .updatePlanData(currentPlan.value)
      .then(() => {
        showSpinner.value = false
        isUpdateSuccessful.value = true
        toastMessage.value = t('updated_saved_label')
        invokeNotification()
        emit('task-update-success', true)
      })
      .catch((error: Error) => {
        showSpinner.value = false
        isUpdateSuccessful.value = false
        toastMessage.value = error.message
        emit('task-update-success', false)
      })
  }
  return
}

function openNewTaskModal() {
  newTaskModalOpen.value = true
}

function hideNewTaskModal() {
  newTaskModalOpen.value = false
}

function updatePlan(updatedTasks: Array<InsightsPlanSupportingTask>) {
  const updatedPlan = {
    ...currentPlan.value,
    tasks: updatedTasks
  } as Plan
  plansStore.updatePlan(updatedPlan.id, updatedPlan)
  return
}

function addNewTask(task: InsightsPlanSupportingTask) {
  if (tasks.value) {
    tasks.value.push(task)
    updatePlan(tasks.value)
  }
  return
}

function openTaskLibrary() {
  taskLibraryOpen.value = true
}
function closeTaskLibrary() {
  taskLibraryOpen.value = false
  tasksToAdd.value = []
}
function addTasksFromLibrary() {
  if (!currentPlan.value) return
  const newTasks = tasksToAdd.value.map((key: string) => {
    return {
      id: window.crypto.randomUUID(),
      taskCode: key,
      taskOwner: currentPlan.value.planDsid,
      taskDueDate: currentPlan.value.planEndDate,
      taskStatus: 'IN_PROGRESS',
      // These two fields are added to keep in sync with `InsightsPlanSupportingTask` structure
      taskDescription: '',
      taskType: ''
    }
  })
  if (tasks.value) {
    tasks.value.push(...newTasks)
    updatePlan(tasks.value)
  }
  closeTaskLibrary()
}

function invokeNotification() {
  errorNotifier.value.queue()
}

const assignableEmployees = computed(() => {
  const list = EmployeeHelper.employeeDsidsForTasks(props.planData)
  return list.map((dsid: string) => EmployeeHelper.findEmployee(dsid))
})

function editTask(taskID: string, editMode: boolean) {
  emit('update-task', taskID, editMode)
}

function updateTask(taskData: InsightsPlanSupportingTask, apiCall: boolean = false) {
  const existingTasks = PlanHelper.cloneObject(props.planData.tasks)
  const updatedTasks = existingTasks.map((task: InsightsPlanSupportingTask) => {
    return task.id == taskData.id ? taskData : task
  })
  updatePlan(updatedTasks)
  if (apiCall) saveTaskOfPlan()
}

function deleteTask(taskUUID: string) {
  const existingTasks = PlanHelper.cloneObject(props.planData.tasks)

  const remainingTasks = existingTasks.filter(
    (task: InsightsPlanSupportingTask) => task.id != taskUUID
  )
  updatePlan(remainingTasks)
}

const allowTaskToAdd = computed(() => {
  const startDate = +new Date(props.planData.planStartDate)
  const endDate = +new Date(props.planData.planEndDate)

  if (endDate - startDate < 86400000 * 11) {
    return true
  }
  return false
})

onUpdated(() => {
  // After the changes are flused to DOM, we need to set `task-update-success` as `false`
  if (isUpdateSuccessful.value) {
    emit('task-update-success', false)
  }
})
</script>

<template>
  <section class="supporting-tasks-sec">
    <div class="header-section">
      <div class="header-right">
        <bricks-button
          visual-style="tertiary"
          :accessible-title="t('open_task_library_label')"
          class="anchor-link margin-right10"
          @bricks-click="openTaskLibrary"
          :disabled="PlanHelper.disableStatus(currentPlan.planState) || allowTaskToAdd"
        >
          {{ t('open_library_label') }}
        </bricks-button>
        <bricks-button
          visual-style="alternative"
          @bricks-click="openNewTaskModal"
          :disabled="PlanHelper.disableStatus(currentPlan.planState) || allowTaskToAdd"
        >
          <bricks-icon slot="icon">
            <Plus class="plus-icon" />
          </bricks-icon>
          {{ t('new_task_label') }}
        </bricks-button>
      </div>
    </div>
    <table class="support-headers">
      <thead>
        <tr>
          <th class="status">{{ t('task_status_label') }}</th>
          <th class="task">{{ t('task_label') }}</th>
          <th class="task-own">{{ t('task_owner_label') }}</th>
          <th>{{ t('task_due_date_label') }}</th>
        </tr>
      </thead>
      <tbody>
        <SupportingTask
          v-for="task in tasks"
          :key="task.id"
          :assignable-employees="assignableEmployees"
          :plan-end-date="planData.planEndDate"
          :plan-start-date="planData?.planStartDate"
          :task="task"
          :task-library="taskLibrary"
          @update-task="updateTask"
          @delete-task="deleteTask"
          @edit-task="editTask"
          isPlanView
          :planViewSaveFlag="saveFlag"
          :planState="currentPlan.planState"
          :user-can-update-plan="userCanUpdatePlan"
        />
      </tbody>
    </table>
  </section>
  <AddNewTask
    v-if="newTaskModalOpen"
    :openTaskModal="newTaskModalOpen"
    :plan-data="planData"
    @add-new-task="addNewTask"
    @hide-new-task-modal="hideNewTaskModal"
  />
  <template v-if="taskLibraryOpen">
    <bricks-dialog
      behavior="modal"
      .isOpen="taskLibraryOpen"
      @bricks-dialog-close="closeTaskLibrary"
      class="supporting-task-library-modal"
    >
      <span slot="body">
        <TasklibraryModal :tasksToAdd="tasksToAdd" />
      </span>
      <bricks-button
        slot="footer-primary"
        default
        visual-style="primary"
        @bricks-click="addTasksFromLibrary"
      >
        {{ t('add_label') }}
      </bricks-button>
      <bricks-button
        slot="footer-secondary"
        @bricks-click="closeTaskLibrary"
        visual-style="secondary"
      >
        {{ t('cancel_label') }}
      </bricks-button>
    </bricks-dialog>
  </template>
  <bricks-spinner size="44" fullScreen isOverlay v-if="showSpinner"></bricks-spinner>
  <div class="component-holder">
    <bricks-toast
      class="regular-toast top-right"
      :class="{ 'error-updating': !isUpdateSuccessful }"
      ref="errorNotifier"
      duration="4000"
    >
      {{ toastMessage }}
    </bricks-toast>
  </div>
</template>

<style scoped>
.header-section {
  display: flex;
}

.header-section .header-right {
  display: flex;
  margin-left: auto;

  --bricks-button-alternative-border-color: #007aff;
  --bricks-button-alternative-text-color: #007aff;
}

bricks-button:not(.anchor-link)::part(base) {
  border-color: #007aff;
}

.supporting-tasks-sec {
  padding: 5px;
}

.support-headers {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0 15px;
}

.support-headers th {
  font-size: 14px;
  opacity: 0.5;
}

.support-headers th:first-child {
  padding-left: 20px;
}

.each-task {
  display: flex;
  align-items: center;
  padding: 7px 20px;
  border-radius: 5px;
  margin-bottom: 10px;
  box-shadow: rgb(99 99 99 / 20%) 0 1px 6px 2px;
}

.task-own-p,
.task-p {
  padding-right: 50px;
}

bricks-spinner {
  --bricks-spinner-overlay: rgb(212 246 218 / 30%);
  --bricks-spinner-native-bg-color: #2e7d32;
}

bricks-dialog {
  --bricks-dialog-width: 800px;
}

.support-headers tbody tr {
  border-radius: 5px;
  background-color: #fff;
  box-shadow: rgb(99 99 99 / 20%) 0 1px 6px 2px;
}
</style>

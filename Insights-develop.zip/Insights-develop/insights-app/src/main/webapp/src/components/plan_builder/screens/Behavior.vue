<script setup lang="ts">
import { computed, ref, type PropType } from 'vue'
import { useI18n } from 'vue-i18n'
import type { InsightsBehavior, InsightsPlanBehavior } from '@/types/InsightsTypes'
import type { IBricks } from '@nexus/bricks-vue'

const { t } = useI18n()

const props = defineProps({
  behavior: {
    type: Object as PropType<InsightsPlanBehavior>,
    required: true
  },
  behaviorLibrary: {
    type: Array as PropType<InsightsBehavior[]>,
    required: true
  },
  metricLibrary: {
    type: Array<string>,
    required: true
  }
})

const emit = defineEmits(['update-behavior', 'delete-behavior'])

const behaviorCode = ref([props.behavior.behaviorCode || props.behavior.behaviorDescription])

const behaviorCodeError = computed(() => {
  if (!behaviorCode.value.length || behaviorCode.value[0] == '')
    return { status: 'invalid', message: t('error_missing_behavior_description') }
  return { status: 'valid', messagge: '' }
})

function updateBehaviorCode(event: IBricks.Selector.Events.SelectorChange) {
  const selectorValue = event.detail.value as IBricks.Selector.value
  behaviorCode.value = selectorValue
}

const metricCode = ref([props.behavior.behaviorMetricCode])
const metricCodeError = computed(() => {
  if (!metricCode.value[0] || metricCode.value[0] == '') {
    return { status: 'invalid', message: t('error_missing_behavior_metric') }
  }
  return { status: 'valid', message: '' }
})

function updateMetricCode(event: IBricks.Selector.Events.SelectorChange) {
  const selectorValue = event.detail.value as IBricks.Selector.value
  metricCode.value = selectorValue
}

const isEditing = ref(false)

const editing = computed(() => {
  // Set Editing to true if the behavior was just created and has no metric or
  // behavior code/description, otherwise go by the isEditing state
  if (
    (!props.behavior.behaviorCode || !props.behavior.behaviorDescription) &&
    !props.behavior.behaviorMetricCode
  )
    return true
  return isEditing.value
})

function setEditBehavior(status: boolean) {
  isEditing.value = status
}
function cancelEdit() {
  // Reset inputs to their initial values
  behaviorCode.value = [props.behavior.behaviorCode || props.behavior.behaviorDescription]
  metricCode.value = [props.behavior.behaviorMetricCode]

  // If the props behavior doesn't have text, delete it instead of cancelling
  // edit
  if (
    props.behavior.behaviorCode == '' &&
    props.behavior.behaviorDescription == '' &&
    props.behavior.behaviorMetricCode == ''
  ) {
    deleteBehavior()
  } else {
    setEditBehavior(false)
  }
}
function saveBehavior() {
  // If both inputs have a 'valid' error status, emit a save
  if (metricCodeError.value.status == 'valid' && behaviorCodeError.value.status == 'valid') {
    const updatedBehaviorData = {
      ...props.behavior,
      behaviorCode: behaviorCode.value[0],
      behaviorMetricCode: metricCode.value[0]
    }
    emit('update-behavior', updatedBehaviorData)
    setEditBehavior(false)
  }
}
function deleteBehavior() {
  emit('delete-behavior', props.behavior.id)
}
</script>
<template>
  <tr class="behavior-row">
    <template v-if="editing">
      <td>
        <bricks-selector
          required
          filter
          hoist
          :accessible-title="t('select_one_label')"
          class="behavior-selector"
          visual-style="floating"
          :value="behaviorCode"
          :fieldValidationState="behaviorCodeError"
          @bricks-selector-change="updateBehaviorCode"
        >
          <bricks-menu-item
            v-for="libraryBehavior of behaviorLibrary"
            :value="libraryBehavior.behaviorCode"
            :key="libraryBehavior.behaviorCode"
          >
            {{ t(libraryBehavior.behaviorCode) }}
          </bricks-menu-item>
        </bricks-selector>
      </td>

      <td>
        <bricks-selector
          required
          filter
          hoist
          :accessible-title="t('select_one_label')"
          class="metric-selector"
          visual-style="floating"
          :value="metricCode"
          :fieldValidationState="metricCodeError"
          @bricks-selector-change="updateMetricCode"
        >
          <bricks-menu-item v-for="metricCode of metricLibrary" :value="metricCode">
            {{ t(metricCode) }}
          </bricks-menu-item>
        </bricks-selector>
      </td>

      <td>
        <div class="behavior-button-row">
          <bricks-button
            visual-style="link"
            :accessible-title="t('save_label')"
            class="bricks-button"
            @bricks-click="saveBehavior"
          >
            {{ t('save_label') }}
          </bricks-button>
          <bricks-button
            visual-style="link"
            :accessible-title="t('cancel_label')"
            class="bricks-button anchor-link-delete"
            @bricks-click="cancelEdit"
          >
            {{ t('cancel_label') }}
          </bricks-button>
        </div>
      </td>
    </template>
    <template v-else>
      <td>{{ behavior.behaviorCode ? t(behavior.behaviorCode) : behavior.behaviorDescription }}</td>
      <td>{{ t(behavior.behaviorMetricCode) }}</td>
      <td>
        <div class="behavior-button-row">
          <bricks-button
            visual-style="link"
            :accessible-title="t('edit_label')"
            class="bricks-button"
            @bricks-click="setEditBehavior(true)"
          >
            {{ t('edit_label') }}
          </bricks-button>
          <bricks-button
            visual-style="link"
            :accessible-title="t('delete_label')"
            class="bricks-button anchor-link-delete"
            @bricks-click="deleteBehavior"
          >
            {{ t('delete_label') }}
          </bricks-button>
        </div>
      </td>
    </template>
  </tr>
</template>

<style scoped>
bricks-selector.behavior-selector {
  --bricks-selector-box-width: 500px;
}

bricks-selector.metric-selector {
  --bricks-selector-box-width: 190px;
}

.behavior-row {
  display: flex;
  align-items: center;
  padding: 15px;
}

.behavior-button-row {
  display: flex;
  justify-content: end;
}

.behavior-button-row bricks-button + bricks-button {
  margin-left: 15px;
}

/* Hoist isn't working. So, added height. */
bricks-selector.behavior-selector::part(menu) {
  --bricks-menu-max-height: 250px;
}

bricks-button::part(base) {
  text-decoration: none;
}

.anchor-link-delete::part(title) {
  color: #d63384;
}

td:first-child {
  width: 53%;
}

td:last-child {
  width: 20%;
  text-align: right;
}

td:nth-child(2) {
  width: 25%;
}
</style>

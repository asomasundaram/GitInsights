<script setup lang="ts">
import { ref } from 'vue'
import Time from '@/components/icons/sfsymbols/time.vue'
import Hold from '@/components/icons/sfsymbols/hold.vue'
import Notify from '@/components/icons/sfsymbols/notify.vue'
import XCircleFill from '@/components/icons/sfsymbols/x.circle.fill.vue'
import CheckmarkCircleFill from '@/components/icons/sfsymbols/checkmark.circle.fill.vue'
import PlanHelper from '@/helpers/PlanHelper'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const props = defineProps({
  tasksCountData: {
    type: Object,
    required: true
  }
})
const emit = defineEmits(['selected-filters'])
const filteredStates = ref([] as String[])
const disableFilterFor = ref([] as String[])
const dueAndCompletedTasks = ['DUE_SOON', 'OVERDUE', 'COMPLETED']

function icon(taskState: string) {
  switch (taskState) {
    case 'IN_PROGRESS':
      return Time
    case 'ON_HOLD':
      return Hold
    case 'INCOMPLETE':
      return Notify
    case 'CANCELLED':
      return XCircleFill
    default:
      return CheckmarkCircleFill
  }
}

const selectFilter = (statusName: string, e: CustomEvent) => {
  if (filteredStates.value.includes(statusName)) {
    filteredStates.value = filteredStates.value.filter((state) => state !== statusName)
  } else {
    filteredStates.value.push(statusName)
  }

  if (filteredStates.value.length) {
    if (dueAndCompletedTasks.includes(statusName)) {
      disableFilterFor.value = ['IN_PROGRESS', 'ON_HOLD', 'INCOMPLETE', 'CANCELLED']
    } else {
      disableFilterFor.value = ['DUE_SOON', 'OVERDUE', 'COMPLETED']
    }
  } else {
    disableFilterFor.value = []
  }
  emit('selected-filters', filteredStates.value)
  return
}

const taskFilterOptions = PlanHelper.taskFilterOptions()
</script>
<template>
  <section class="header-section">
    <bricks-card class="card-container" header="Overview">
      <div class="body-content">
        <template v-for="(task, name, index) in taskFilterOptions" :key="name">
          <bricks-button
            visual-style="alternative"
            :disabled="disableFilterFor.includes(name as string)"
            :class="['bricks-button', (name as string).replace('_', '-').toLocaleLowerCase()]"
            @bricks-click="(e: CustomEvent) => selectFilter(name as string, e)"
          >
            <div
              class="card-header-width-height"
              v-if="dueAndCompletedTasks.includes(name as string)"
            >
              <p class="count">{{ tasksCountData[name] }}</p>
            </div>
            <div class="card-header-width-height" v-else>
              <bricks-icon
                color="secondary"
                size="extra-large"
                :class="(name as string).replace('_', '-').toLocaleLowerCase()"
              >
                <component :is="icon(name as string)"></component>
              </bricks-icon>
            </div>
            <p class="status-name">{{ task }}</p>
            <p v-if="!dueAndCompletedTasks.includes(name as string)">
              {{ t('task_count', { count: tasksCountData[name] }) }}
            </p>
            <XCircleFill class="x-icon" v-show="filteredStates.includes(name as string)" />
          </bricks-button>
          <hr v-if="index === 2" />
        </template>
      </div>
    </bricks-card>
  </section>
</template>
<style scoped>
@import url('@/assets/variables.css');

.header-section {
  padding-bottom: 18px;
  background: #f1f5fc;
  font-size: 16px;
  overflow-x: auto;
}

.header-section .card-container {
  margin-left: 45px;
}

bricks-card::part(base) {
  padding: 0;
  border-radius: 0;
}

bricks-button {
  --bricks-button-alternative-text-color: #3a3a3a;

  width: 136px;
  height: 168px;
  margin-right: 18px;
}

bricks-button p {
  opacity: 0.8;
}

.due-soon::part(base) {
  border-left: 4px solid #ff9f0a;
}

.overdue::part(base) {
  border-left: 4px solid #ff453a;
}

.completed::part(base) {
  border-left: 4px solid #32d74b;
}

bricks-button::part(base) {
  display: block;
  padding: 32px 25px 45px;
  border: none;
  box-shadow: 0 0 13px 3px rgb(0 0 0 / 8%);
  text-align: left;
}

bricks-card::part(heading) {
  margin-bottom: 19px;
  color: #3a3a3a;
  font-size: 28px;
  font-weight: 600;
}

.count {
  font-size: 38px;
  font-weight: 600;
  opacity: 0.85;
}

.count span {
  font-size: 14px;
  opacity: 0.65;
}

.status-name {
  margin-top: 12px;
  font-size: 18px;
  font-weight: 500;
  opacity: 0.85;
}

.card-header-width-height {
  width: 56px;
  height: 56px;
}

bricks-icon {
  width: 100%;
  height: 100%;
  border-radius: 8px;
}

bricks-icon::part(base) {
  display: flex;
  align-items: center;
  justify-content: center;
}

svg {
  width: 25px;
  height: 25px;
}

.in-progress bricks-icon {
  background-color: #feeacd;
}

.in-progress svg {
  fill: var(--action-plan-bg-color);
}

.on-hold bricks-icon {
  background-color: #f0ddf9;
}

.on-hold svg {
  fill: var(--task-on-hold-bg-color);
}

.incomplete bricks-icon {
  background-color: #fff4cd;
}

.incomplete svg {
  fill: #fc0;
}

.cancelled bricks-icon {
  background-color: #ffdbd8;
}

.cancelled svg {
  fill: #ff453a;
}

.body-content {
  position: relative;
  display: flex;
}

.body-content hr {
  border-left: 1px solid #979797;
  margin: 0 18px 0 0;
}

svg.x-icon {
  position: absolute;
  top: -13px;
  left: 123px;
  fill: #98989d;
}

@media screen and (width <= 1480px) {
  bricks-button {
    width: 110px;
    height: 148px;
    margin-right: 15px;
  }

  .status-name {
    font-size: 16px;
  }

  bricks-button::part(base) {
    padding: 25px 15px 38px;
  }

  .header-section .card-container {
    margin-left: 35px;
  }
}
</style>

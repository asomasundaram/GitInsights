<script setup lang="ts">
import { computed, type PropType } from 'vue'
import { Employee } from '@/classes/Employee'
import { useI18n } from 'vue-i18n'
import Avatar from '@/components/icons/Avatar.vue'

const { t } = useI18n()
const props = defineProps({
  currentUser: {
    type: Employee,
    default: null
  }
})

const currentUserName = computed(() => {
  const user = props.currentUser as Employee
  if (!user) return ' John AppleSeed'
  return user.fullName()
})

const logout = () => {
  console.log('CurrentUserProfile.logout: Logging user out...')
  window.location.href = window.location.origin + '/logout'
}
</script>
<template>
  <div class="user-profile-section">
    <bricks-menu-button class="user-profile-button" placement="auto">
      <bricks-button
        slot="trigger"
        variation="standard"
        visual-style="inline"
        size="small"
        :accessible-title="t('user_actions_label')"
      >
        <Avatar :employee="currentUser" />
      </bricks-button>
      <bricks-menu>
        <bricks-menu-item disabled>{{ currentUserName }}</bricks-menu-item>
        <bricks-menu-divider />
        <bricks-menu-item @click="logout">{{ t('logout_label') }}</bricks-menu-item>
      </bricks-menu>
    </bricks-menu-button>
  </div>
</template>

<style scoped>
.user-profile-section {
  display: flex;
  width: 100%;
  height: 50px;
  align-items: center;
  justify-content: space-around;
}
</style>

<script setup lang="ts">
import { computed, type PropType } from 'vue'
import { Plan } from '@/classes/Plan'
import { useI18n } from 'vue-i18n'
import DateHelper from '@/helpers/DateHelper'
import { usePlansStore } from '@/stores/plans'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import PlanBehaviorDetails from '@/components/plan_view/PlanBehaviorDetails.vue'
import PlanCompetencyFocus from '@/components/plan_view/PlanCompetencyFocus.vue'

const props = defineProps({
  isPreviewOpen: {
    type: Boolean,
    required: true
  },
  planData: {
    type: Object as PropType<Plan>,
    required: true
  }
})

const { t, d } = useI18n()
const plansStore = usePlansStore()
const planMonthDateObj = computed(() => {
  const date = DateHelper.dateFromPlanMonthAndYear(
    props.planData.planMonth,
    props.planData.planYear
  )
  return date
})

const lastThreeMonthsData = computed(() => {
  const lastThreeMonthsPlans = plansStore.lastThreeMonths(props.planData.planDsid)
  if (lastThreeMonthsPlans.length) {
    const shortFormatPlanTypes = lastThreeMonthsPlans.map(
      ({ id, planMonth, planYear, planType }) => ({
        id,
        planMonth,
        planYear,
        planType
      })
    )
    return shortFormatPlanTypes
  }
  return []
})

const employeeFullName = computed(() => {
  return EmployeeHelper.fullNameFor(props.planData.planDsid)
})

const employeeData = computed(() => {
  return EmployeeHelper.findEmployee(props.planData.planDsid)
})

const summary = computed(() => props.planData.planNotes)
</script>

<template>
  <section class="preview-section">
    <div class="plan-header">
      <h4>{{ d(planMonthDateObj, 'monthAndYear') }} - {{ t(planData.planType) }}</h4>
      <div class="last-three-months">
        <p class="three-months-label">{{ t('aiml_last_three_months_label') }}</p>
        <div class="three-months-section">
          <template v-if="lastThreeMonthsData.length">
            <template v-for="eachPlan in lastThreeMonthsData" :key="eachPlan.id">
              <div class="plan-type-info">
                <p class="year-info">
                  {{ DateHelper.shortMonthNumericYear(eachPlan.planMonth, eachPlan.planYear) }}
                </p>
                <p :class="['plan-color-' + t(`${eachPlan.planType}_short`)?.toLocaleLowerCase()]">
                  {{ t(`${eachPlan.planType}_short`) }}
                </p>
              </div>
            </template>
          </template>
        </div>
      </div>
    </div>
    <div class="plan-details">
      <div class="first-row">
        <div class="col-width">
          <h5>{{ t('aiml_analyst_label') }}</h5>
          <p>{{ employeeFullName }}</p>
          <p class="sub-text">{{ employeeData.roleName }}</p>
        </div>
        <div class="col-width">
          <h5>{{ t('start_date_label') }}</h5>
          <p>{{ d(DateHelper.newDate(planData.planStartDate)) }}</p>
        </div>
        <div class="col-width">
          <h5>{{ t('end_date_label') }}</h5>
          <p>{{ d(DateHelper.newDate(planData.planEndDate)) }}</p>
        </div>
      </div>
      <div class="second-row">
        <div class="col-width">
          <h5>{{ t('plan_type_label') }}</h5>
          <p>{{ t(planData.planType) }}</p>
        </div>
        <div
          class="col-width"
          v-for="focusData in planData?.focusAreaMetrics"
          :key="focusData.focusArea"
        >
          <h5>{{ t('focus_area_label') }}</h5>
          <p>{{ t(focusData.focusArea) }}</p>
          <span class="sub-text">{{
            focusData.focusAreaMetrics.map((metric) => t(metric)).join(', ')
          }}</span>
        </div>
      </div>
    </div>
    <bricks-accordion-group expand-at-index="4">
      <bricks-accordion :header="t('opening_summary_label')">
        <div slot="body" class="accordion-content">{{ summary }}</div>
      </bricks-accordion>
      <bricks-accordion :header="t('behaviors_label')">
        <div slot="body" class="accordion-content">
          <PlanBehaviorDetails :planData="planData" />
        </div>
      </bricks-accordion>
      <bricks-accordion :header="t('aiml_competency_focus_label')">
        <div slot="body" class="accordion-content">
          <PlanCompetencyFocus :planData="planData" />
        </div>
      </bricks-accordion>
      <bricks-accordion
        :header="t('supporting_tasks_label')"
        expand-collapse-icon-variant="up-down"
      >
        <div slot="body" class="accordion-content">
          <table class="supporting-tasks">
            <thead>
              <tr>
                <th class="status">{{ t('task_status_label') }}</th>
                <th class="task">{{ t('task_label') }}</th>
                <th class="task-own">{{ t('task_owner_label') }}</th>
                <th>{{ t('task_due_date_label') }}</th>
              </tr>
            </thead>
            <tbody>
              <template v-for="task in planData.tasks" :key="task.id">
                <tr>
                  <td>
                    <p
                      :class="[
                        'task-status-btn',
                        `task-${task.taskStatus?.replace(/[_ ]/g, '').toLocaleLowerCase()}`
                      ]"
                    >
                      {{ t('task_status_' + task.taskStatus.toLowerCase()) }}
                    </p>
                  </td>
                  <td>{{ t(task.taskCode) }}</td>
                  <td>{{ EmployeeHelper.fullNameFor(task.taskOwner) }}</td>
                  <td>{{ task.taskDueDate }}</td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </bricks-accordion>
    </bricks-accordion-group>
  </section>
</template>
<style scoped>
.preview-section {
  padding: 20px 0;
}

.first-row,
.second-row {
  display: flex;
}

.second-row {
  flex-wrap: wrap;
  margin: 35px 0 20px;
}

.plan-header {
  margin-bottom: 20px;
}

.plan-header,
.last-three-months,
.three-months-section {
  display: flex;
  align-items: center;
}

.three-months-section {
  margin-left: 20px;
}

.last-three-months {
  margin-left: auto;
}

.col-width p {
  color: #3a3a3a;
  font-size: 14px;
}

.three-months-section p:last-child {
  display: flex;
  width: 26px;
  height: 26px;
  align-items: center;
  justify-content: center;
  border-radius: 100%;
  font-size: 12px;
}

.col-width {
  width: 20%;
}

.three-months-section div + div {
  margin-left: 7px;
}

.plan-details h5 {
  margin-bottom: 0;
  font-size: 12px;
  font-weight: bold;
  opacity: 0.5;
}

.accordion-content {
  margin-left: 30px;
}

.plan-details .sub-text {
  color: #3a3a3a;
  font-size: 12px;
  opacity: 0.6;
}

.supporting-tasks {
  width: 99%;
  border-collapse: separate;
  border-spacing: 0 15px;
}

.supporting-tasks th {
  width: calc(100% / 4);
  padding-left: 10px;
  font-size: 12px;
  font-weight: bold;
  opacity: 0.5;
}

tbody tr {
  border-radius: 5px;
  background-color: #fff;
  box-shadow: #63636333 0 1px 6px 2px;
}

tbody td {
  padding: 10px 40px 10px 10px;
  text-align: left;
}

tbody td:first-child {
  border-bottom-left-radius: 8px;
  border-top-left-radius: 8px;
}

tbody td:last-child {
  border-bottom-right-radius: 8px;
  border-top-right-radius: 8px;
}

.plan-type-info {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-right: 10px;
}

.year-info {
  margin-bottom: 5px;
}

.three-months-label {
  margin-top: 25px;
}
</style>

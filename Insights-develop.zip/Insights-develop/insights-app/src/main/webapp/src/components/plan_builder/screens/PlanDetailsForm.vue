<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { computed, ref, type PropType, onMounted, watch } from 'vue'
import { Plan } from '@/classes/Plan'
import { usePlansStore } from '@/stores/plans'
import type { IBricks } from '@nexus/bricks-vue'
import PlanHelper from '@/helpers/PlanHelper'
import DateHelper from '@/helpers/DateHelper'

const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  },
  readOnly: Boolean
})

const emit = defineEmits(['update-draft-field', 'update-month-validation'])

const { t, d } = useI18n()

const plansStore = usePlansStore()

const draftUUID = computed(() => {
  return props.planData.id || props.planData.draftUUID || ''
})

const planMonth = computed(() => props.planData.planMonth as string | number)
const planStartAndEndDates = computed(() => [
  props.planData.planStartDate,
  props.planData.planEndDate
])
const selectedPlanType = computed(() => [props.planData.planType])
const selectedPlanTypeReason = computed(() => [props.planData.planTypeReason])
const planTypes = plansStore.planTypeLibrary

const planMonthOrYearError = ref('')

const reason = ['']
// TODO: Pull these from localization, maybe?
const reasons = [
  'aiml_planType_reason_loa',
  'aiml_planType_reason_rotation',
  'aiml_planType_reason_new_hire'
]

const planMonthDateObj = computed(() => {
  const date = DateHelper.dateFromPlanMonthAndYear(
    props.planData.planMonth,
    props.planData.planYear
  )
  return date
})

const currentMonth = computed(() => {
  const now = new Date()
  return now
})

const prevMonth = computed(() => {
  const date = new Date()
  date.setMonth(date.getMonth() - 1)
  return date
})

const nextMonth = computed(() => {
  const date = new Date()
  date.setMonth(date.getMonth() + 1)
  return date
})

function updateDraft(field: string, value: any) {
  emit('update-draft-field', { field, value })
}

function updatePlanMonth(event: IBricks.TabGroup.Events.TabGroupClick) {
  const newMonth = event.detail.value.dataset.month_number as string
  // Months from date objects are stored as a 0-index, so you have to add 1 to
  // get the actual number of the month, ex: June returns 5, add 1 to get 06
  // as the real month number
  const realMonth = parseInt(newMonth) + 1
  if (!realMonth) return

  validatePlanMonthAndYear(realMonth)
  updateDraft('planMonth', realMonth)
  // plansStore.updateDraftField(draftUUID.value, 'planMonth', realMonth)
}

function validatePlanMonthAndYear(realMonth: number) {
  const planMonthAndYearError = PlanHelper.validate.planMonthAndYear(
    draftUUID.value,
    realMonth,
    parseInt(props.planData.planYear as string),
    plansStore.plansForDsid(props.planData.planDsid)
  )

  // If there's no error, then it means that we can create plan for the selected month
  emit('update-month-validation', !!planMonthAndYearError)

  if (planMonthAndYearError) {
    planMonthOrYearError.value = planMonthAndYearError || ''
    console.warn('PlanDetailsForm.updatePlanMonth: Plan Exists for Year and Month')
    return false
  }
  planMonthOrYearError.value = ''
  return true
}

function updateSelectedPlanType(event: IBricks.Selector.Events.SelectorChange) {
  console.log('PlanDetailsForm.updateSelectedPlanType', event)

  const newSelection = event.detail.value[0]
  updateDraft('planType', newSelection)
}

function updatePlanTypeReason(event: IBricks.Selector.Events.SelectorChange) {
  console.log('UpdatePlanTypeReason', event)

  const newSelection = event.detail.value[0]
  updateDraft('planTypeReason', newSelection)
}

function updatePlanDates(event: IBricks.DatePicker.Events.Change) {
  const newDates = event.detail.value as string[]
  const existingDates = planStartAndEndDates.value

  // Do nothing if dates match
  const newDateData = { planStartDate: existingDates[0], planEndDate: existingDates[1] } as {
    planStartDate: string
    planEndDate: string
  }
  if (newDates[0] != existingDates[0]) newDateData.planStartDate = newDates[0]
  if (newDates[1] != existingDates[1]) newDateData.planEndDate = newDates[1]
  if (Object.keys(newDates).length < 1) return

  // Validate dates
  // Date validation returns an error string if there is an error, otherwise it
  // returns null
  const datesValid = PlanHelper.validate.planDates(newDateData)
  if (datesValid) {
    console.warn('PlanDetailsForm.updatePlanDates: Plan Dates Invalid', newDateData)
    return
  }

  // Convert Date data to MM/DD/YYYY format
  const planStartDate = DateHelper.shortFormat(newDateData.planStartDate)
  const planEndDate = DateHelper.shortFormat(newDateData.planEndDate)

  updateDraft('planStartDate', planStartDate)
  updateDraft('planEndDate', planEndDate)
}

onMounted(() => {
  // On PlanDetailsForm load, valdiate the plan month and year
  validatePlanMonthAndYear(props.planData.planMonth as number)
})

// const updateStateWithNewData = (newPlanData: Plan) => {
//   // Update PlanMonth Ref
//   if (newPlanData.planMonth != planMonth.value)
//     planMonth.value = parseInt(newPlanData.planMonth as string)

//   // Update Plan Start and End date Ref
//   const formattedStartAndEndDate = [newPlanData.planStartDate, newPlanData.planEndDate]
//   if (formattedStartAndEndDate != planStartAndEndDates.value)
//     planStartAndEndDates.value = formattedStartAndEndDate

//   // Update PlanType Ref
//   const formattedPlanType = [newPlanData.planType]
//   if (formattedPlanType != selectedPlanType.value) selectedPlanType.value = formattedPlanType

//   // Update PlanTypeReason Ref
//   if (newPlanData.planTypeReason && newPlanData.planTypeReason != selectedPlanTypeReason.value[0])
//     selectedPlanTypeReason.value = [newPlanData.planTypeReason]
// }

// watch(
//   () => props.planData,
//   (newPlanData, oldPlanData) => {
//     updateStateWithNewData(newPlanData)
//   }
// )

const inputEvt = (e) => {
  if ((e.ctrlKey || e.metaKey) && (e.keyCode === 91 || e.keyCode === 67)) {
    return true
  }
  e.preventDefault()
  return false
}
</script>

<template>
  <div v-if="readOnly">
    <bricks-card class="plan-details-readonly-wrapper" :header="t('plan_details_label')">
      <div class="plan-details-readonly">
        <div class="plan-details-group">
          <p class="title-name">{{ t('aiml_plan_month_label') }}</p>
          <p>{{ d(planMonthDateObj, 'monthOnly') }}</p>
        </div>
        <div class="plan-details-group">
          <p class="title-name">{{ t('date_range_label') }}</p>
          <p>
            {{ d(DateHelper.newDate(props.planData.planStartDate)) }} -
            {{ d(DateHelper.newDate(props.planData.planEndDate)) }}
          </p>
        </div>
        <div class="plan-details-group">
          <p class="title-name">{{ t('plan_type_label') }}</p>
          <p>
            {{ t(props.planData.planType) }}
          </p>
        </div>
        <div class="plan-details-group">
          <div v-if="props.planData.planTypeReason">
            <p class="title-name">
              {{ t('aiml_planType_reason_label') }}
            </p>
            <p>
              {{ t(props.planData.planTypeReason) }}
            </p>
          </div>
        </div>
      </div>
    </bricks-card>
  </div>
  <div v-else class="datepicker-div">
    <h3 class="plan-title">{{ t('plan_details_label') }}</h3>

    <p class="title-name">{{ t('aiml_plan_month_label') }}</p>
    <div class="planmonth-box">
      <bricks-tab-group
        visual-style="slider"
        :label="t('aiml_plan_month_label')"
        @bricks-tab-group-click="updatePlanMonth"
      >
        <bricks-tab
          :active="planMonth == prevMonth.getMonth() + 1"
          :data-month_number="prevMonth.getMonth()"
          :panel="prevMonth"
        >
          {{ d(prevMonth, 'monthOnly') }}
        </bricks-tab>
        <bricks-tab
          :active="planMonth == currentMonth.getMonth() + 1"
          :data-month_number="currentMonth.getMonth()"
          :panel="currentMonth"
        >
          {{ d(currentMonth, 'monthOnly') }}
        </bricks-tab>
        <bricks-tab
          :active="planMonth == nextMonth.getMonth() + 1"
          :data-month_number="nextMonth.getMonth()"
          :panel="nextMonth"
        >
          {{ d(nextMonth, 'monthOnly') }}
        </bricks-tab>
      </bricks-tab-group>
      <div class="error-div-msg">
        {{ planMonthOrYearError }}
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="daterange-div">
      <p class="title-name">{{ t('date_range_label') }}</p>
      <bricks-date-picker
        selection-mode="date-range"
        visual-style="floating"
        class="server-side-selector"
        :label="t('plan_dates_label')"
        :min-date="DateHelper.shortFormat(new Date())"
        multiMonth
        :value="planStartAndEndDates"
        @bricks-date-picker-change="updatePlanDates"
        @input="inputEvt"
        @keydown="inputEvt"
        position="auto"
      />
    </div>

    <div class="plan-type">
      <p class="title-name">{{ t('plan_type_label') }}</p>

      <bricks-selector
        class="server-side-selector"
        :accessible-title="t('select_one_label')"
        visual-style="floating"
        @bricks-selector-change="updateSelectedPlanType"
        v-model="selectedPlanType"
      >
        <template v-for="planType in planTypes" :key="planType">
          <bricks-menu-item :value="planType">
            {{ t(planType) }}
          </bricks-menu-item>
        </template>
      </bricks-selector>
    </div>

    <div class="Reason" v-if="selectedPlanType[0] === 'aiml_planType_no_plan'">
      <p class="title-name">{{ t('aiml_planType_reason_label') }}</p>
      <bricks-selector
        filter
        class="server-side-selector"
        :accessible-title="t('select_one_label')"
        visual-style="floating"
        v-model="selectedPlanTypeReason"
        @bricks-selector-change="updatePlanTypeReason"
      >
        <template v-for="rsn in reasons" :key="rsn">
          <bricks-menu-item :value="rsn">
            {{ t(rsn) }}
          </bricks-menu-item>
        </template>
      </bricks-selector>
    </div>
  </div>
</template>

<style scoped>
.plan-details-readonly-wrapper {
  position: relative;
  box-sizing: border-box;
  flex-wrap: wrap;
  align-items: stretch;
  justify-content: space-between;
  padding: 2rem 5rem 2rem 2rem;
}

.plan-details-readonly-wrapper::after {
  position: absolute;
  top: 40px;
  right: 0;
  display: block;
  width: 2px;
  height: 366px;
  background-color: rgb(99 99 99 / 20%);
  content: '';
}

.plan-details-readonly {
  text-align: left;
}

.plan-details-group {
  padding: 0.5rem;
}

bricks-date-picker.server-side-selector {
  --bricks-date-picker-field-width: 100%;

  display: flex;
  min-width: min-content;
  flex-direction: column;
  text-align: left;
}

bricks-selector.server-side-selector {
  --bricks-selector-box-width: 100%;

  display: flex;
  min-width: min-content;
  flex-direction: column;
  text-align: left;
}

/* stylelint-disable-next-line selector-class-pattern */
bricks-selector::part(trigger),
bricks-selector::part(filter) {
  width: 100%;
}

.title-name {
  margin-bottom: 5px;
  color: rgb(0 0 0 / 85%);
  font-size: 18px;
  font-weight: 500;
  letter-spacing: -0.43px;
  line-height: 22px;
  text-align: left;
}

.plan-details-readonly .title-name {
  font-weight: 500;
}

.datepicker-div {
  position: relative;
  height: 500px;
  padding: 15px;
  margin-top: 25px;
}

.plan-title {
  margin-bottom: 13.5px;
  color: var(--header-text-color);
  font-size: 20px;
  font-weight: 400;
  letter-spacing: -0.48px;
  line-height: 22px;
  text-align: left;
}

.planmonth-box span {
  display: block;
  padding: 3px 25px;
  border: 1px solid grey;
  border-radius: 4px;
  margin: 5px 15px;
  float: left;
}

.planmonth-box span:first-child {
  margin-left: 0;
}

.planmonth-box,
.daterange-div,
.plan-type {
  margin-bottom: 35px;
}

.clearfix {
  clear: both;
}

.error-div-msg {
  padding: 10px 0;
  color: rgb(227 0 0);
  font-size: 12px;
  text-align: left;
}

bricks-tab-group::part(nav) {
  background-color: white;
}

bricks-tab {
  margin-right: 8px;
}

bricks-tab::part(base) {
  border-inline-start: none;
  border-inline-start-color: transparent;
}

bricks-tab:not(:active) {
  border: 1px solid #8f8f94;
  border-radius: 8px;
}

bricks-tab-group::part(active-tab-indicator) {
  height: 36px !important;
  border: none;
}

bricks-tab-group::part(active-tab-indicator)::after {
  border-color: #007aff;
}
</style>

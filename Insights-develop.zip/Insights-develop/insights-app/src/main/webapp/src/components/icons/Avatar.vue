<script setup lang="ts">
import axios from 'axios'
import { computed, onMounted, ref } from 'vue'
import { BricksAvatar } from '@nexus/bricks-vue'
import { Employee } from '@/classes/Employee'

const props = defineProps({
  employee: {
    type: Employee,
    default: null
  }
})

const employeeIcon = ref() as any

const employeeInitials = computed(() => {
  const employee = props.employee
  if (!employee) {
    return 'JA'
  } // Johnny AppleSeed
  return employee.initials()
})

const employeeName = computed(() => {
  const employee = props.employee
  if (!employee) return 'Jonny Appleseed'
  return employee.fullName()
})

// Fetch Avatar icon
onMounted(async () => {
  // If there's no DSID, don't do anything
  if (!props.employee?.dsid) return
  // Check if we have a picture
  const iconUrl = 'https://avatars.apple.com/a?no-default&dsid=' + props.employee.dsid
  axios
    .get(iconUrl)
    .then((response) => {
      // Icon found, so we can use the path
      employeeIcon.value = iconUrl
    })
    .catch((err) => {
      // No icon found, so don't do anything
      console.warn(
        `Avatar: No picture found for ${employeeName.value}, using initials`,
        employeeInitials.value,
        props.employee?.dsid
      )
      return
    })
})
</script>
<template>
  <bricks-avatar
    :avatar="employeeIcon"
    :initials="employeeInitials"
    :label="`Avatar for ${employeeName}`"
    size="extra-large"
  />
</template>

<style scoped>
bricks-avatar::part(base-initials) {
  margin-bottom: 6px;
}
</style>
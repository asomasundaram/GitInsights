<script setup lang="ts">
import { computed, ref, type PropType } from 'vue'
import { Plan } from '@/classes/Plan'
import { usePlansStore } from '@/stores/plans'
import { useI18n } from 'vue-i18n'
import type { InsightsPlanCompetency, InsightsPlanCompetencyFocusArea } from '@/types/InsightsTypes'
// @ts-ignore
import Treeselect from 'vue3-treeselect'
import 'vue3-treeselect/dist/vue3-treeselect.css'
import ErrorMessage from './ErrorMessage.vue'
import { type IBricks } from '@nexus/bricks-vue'

const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  }
})

const emit = defineEmits(['update-draft-field'])

const plansStore = usePlansStore()
const { t } = useI18n()

const isOpen = ref(false)
const selectedCompetencies = computed({
  get() {
    let competencies: string[] = []
    // `props.planData.competencyFocus.competencies` is being `null` and hence the check
    if (props.planData.competencyFocus.competencies) {
      competencies = props.planData.competencyFocus.competencies.map((f) => f.focusArea)
    }
    return competencies
  },
  set(newValue) {
    updateCompetencyFocusSelections(newValue)
  }
})
const additionalComments = computed(() => props.planData.competencyFocus.comments)
const options = computed(() => {
  const library = plansStore.competencyFocusLibrary
  // Reformat library into the object required by TreeSelect
  const reformattedLibrary = [] as any[]
  for (let focus of library) {
    reformattedLibrary.push({
      id: focus.factorName,
      label: t(focus.factorName),
      disabled: false,
      children: focus.categoryList.map((category) => {
        return {
          id: category.categoryName,
          label: t(category.categoryName),
          disabled: false,
          children: category.focusList.map((item) => {
            return {
              id: item,
              label: t(item)
            }
          })
        }
      })
    })
  }

  console.log('Original CompetencyFocuses', library)
  console.log('ReformattedLibrary', reformattedLibrary)
  return reformattedLibrary
})

function toggleAccordion() {
  isOpen.value = !isOpen.value
}

function updateCompetencyFocusSelections(newValues) {
  console.log('updatecompetencyFocus', newValues)
  const reformattedValues = formatCompetencies(newValues)

  console.log('Reformatted Values', reformattedValues)
  const competencyFocus = {
    comments: additionalComments.value,
    competencies: reformattedValues
  } as InsightsPlanCompetencyFocusArea

  emit('update-draft-field', { field: 'competencyFocus', value: competencyFocus })
}

function formatCompetencies(competencies) {
  const library = plansStore.competencyFocusLibrary
  const reformattedValues = competencies.map((focusArea) => {
    var category
    const focus = library.find((focus) => {
      category = focus.categoryList.find((cat) => {
        return cat.focusList.includes(focusArea)
      })
      if (category) return focus
    })
    if (!focus) return { factorName: '', categoryName: '', focusArea }
    return {
      factorName: focus.factorName,
      categoryName: category.categoryName,
      focusArea
    }
  }) as InsightsPlanCompetency[]

  return reformattedValues
}

function updateCompetencyFocusComments(event: IBricks.TextArea.Events.TextAreaBlur) {
  const newComments = event.detail.value

  const competencyFocus = {
    comments: newComments,
    competencies: formatCompetencies(selectedCompetencies.value)
  } as InsightsPlanCompetencyFocusArea

  emit('update-draft-field', { field: 'competencyFocus', value: competencyFocus })
}
</script>

<template>
  <div class="margin-top5">
    <div id="accordion">
      <div class="accordion-title">
        <div class="float-left margin-top5">
          <div class="float-left margin-right10">
            <h3 class="font-size18">{{ t('aiml_competency_focus_label') }}</h3>
          </div>

          <div class="float-left">
            <span class="row-count">
              {{ t('aiml_some_competency_focus_added', selectedCompetencies.length) }}
            </span>
          </div>
          <div class="float-right" v-if="selectedCompetencies.length < 1">
            <ErrorMessage :message="t('aiml_error_select_competency_focus')" />
          </div>
        </div>
        <div class="float-right">
          <div class="margin-top5">
            <div class="float-left">
              <h2 class="cursor-pointer" @click="toggleAccordion">
                {{ isOpen ? '-' : '+' }}
              </h2>
            </div>
            <div class="clear"></div>
          </div>
        </div>
        <div class="clear"></div>
      </div>

      <div class="accordion-content" v-if="isOpen">
        <div>
          <Treeselect
            :multiple="true"
            :options="options"
            :disable-branch-nodes="true"
            v-model="selectedCompetencies"
            search-nested
            :limit="3"
            :max-height="400"
            class="custom-treeselect"
          />

          <div class="clear"></div>
        </div>
        <div class="clear"></div>

        <div class="label-section">
          <bricks-text-area
            label="Standard"
            class="full-width"
            :place-holder-text="t('additional_comments_optional_label')"
            max-length="400"
            resize="none"
            :value="additionalComments"
            @bricks-text-area-blur="updateCompetencyFocusComments"
          >
          </bricks-text-area>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.accordion-title {
  padding: 10px 15px 0;
  border-top: 2px solid #d1d1d1;
}

.cursor-pointer {
  margin-top: -6px;
  cursor: pointer;
}

.vue-treeselect {
  position: relative;
  width: 35%;
  margin: 0 0 20px 15px;
  text-align: left;
}

.custom-treeselect {
  display: block;
  min-height: 40px !important;
}

/* stylelint-disable-next-line selector-class-pattern */
.vue-treeselect__option-arrow {
  display: none !important;
}

.label-section {
  width: 36%;
}

.label-text {
  display: block;
  color: gray;
  font-weight: bold;
  text-align: left;
}

bricks-text-area.full-width {
  width: 100%;
  border-radius: 3px;
  margin-bottom: 20px;
  margin-left: 15px;
}

.row-count {
  display: block;

  /* margin-top: 7px; */
  color: gray;
}
</style>

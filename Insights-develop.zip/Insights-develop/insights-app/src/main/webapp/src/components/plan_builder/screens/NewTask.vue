<script setup lang="ts">
import { computed, ref } from 'vue'
import type { InsightsPlanSupportingTask, InsightsTask } from '@/types/InsightsTypes'
import type { Employee } from '@/classes/Employee'
import DateHelper from '@/helpers/DateHelper'

import { useI18n } from 'vue-i18n'
import type { IBricks } from '@nexus/bricks-vue'

const { t, d } = useI18n()

const props = defineProps({
  assignableEmployees: {
    type: Array<Employee>,
    required: true
  },
  disabled: Boolean,
  planStartDate: {
    type: String,
    required: true
  },
  planEndDate: {
    type: String,
    required: true
  },
  taskLibrary: {
    type: Array<InsightsTask>,
    required: true
  }
})

const emit = defineEmits(['add-new-tasks'])

const isOpen = ref(false)
const taskCode = ref([''])
const taskCodeError = computed(() => {
  let message: string | undefined
  if (!taskCode.value || taskCode.value[0] == '') message = t('error_task_description_required')
  return { status: message ? 'invalid' : 'valid', message }
})
const taskOwner = ref([''])
const taskOwnerError = computed(() => {
  let message: string | undefined
  if (!taskOwner.value || taskOwner.value[0] == '') message = t('error_task_owner_required')
  return { status: message ? 'invalid' : 'valid', message }
})
const taskDueDate = ref(DateHelper.shortFormat(props.planEndDate))
const taskDueDateRef = ref(null as HTMLBricksDatePickerElement | null)
const taskDueDateError = computed(() => {
  let message: string | undefined
  const datePickerInvalid = taskDueDateRef.value?.invalid
  console.log('taskDueDateError', datePickerInvalid, taskDueDateRef.value)
  if (datePickerInvalid) message = t('error_task_date_issue')
  if (!taskDueDate.value || taskDueDate.value == '') message: t('error_invalid_date_format')
  return { status: message ? 'invalid' : 'valid', message }
})

function updateTaskCode(event: IBricks.Selector.Events.SelectorChange) {
  const newValue = event.detail.value
  taskCode.value = newValue
}
function updateTaskOwner(event: IBricks.Selector.Events.SelectorChange) {
  const newValue = event.detail.value
  taskOwner.value = newValue
}
function updateTaskDueDate(event: IBricks.DatePicker.Events.Change) {
  const newValue = event.detail.value as string
  const datePickerInvalid = taskDueDateRef.value?.invalid

  console.log('NewTask.updateTaskDueDate', newValue, datePickerInvalid)
  if (datePickerInvalid)
    return console.warn('NewTask.updateTaskDueDate: Datepicker value invalid', newValue)

  taskDueDate.value = newValue
}

function openNewTaskModal() {
  isOpen.value = true
}

function closeNewTaskModal() {
  isOpen.value = false
  taskCode.value = ['']
  taskOwner.value = ['']
  taskDueDate.value = DateHelper.shortFormat(props.planEndDate)
}

function addNewTask() {
  console.log('Task Valid?', taskCodeError.value, taskOwnerError.value, taskDueDateError.value)
  // If there is an error, do not add the task
  if (
    taskCodeError.value.status == 'invalid' ||
    taskOwnerError.value.status == 'invalid' ||
    taskDueDateError.value.status == 'invalid'
  )
    return

  const newTask = {
    id: window.crypto.randomUUID(),
    taskCode: taskCode.value[0],
    taskOwner: taskOwner.value[0],
    taskDueDate: DateHelper.shortFormat(taskDueDate.value),
    taskStatus: 'IN_PROGRESS'
  } as InsightsPlanSupportingTask

  emit('add-new-tasks', [newTask])
  closeNewTaskModal()
}

const inputEvt = (e) => {
  if ((e.ctrlKey || e.metaKey) && (e.keyCode === 91 || e.keyCode === 67)) {
    return true
  }
  e.preventDefault()
  return false
}
</script>
<template>
  <div>
    <bricks-button
      visual-style="alternative"
      class="anchor-link margin-right10"
      @bricks-click="openNewTaskModal"
      :disabled="disabled"
    >
      {{ t('new_task_label') }}
    </bricks-button>
    <bricks-dialog
      behavior="modal"
      .isOpen="isOpen"
      class="supporting-task-new-task-modal"
      @bricks-dialog-close="closeNewTaskModal"
    >
      <strong slot="header">{{ t('add_new_task_label') }}</strong>

      <span slot="body">
        <bricks-label>{{ t('task_description_label') }}</bricks-label>
        <bricks-selector
          :accessible-title="t('select_task_label')"
          filter
          hoist
          class="new-task-selector"
          :value="taskCode"
          :fieldValidationState="taskCodeError"
          @bricks-selector-change="updateTaskCode"
        >
          <bricks-menu-item v-for="task of taskLibrary" :key="task.taskCode" :value="task.taskCode">
            {{ t(task.taskCode) }}
          </bricks-menu-item>
        </bricks-selector>

        <bricks-label>{{ t('task_owner_label') }}</bricks-label>
        <bricks-selector
          :accessible-title="t('select_task_owner_label')"
          hoist
          class="new-task-selector"
          :value="taskOwner"
          :fieldValidationState="taskOwnerError"
          @bricks-selector-change="updateTaskOwner"
        >
          <bricks-menu-item
            v-for="employee of assignableEmployees"
            :key="employee.dsid"
            :value="employee.dsid"
          >
            {{ employee.fullName() }}
          </bricks-menu-item>
        </bricks-selector>

        <bricks-label>{{ t('task_due_date_label') }}</bricks-label>
        <bricks-date-picker
          hoist
          required
          .value="taskDueDate"
          :min-date="planStartDate"
          :max-date="planEndDate"
          ref="taskDueDateRef"
          @bricks-date-picker-change="updateTaskDueDate"
          @bricks-date-picker-dialog-close="updateTaskDueDate"
          @input="inputEvt"
          @keydown="inputEvt"
          position="auto"
        />
      </span>
      <bricks-button
        slot="footer-primary"
        default
        visual-style="primary"
        @bricks-click="addNewTask"
      >
        {{ t('add_label') }}
      </bricks-button>
      <bricks-button
        slot="footer-secondary"
        @bricks-click="closeNewTaskModal"
        visual-style="secondary"
      >
        {{ t('cancel_label') }}
      </bricks-button>
    </bricks-dialog>
  </div>
</template>
<style scoped>
bricks-dialog::part(modal) {
  width: 430px;
  max-height: fit-content;
}

.new-task-selector {
  --bricks-selector-box-width: 375px;
}
</style>

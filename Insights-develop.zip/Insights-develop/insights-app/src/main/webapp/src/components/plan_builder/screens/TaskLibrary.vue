<script setup lang="ts">
import { computed, ref } from 'vue'
import type { InsightsPlanSupportingTask, InsightsTask } from '@/types/InsightsTypes'
import { useI18n } from 'vue-i18n'
import type { IBricks } from '@nexus/bricks-vue'

const { t } = useI18n()

const props = defineProps({
  analystDsid: {
    type: String,
    required: true
  },
  disabled: Boolean,
  managerDsid: {
    type: String,
    required: true
  },
  taskLibrary: {
    type: Array<InsightsTask>,
    required: true
  },
  planEndDate: {
    type: String,
    required: true
  }
})

const emit = defineEmits(['add-new-tasks'])

const isOpen = ref(false)

const filter = ref(['ALL'])
const searchString = ref('')

const filterOptions = ['ALL', 'MANAGER', 'ANALYST']
const filteredTasks = computed(() => {
  return filter.value[0] == 'ALL'
    ? props.taskLibrary
    : props.taskLibrary.filter((task: InsightsTask) => task.taskType == filter.value[0])
})

const pageSize = 5
const currentPage = ref(1)

const pageCount = computed(() => Math.ceil(props.taskLibrary.length / pageSize))

function taskIndexHidden(index: number) {
  const startIndex = (currentPage.value - 1) * pageSize
  const endIndex = startIndex + pageSize
  // If index is not between the start and end index from PaginatedTasks, return
  // true because it should not be showing
  if (startIndex <= index && endIndex > index) return false
  return true
}

const tasksToAdd = ref([''])

function updateTaskFilter(event: IBricks.Selector.Events.SelectorChange) {
  const newValue = event.detail.value
  filter.value = event.detail.value
}

function openTaskLibrary() {
  isOpen.value = true
}

function closeTaskLibrary() {
  isOpen.value = false
  filter.value = ['ALL']
  tasksToAdd.value = []
}

function updateSelectedTasks(event: IBricks.CheckboxGroup.Events.Change) {
  const newTaskValues = event.detail.value
  tasksToAdd.value = newTaskValues
}

function addTasks() {
  const formattedTasks = tasksToAdd.value.map((taskCode: string) => {
    const libraryTask = props.taskLibrary.find((task: InsightsTask) => {
      task.taskCode == taskCode
    })
    return {
      id: window.crypto.randomUUID(),
      taskCode: taskCode,
      taskOwner: libraryTask?.taskType == 'MANAGER' ? props.managerDsid : props.analystDsid,
      taskDueDate: props.planEndDate,
      taskStatus: 'IN_PROGRESS'
    }
  }) as InsightsPlanSupportingTask[]

  emit('add-new-tasks', formattedTasks)
  closeTaskLibrary()
}
</script>
<template>
  <div>
    <bricks-button
      visual-style="tertiary"
      :accessible-title="t('open_task_library_label')"
      class="anchor-link margin-right10"
      @bricks-click="openTaskLibrary"
      :disabled="disabled"
    >
      {{ t('open_library_label') }}
    </bricks-button>
    <bricks-dialog
      behavior="modal"
      .isOpen="isOpen"
      @bricks-dialog-close="closeTaskLibrary"
      class="supporting-task-library-modal"
    >
      <span slot="body">
        <div>
          <div class="margin-bottom-60 margin-top-40">
            <div class="float-left">
              <h4 class="title">{{ t('task_library_label') }}</h4>
            </div>
            <div class="float-right">
              <div class="filter-section float-left margin-right10">
                <!-- <bricks-label>Filter Tasks By:</bricks-label> -->
                <bricks-selector
                  filter
                  id="filter-select-box"
                  :accessible-title="t('filter_tasks_label')"
                  class="single-select"
                  :value="filter"
                  @bricks-selector-change="updateTaskFilter"
                >
                  <bricks-menu-item v-for="option in filterOptions" :key="option" :value="option">
                    {{ t('task_filter_option_' + option) }}
                  </bricks-menu-item>
                </bricks-selector>
              </div>
              <div class="filter-section float-left">
                <input
                  class="search-input"
                  type="search"
                  :value="searchString"
                  placeholder="Search..."
                />
              </div>
            </div>
            <div class="clear"></div>
          </div>
          <table>
            <thead>
              <tr>
                <th colspan="3">{{ t('task_label') }}</th>
                <!-- <th>Task Owner</th> -->
              </tr>
            </thead>
            <tbody>
              <bricks-checkbox-group @bricks-check-box-group-change="updateSelectedTasks">
                <tr
                  v-for="(task, index) in filteredTasks"
                  :key="index"
                  :class="{
                    selected: tasksToAdd.includes(task.taskCode),
                    hidden: taskIndexHidden(index)
                  }"
                >
                  <td :style="{ width: '100%' }">
                    <bricks-checkbox
                      :value="task.taskCode"
                      :label="t(task.taskCode)"
                      :checked="tasksToAdd.includes(task.taskCode)"
                    />
                  </td>
                  <!-- <td :style="{ width: '150px', marginLeft: 'auto' }">{{ t(task.taskType) }}</td> -->
                </tr>
              </bricks-checkbox-group>
            </tbody>
          </table>
          <div class="pagination">
            <button :disabled="currentPage === 1" @click="currentPage--">&lt;</button>
            <span>{{ t('count_of_total_label', { count: currentPage, total: pageCount }) }}</span>
            <button :disabled="currentPage === pageCount" @click="currentPage++">&gt;</button>
          </div>
        </div>
      </span>
      <bricks-button slot="footer-primary" default visual-style="primary" @bricks-click="addTasks">
        {{ t('add_label') }}
      </bricks-button>
      <bricks-button
        slot="footer-secondary"
        @bricks-click="closeTaskLibrary"
        visual-style="secondary"
      >
        {{ t('cancel_label') }}
      </bricks-button>
    </bricks-dialog>
  </div>
</template>

<style scoped>
bricks-dialog.supporting-task-library-modal::part(modal) {
  width: 800px;
}

.filter-bar {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  width: 40%;
  padding: 8px;
  text-align: left;
}

th:first-child,
td:first-child {
  width: 20%;
}

th:last-child,
td:last-child {
  width: 30%;
}

thead,
tbody {
  display: block;
}

thead tr {
  display: flex;
  margin-bottom: 5px;
}

tbody tr {
  display: flex;
  border-radius: 5px;
  margin-bottom: 15px;
  background-color: #fff;
  box-shadow: rgb(99 99 99 / 20%) 0 1px 6px 2px;
}

tr.selected {
  /* background-color: yellow; */
  border: 1px solid #2997ff;
}

button {
  border: none;
  margin: 0 5px;
  font-size: 16px;
}

.pagination {
  width: 115px;
  margin: 0 auto;
}

.search-input {
  min-height: 33px;
  padding: 0 0 0 10px;
  border: 1px solid #d1d1d1;
  border-radius: 5px;
}

.hidden {
  display: none;
}
</style>

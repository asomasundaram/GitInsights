<script setup lang="ts">
import { computed, type PropType, ref } from 'vue'
import { type Employee } from '@/classes/Employee'
import TeamSidebarEntry from './TeamSidebarEntry.vue'
import TeamSidebarExpandCollapse from './TeamSidebarExpandCollapse.vue'
import TeamSidebarDirects from './TeamSidebarDirects.vue'
import { useEmployeeStore } from '@/stores/employee'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import type { IBricks } from '@nexus/bricks-vue'
import APIHelper from '@/helpers/APIHelper'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const props = defineProps({
  activeDirects: {
    type: Array<Employee>,
    required: true
  },
  inactiveDirects: {
    type: Array<Employee>,
    required: true
  },
  isCollapsed: Boolean,
  isHidden: Boolean,
  selectedEmployee: String,
  selectedManager: {
    type: Object as PropType<Employee>,
    required: true
  }
})

const emit = defineEmits(['toggle-expand-collapse', 'update-sidebar-selection'])
const showChangeManagerModel = ref(false)
const isChangingManager = ref(false)
const changeManagerInput = ref(undefined as HTMLBricksTextFieldElement | undefined)
const managerDSIDSearch = ref(undefined as string | undefined)
const employeeStore = useEmployeeStore()

const managerSubheader = computed(() => {
  // TODO: Convert this to localized string
  const totalHeadcount = props.activeDirects.length + props.inactiveDirects.length
  return t('total_headcount_label', { count: totalHeadcount || 0 })
})

const currentUser = computed(() => employeeStore.currentUser as Employee)
const delegatedManagers = computed(() => employeeStore.getDelegatedManagers())

const selectManagerInSidebar = (event: Event) => {
  const element = event.target as HTMLElement
  // Don't select the manager if the "More" icon is clicked
  if (['path', 'svg', 'bricks-button'].includes(element.tagName.toLowerCase())) return
  emit('update-sidebar-selection', props.selectedManager.dsid)
}

const openChangeManagerModal = () => {
  showChangeManagerModel.value = true
}

const hideChangeManagerModal = () => {
  showChangeManagerModel.value = false
}

const changeManagerDisabled = computed(() => {
  const input = changeManagerInput.value
  if (!input || input.invalid) return true
  const rawDSID = managerDSIDSearch.value
  if (!rawDSID) return true
  const parsedDSID = parseInt(rawDSID)
  if (isNaN(parsedDSID)) return true
  if (isChangingManager.value) return true
  return false
})

const changeManager = () => {
  if (changeManagerDisabled.value || !managerDSIDSearch.value) return
  isChangingManager.value = true
  APIHelper.changeSelectedManager(managerDSIDSearch.value)
    .then(() => {
      isChangingManager.value = false
      hideChangeManagerModal()
    })
    .catch(() => {
      isChangingManager.value = false
      hideChangeManagerModal()
    })
}

const switchDelegatedTeam = (managerDSID: string) => {
  isChangingManager.value = true
  APIHelper.changeSelectedManager(managerDSID)
    .then(() => {
      isChangingManager.value = false
    })
    .catch(() => {
      isChangingManager.value = false
    })
}

const updateManagerDSID = (event: IBricks.TextField.Events.TextFieldChange) => {
  const details = event.detail.value as string
  managerDSIDSearch.value = details
}

const resetModal = () => {
  managerDSIDSearch.value = undefined
  hideChangeManagerModal()
}
</script>

<template>
  <div class="team-sidebar" :class="{ collapsed: isCollapsed, hidden: isHidden }">
    <TeamSidebarExpandCollapse
      :collapsed="isCollapsed"
      @toggle-sidebar-collapse="emit('toggle-expand-collapse')"
    />
    <div class="team-sidebar-content">
      <div class="team-sidebar-manager">
        <!-- Team Sidebar Manager -->
        <TeamSidebarEntry
          :collapsed="isCollapsed"
          :employee="selectedManager"
          :subheader="managerSubheader"
          :selected="selectedEmployee == selectedManager.dsid"
          :showMenu="delegatedManagers.length > 0"
          :key="selectedManager.dsid"
          @click="selectManagerInSidebar"
        >
          <template v-slot:menu-options v-if="delegatedManagers.length">
            <bricks-label class="menu-label">{{ t('delegation_label') }}</bricks-label>
            <bricks-menu-divider />
            <bricks-menu-item
              @click="switchDelegatedTeam(currentUser.dsid)"
              :disabled="selectedManager.dsid == currentUser.dsid"
            >
              {{ t('my_team_label') }}
            </bricks-menu-item>
            <bricks-menu-item
              v-for="managerDsid in delegatedManagers"
              @click="switchDelegatedTeam(managerDsid)"
              :disabled="selectedManager.dsid == managerDsid"
            >
              {{ EmployeeHelper.fullNameFor(managerDsid) }}
            </bricks-menu-item>
          </template>
        </TeamSidebarEntry>
      </div>
      <div class="team-sidebar-directs">
        <!-- Team Sidebar Employees -->
        <TeamSidebarDirects
          :collapsed="isCollapsed"
          :activeEmployees="activeDirects"
          :inactiveEmployees="inactiveDirects"
          :selectedEmployee="selectedEmployee"
          @update-selected-employee="emit('update-sidebar-selection', $event)"
        />
      </div>
    </div>
  </div>
  <!-- <bricks-dialog
    behavior="modal"
    .isOpen="showChangeManagerModel"
    @bricks-dialog-close="hideChangeManagerModal"
  >
    <span slot="header"> Change Manager </span>
    <div slot="body">
      <div v-if="isChangingManager">
        <span>Changing to {{ managerDSIDSearch }}</span>
        <bricks-progress-bar />
      </div>
      <template v-else>
        <span>Enter the DSID for the manager you wish to change to.</span>
        <div>
          <bricks-label>Manager DSID</bricks-label>
          <bricks-text-field
            label="Manager DSID"
            pattern="[0-9]+$"
            min="3"
            max="12"
            @bricks-text-field-change="updateManagerDSID"
            ref="changeManagerInput"
          />
        </div>
      </template>
    </div>
    <bricks-button
      slot="footer-primary"
      default
      visual-style="primary"
      @bricks-click="changeManager"
      :disabled="changeManagerDisabled"
    >
      Change
    </bricks-button>
    <bricks-button
      slot="footer-secondary"
      visual-style="secondary"
      @bricks-click="resetModal"
      :disabled="isChangingManager"
    >
      Cancel
    </bricks-button>
  </bricks-dialog> -->
</template>

<style scoped>
.team-sidebar-content {
  overflow: hidden;
  width: 100%;
  height: 100%;
}

.team-sidebar-directs {
  overflow: scroll;
  height: 100%;
  padding-bottom: 80px;
}

.team-sidebar.collapsed {
  width: 100px;
}

.team-sidebar-divider {
  width: 100%;
  height: 1px;
  padding: 0;

  /* TODO: Switch this to a variable */
  border: solid 1px #979797;
  border-radius: 1px;
  margin: 15px 0;
}

.hidden {
  display: none;
  visibility: hidden;
}

.team-sidebar-manager {
  padding-bottom: 12px;
  border-bottom: solid 1px #979797;
}

.menu-label {
  padding-right: 8px;
  padding-left: 8px;
}
</style>

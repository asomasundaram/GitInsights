<script setup lang="ts">
import { ref, type PropType } from 'vue'
import { Plan } from '@/classes/Plan'
import { useI18n } from 'vue-i18n'
import DateHelper from '@/helpers/DateHelper'

import ChevronRight from '@/components/icons/sfsymbols/chevron.right.vue'
import PlanHelper from '@/helpers/PlanHelper'

const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  },
  lastThreeMonths: {
    type: Array<Plan>,
    default: [] as Array<Plan>
  }
})

const emit = defineEmits(['duplicate-plan'])

const { t, d } = useI18n()
const modalIsOpen = ref(false)
const planToDuplicate = ref('')

const activeAccordion = ref(null as number | null)

function toggleAccordion(index: number, event: MouseEvent | KeyboardEvent) {
  // Do not expand/collapse accordion if the `Duplicate Plan` button is clicked
  const eventTarget = event.target as HTMLElement
  if (eventTarget?.tagName == 'BRICKS-BUTTON') return
  activeAccordion.value = activeAccordion.value === index ? null : index
}

const showDuplicatePlanModal = (uuid: string) => {
  planToDuplicate.value = uuid
  modalIsOpen.value = true
}

const hideDuplicatePlanModal = () => {
  modalIsOpen.value = false
  planToDuplicate.value = ''
}

function duplicatePlan() {
  const planUUID = planToDuplicate.value
  if (planUUID == '')
    return console.log('PlanDetailsLastThreeMonths.duplicatePlan: No UUID to duplicate')
  console.log('PlanDetailsLastThreeMonths.duplicatePlan: Duplicate Plan clicked', planUUID)
  emit('duplicate-plan', planUUID)
  hideDuplicatePlanModal()
}
</script>

<template>
  <bricks-dialog
    behavior="modal"
    .isOpen="modalIsOpen"
    @bricks-dialog-close="hideDuplicatePlanModal"
  >
    <strong slot="header">{{ t('duplicate_plan_label') }}</strong>
    <div slot="body">
      <p>
        {{ t('duplicate_plan_warning') }}
      </p>
    </div>
    <bricks-button
      slot="footer-primary"
      default
      visual-style="primary"
      :accessible-title="t('duplicate_plan_label')"
      @bricks-click="duplicatePlan"
    >
      {{ t('duplicate_plan_label') }}
    </bricks-button>
    <bricks-button
      slot="footer-secondary"
      visual-style="secondary"
      :accessible-title="t('cancel_label')"
      @bricks-click="hideDuplicatePlanModal()"
    >
      {{ t('cancel_label') }}
    </bricks-button>
  </bricks-dialog>
  <div class="tile">
    <div class="last-three-sec">
      <h3 class="title">
        {{ t('aiml_last_three_months_label') }}
      </h3>

      <div class="months-section">
        <div class="accordion-container">
          <div v-if="lastThreeMonths.length < 1">{{ t('error_no_details') }}</div>

          <div v-for="(plan, index) in lastThreeMonths" :key="index" class="accordion-item">
            <div
              class="accordion-header"
              @click="toggleAccordion(index, $event)"
              @keypress.enter="toggleAccordion(index, $event)"
              @keypress.space="toggleAccordion(index, $event)"
              tabindex="0"
            >
              <div class="header-left">
                <p>
                  {{
                    d(
                      DateHelper.dateFromPlanMonthAndYear(plan.planMonth, plan.planYear),
                      'monthAndYear'
                    )
                  }}
                </p>
                <h2 class="font-size-15-bold">{{ t('plan_type_label') }}</h2>
                <p>{{ t(plan.planType) }}</p>
              </div>
              <div class="header-right">
                <bricks-button
                  class="duplicate-plan-button"
                  visual-style="link"
                  :accessible-title="t('duplicate_plan_label')"
                  @bricks-click="showDuplicatePlanModal(plan.id)"
                  tabindex="0"
                >
                  {{ t('duplicate_plan_label') }}
                </bricks-button>

                <div
                  class="accordion-expand-collapse"
                  :class="{ 'icon-down': activeAccordion === index }"
                >
                  <bricks-icon color="secondary" size="small">
                    <ChevronRight />
                  </bricks-icon>
                </div>
              </div>
              <div class="clear"></div>
            </div>
            <div class="accordion-body" v-show="activeAccordion === index">
              <h2 class="font-size-15-bold">{{ t('aiml_focusAreas_label') }}</h2>
              <!-- false tigger section start here -->
              <div class="margin-bottom-10">
                <div class="float-left">
                  <div
                    class="focus-data"
                    v-for="focusArea in plan.focusAreaMetrics"
                    :key="focusArea.focusArea"
                  >
                    <div class="float-left margin-right-10 width-150">
                      <p class="font-size-15">{{ t(focusArea.focusArea) }} :</p>
                    </div>

                    <div class="float-left">
                      <p
                        class="font-size-15"
                        v-for="metric in focusArea.focusAreaMetrics"
                        :key="metric"
                      >
                        {{ t(metric) }}
                      </p>
                    </div>
                  </div>
                </div>
                <div class="clear"></div>
              </div>
              <div class="margin-bottom-10">
                <h2 class="font-size-15-bold">{{ t('aiml_competency_focus_label') }}</h2>
                <div
                  v-for="competency in plan.competencyFocus.competencies"
                  :key="competency.focusArea"
                >
                  <ul>
                    <li class="font-size-15">{{ t(competency.focusArea) }}</li>
                  </ul>
                </div>
              </div>

              <div class="margin-bottom-10">
                <h2 class="font-size-15-bold">{{ t('behaviors_label') }}</h2>
                <div v-for="behavior in plan.behaviors" :key="behavior.behaviorCode">
                  <ul>
                    <li class="font-size-15">{{ t(behavior.behaviorCode) }}</li>
                  </ul>
                </div>
              </div>

              <div v-if="plan.closureRating" class="margin-bottom-10">
                <h2 class="font-size-15-bold">{{ t('planClosure_rating_label') }}</h2>
                <div>
                  <p class="font-size-15">{{ t(plan.closureRating) }}</p>
                </div>
              </div>

              <div
                v-if="plan.closureComments && plan.closureComments != ''"
                class="margin-bottom-10"
              >
                <h2 class="font-size-15-bold">{{ t('planClosure_notes_label') }}</h2>
                <div>
                  <p class="font-size-15">{{ plan.closureComments }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
h1,
h2,
h3,
p {
  margin: 0;
}

.float-left {
  float: left;
}

.float-right {
  float: right;
}

.clear {
  clear: both;
}

.font-size-15 {
  font-size: 15px;
}

.font-size-15-bold {
  font-size: 15px;
  font-weight: bold;
}

.margin-bottom-5 {
  margin-bottom: 5px;
}

.margin-bottom-10 {
  margin-bottom: 10px;
}

.margin-right-10 {
  margin-right: 10px;
}

.width-150 {
  width: 150px;
}

.margin-top-20 {
  margin-top: 20px;
}

.margin-top-10 {
  margin-top: 10px;
}

.textalign-left {
  text-align: left;
}

.senior-analyst {
  /* color: #f2f2f2; */
  width: 45%;
  float: left;
}

.accordion-container {
  width: 97%;
}

.months-section {
  max-height: 380px;

  /* Enable vertical scroll */
  margin-top: 16px;

  /* Set a max height to enable vertical scroll */
  overflow-y: auto;
  scrollbar-color: #ccc #f2f2f2;

  /* Custom vertical scroll bar */
  scrollbar-width: thin;
}

.months-section::-webkit-scrollbar {
  width: 6px;
}

.months-section::-webkit-scrollbar-thumb {
  border-radius: 3px;
  background-color: #ccc;
}

.months-section::-webkit-scrollbar-track {
  background-color: #f2f2f2;
}

.accordion-item {
  margin-bottom: 8px;
  background-color: #f2f2f2;
}

.accordion-header {
  display: flex;
  width: 100%;
  justify-content: space-between;
  padding: 15px;
  cursor: pointer;
  font-size: 13px;
  font-weight: bold;
  text-align: left;
}

.header-left {
  width: 50%;
}

.header-right {
  display: flex;
  width: 50%;
  align-items: center;
  justify-content: flex-end;
}

.duplicate-plan-button {
  margin-right: 25px;
}

.accordion-expand-collapse {
  color: #000;
  fill: #000;
  transition: transform 0.15s ease-in-out;
}

.icon-down {
  transform: rotate(90deg);
}

.accordion-body {
  padding: 0 15px 15px;
  margin-top: 4px;
  text-align: left;
}

.accordion-body ul {
  margin: 0;
}

.last-three-sec {
  margin-top: 25px;
}

.focus-data {
  width: 270px;
}

.duplicate-link {
  color: cornflowerblue;
  text-decoration: none;
}

.tile::after {
  position: absolute;
  top: 40px;

  /* left: 50%; */
  right: 0;
  display: block;
  width: 2px;
  height: 366px;
  background-color: rgb(99 99 99 / 20%);
  content: '';
}

.divider {
  width: 4%;
  height: 1400px;
  background-color: #ccc;
  float: left;
}

.tile {
  position: relative;
  box-sizing: border-box;

  /* box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 6px 2px; */

  /* display: flex; */
  flex-wrap: wrap;
  align-items: stretch;
  justify-content: space-between;

  /* margin: 0 25px 25px 0; */

  /* width: 35%; */
  padding: 15px;
}

.title {
  color: rgb(58 58 58 / 85%);
  font-size: 20px;
  font-weight: 400;
  letter-spacing: -0.48px;
  line-height: 22px;
  text-align: left;
}
</style>

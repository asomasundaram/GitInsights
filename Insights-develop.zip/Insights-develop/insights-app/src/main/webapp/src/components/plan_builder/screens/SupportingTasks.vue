<script setup lang="ts">
import { computed, ref, type PropType } from 'vue'
import { usePlansStore } from '@/stores/plans'
import { useI18n } from 'vue-i18n'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import ErrorMessage from './ErrorMessage.vue'
import SupportingTask from '@/components/plan_builder/screens/SupportingTask.vue'
import type { InsightsPlanSupportingTask } from '@/types/InsightsTypes'
import NewTask from '@/components/plan_builder/screens/NewTask.vue'
import TaskLibrary from '@/components/plan_builder/screens/TaskLibrary.vue'
import { Plan } from '@/classes/Plan'
import PlanHelper from '@/helpers/PlanHelper'

const emit = defineEmits(['update-draft-field'])

const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  }
})

const plansStore = usePlansStore()
const { t, d, locale } = useI18n()

const taskLibrary = plansStore.taskLibrary

const isButtonDisabled = ref(true)
const isOpen = ref(false)

const assignableEmployees = computed(() => {
  const list = EmployeeHelper.employeeDsidsForTasks(props.planData)
  return list.map((dsid: string) => EmployeeHelper.findEmployee(dsid))
})

const planHasMinimumTasks = computed(() => {
  return props.planData.tasks.length > 0
})

function toggleAccordion() {
  isOpen.value = !isOpen.value
  isButtonDisabled.value = !isOpen.value
}

function addNewTasks(newTasks: InsightsPlanSupportingTask[]) {
  const updatedTasks = [...props.planData.tasks, ...newTasks]
  updateDraft(updatedTasks)
}

function updateTask(taskData: InsightsPlanSupportingTask) {
  console.log('SupportingTask.updateTask: taskData', taskData)
  // Deep-copy tasks to avoid mutations
  const existingTasks = PlanHelper.cloneObject(props.planData.tasks)
  // Replace task with newly supplied task data if the UUID matches
  const updatedTasks = existingTasks.map((task: InsightsPlanSupportingTask) => {
    return task.id == taskData.id ? taskData : task
  })

  console.log('SupportingTask.updateTask: updatedTasks', updatedTasks)
  updateDraft(updatedTasks)
}

function deleteTask(taskUUID: string) {
  // Deep-copy tasks to avoid mutations
  const existingTasks = PlanHelper.cloneObject(props.planData.tasks)

  const taskIndex = existingTasks.findIndex(
    (task: InsightsPlanSupportingTask) => task.id == taskUUID
  )
  // If the Task Index wasn't found, do nothing. Otherwise, delete it and
  // update the draft
  if (taskIndex < 0) return
  existingTasks.splice(taskIndex, 1)
  updateDraft(existingTasks)
}

function updateDraft(updatedTasks: InsightsPlanSupportingTask[]) {
  emit('update-draft-field', { field: 'tasks', value: updatedTasks })
}
</script>

<template>
  <div>
    <div id="accordion">
      <div class="accordion-title margin-top5">
        <div class="float-left margin-top5">
          <div class="float-left margin-right10">
            <h3 class="font-size18">{{ t('supporting_tasks_label') }}</h3>
          </div>

          <div class="float-left">
            <span class="row-count">
              {{ t('some_supporting_tasks_added', planData.tasks.length) }}
            </span>
          </div>

          <div class="float-right" v-if="!planHasMinimumTasks">
            <ErrorMessage :message="t('error_tasks_required')" />
          </div>
        </div>
        <div class="float-right">
          <div class="margin-top5">
            <div class="float-left margin-right10">
              <div class="float-left margin-right10">
                <TaskLibrary
                  :analyst-dsid="planData.planDsid"
                  :disabled="isButtonDisabled"
                  :manager-dsid="planData.createdBy"
                  :task-library="taskLibrary"
                  :plan-end-date="planData.planEndDate"
                  @add-new-tasks="addNewTasks"
                />
              </div>
              <div class="float-left">
                <NewTask
                  :assignable-employees="assignableEmployees"
                  :disabled="isButtonDisabled"
                  :plan-end-date="planData.planEndDate"
                  :plan-start-date="planData.planStartDate"
                  :taskLibrary="taskLibrary"
                  @add-new-tasks="addNewTasks"
                />
              </div>
            </div>
            <div class="float-left">
              <h2 class="cursor-pointer" @click="toggleAccordion">
                {{ isOpen ? '-' : '+' }}
              </h2>
            </div>
            <div class="clear"></div>
          </div>
        </div>
        <div class="clear"></div>
      </div>

      <div class="accordion-content" v-if="isOpen">
        <table v-if="planData.tasks.length">
          <thead>
            <tr>
              <th>{{ t('task_label') }}</th>
              <th>{{ t('task_owner_label') }}</th>
              <th>{{ t('task_due_date_label') }}</th>
              <th>&nbsp;</th>
            </tr>
          </thead>
          <tbody>
            <SupportingTask
              v-for="task in planData.tasks"
              :key="task.id"
              :assignable-employees="assignableEmployees"
              :plan-end-date="planData.planEndDate"
              :plan-start-date="planData.planStartDate"
              :task="task"
              :task-library="taskLibrary"
              @update-task="updateTask"
              @delete-task="deleteTask"
              :plan-state="planData.planState"
            />
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<style scoped>
.datepicker-div {
  position: relative;
  height: 500px;
  margin-top: 25px;
}

.accordion-content {
  margin-left: 15px;
}

.accordion-title {
  padding: 10px 15px;
  border-top: 2px solid #d1d1d1;
}

.cursor-pointer {
  margin-top: -6px;
  cursor: pointer;
}

table {
  width: 100%;
  border-collapse: separate;
}

th {
  width: 40%;
  color: grey;
  text-align: left;
}

th:not(:first-child) {
  width: 20%;
}

th:first-child {
  padding-left: 20px;
}

th:first-child,
td:first-child {
  width: 40%;
}

th:last-child,
td:last-child {
  width: 20%;
  text-align: right;
}

/* custom scrollbar styles */
tbody {
  max-height: 385px;
  padding-top: 5px;
  overflow-y: auto;
  scrollbar-color: #ccc #f2f2f2;
  scrollbar-width: thin;
}

tbody ::-webkit-scrollbar {
  width: 6px;
}

tbody ::-webkit-scrollbar-thumb {
  border-radius: 3px;
  background-color: #ccc;
}

tbody ::-webkit-scrollbar-track {
  background-color: #f2f2f2;
}

thead tr {
  display: inline-flex;
  width: 99%;
  margin-top: 10px;
  margin-bottom: 5px;
}

tbody tr {
  display: inline-flex;
  width: 99%;
  align-items: center;
  border-radius: 5px;
  margin-bottom: 15px;
  background-color: #fff;
  box-shadow: rgb(99 99 99 / 20%) 0 1px 6px 2px;
}

bricks-selector {
  --bricks-selector-box-menu-max-height: 250px;
}

bricks-selector.new-task-selector {
  --bricks-selector-box-width: 390px;

  margin-bottom: 10px;
}

bricks-selector.single-select-div2 {
  --bricks-selector-box-width: 390px;

  margin-bottom: 10px;
}

bricks-dialog.supporting-task-library-modal::part(modal) {
  width: 800px;
}

.date-area {
  width: 100%;
  height: 40px;
  border: 1px solid #959595;
  border-radius: 10px;
}

.row-count {
  display: block;
  color: gray;
}
</style>

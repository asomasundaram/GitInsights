<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { usePlansStore } from '@/stores/plans'
import { computed, ref } from 'vue'
import CoachingPlan from '@/components/plans/direct/CoachingPlan.vue'
import type { Plan } from '@/classes/Plan'
import DateHelper from '@/helpers/DateHelper'
import PlanHelper from '@/helpers/PlanHelper'
import type { IBricks } from '@nexus/bricks-vue'

const props = defineProps({
  dsid: {
    type: String,
    required: true
  }
})

const plansStore = usePlansStore()
const filteredPlans = computed(() => plansStore.plansForDsid(props.dsid))
const planFilter = ref('12')

const sortedPlans = computed(() => {
  const plans = filteredPlans?.value.filter((plan) => plan.planState !== 'DRAFT')
  let plansSorted = PlanHelper.sortPlanMonthAndYear(plans, 'descending')
  if (planFilter.value) {
    plansSorted = plansSorted.filter((plan) => {
      // Create a new date object for the current month. `getMonth()` returns
      // a 0-indexed month, so we need to add 1
      const currentMonth = new Date().getMonth() + 1
      // Cast filter value to a number for use in rolling period
      const rollingPeriod = parseInt(planFilter.value)
      // Create a new date object to store the rolling period
      const rollingMonth = new Date()
      // Set the month to the rolling month
      rollingMonth.setMonth(currentMonth - rollingPeriod)
      // Set the rolling month to the first day of the month at T00:00:00:00Z
      rollingMonth.setDate(1)
      rollingMonth.setHours(0, 0, 0, 0)

      // Create a new date object for the first day of the Plan Month
      const planMonth = new Date(plan.planMonth + '/01/' + plan.planYear)
      // Set the Plan month's time to T:00:00:00:00Z
      planMonth.setHours(0, 0, 0, 0)

      // Check to see if the plan month is newer than the rolling period
      // timestamp, or equal to it. We can do this in miliseconds by adding
      // `getTime()` to these, but Javascript will do Date comparisons as well.
      // Setting the Hours, Minutes, Seconds, and Miliseconds to 0 ensures that
      // we should always return plans within this timeframe, and accounts for
      // plans spanning across multiple years.
      return planMonth >= rollingMonth
    })
  }
  return plansSorted
})

const planTypes = plansStore.planTypeLibrary

const { t } = useI18n()

const currentPlan = computed(() => {
  const activePlans = filteredPlans?.value.filter((plan) => plan?.planState === 'IN_PROGRESS')

  const newestPlan = activePlans?.sort((a, b) => {
    const monthA = parseInt(a.planMonth as string)
    const monthB = parseInt(b.planMonth as string)
    return monthB - monthA
  })
  return newestPlan[0]
})

const draftPlan = computed(() => {
  const activePlans = filteredPlans?.value.filter((plan) => plan?.planState === 'DRAFT')

  const newestPlan = activePlans?.sort((a, b) => {
    const monthA = parseInt(a.planMonth as string)
    const monthB = parseInt(b.planMonth as string)
    return monthB - monthA
  })
  return newestPlan[0]
})

const filterPlansByType = (planType: string) => {
  const activePlans = filteredPlans.value.filter((plan: Plan) => plan.planState != 'DRAFT')
  const sortedplanType = activePlans.filter((pd: Plan) => pd.planType == planType)
  return sortedplanType.length
}

const planTypeClass = (planType: string) => {
  return 'side-color-' + t(planType + '_short').toLowerCase()
}

const updatePlanFilter = (event: IBricks.Selector.Events.SelectorChange) => {
  const newValue = event.detail.value[0] as string
  planFilter.value = newValue
}
</script>

<template>
  <CoachingPlan :dsid="dsid" />
  <div class="clear"></div>
  <div class="plans-header">
    <h3>{{ t('plans_label') }}</h3>

    <div class="plans-filters">
      <bricks-selector
        :value="planFilter"
        @bricks-selector-change="updatePlanFilter"
        :accessible-title="t('plan_filter_label')"
      >
        <bricks-menu-item value="3">{{ t('plan_filter_rolling_3') }}</bricks-menu-item>
        <bricks-menu-item value="6">{{ t('plan_filter_rolling_6') }}</bricks-menu-item>
        <bricks-menu-item value="12">{{ t('plan_filter_rolling_12') }}</bricks-menu-item>
        <bricks-menu-item value="15">{{ t('plan_filter_rolling_15') }}</bricks-menu-item>
      </bricks-selector>
    </div>
  </div>

  <div class="clear"></div>

  <div class="plan-section">
    <div class="float-left plans">
      <div v-for="planType in planTypes" :key="planType">
        <p class="plans-title">{{ t(planType) }}</p>
        <div class="standard-coaching-vl" :class="[planTypeClass(planType)]">
          {{ filterPlansByType(planType) }}
        </div>
      </div>
      <div class="clear"></div>
      <div class="coachingplan-card" v-if="currentPlan">
        <div class="coachingcards">
          <span class="">{{ t('current_plan_label') }}</span>
          <span>{{ PlanHelper.completedTasks(currentPlan) }}</span>
        </div>
        <p class="coachingplancard-title">
          {{ DateHelper.shortMonthNumericYear(currentPlan.planMonth, currentPlan.planYear) }}
          - {{ t(currentPlan.planType) }}
        </p>
        <div class="coachingplancard-hr"></div>
        <router-link
          class="coachingplancard-link"
          :to="{
            name: 'plans',
            params: { employee: currentPlan.planDsid },
            query: { plan: currentPlan.id }
          }"
        >
          {{ t('view_label') }}
        </router-link>
      </div>
      <div class="coachingplan-card" v-if="draftPlan">
        <div class="coachingcards">
          <span class="">{{ t('draft_plan_label') }}</span>
          <span>{{ t('task_count', { count: draftPlan.tasks.length }) }}</span>
        </div>
        <p class="coachingplancard-title">
          {{ DateHelper.shortMonthNumericYear(draftPlan.planMonth, draftPlan.planYear) }}
          - {{ t(draftPlan.planType) }}
        </p>
        <div class="coachingplancard-hr"></div>
        <router-link
          class="coachingplancard-link"
          :to="{
            name: 'plans',
            params: { employee: draftPlan.planDsid },
            query: { plan: draftPlan.id }
          }"
        >
          {{ t('view_label') }}
        </router-link>
      </div>
    </div>

    <div class="vertical-line"></div>
    <div class="float-left table-section">
      <table class="planstable">
        <thead>
          <tr>
            <th>{{ t('date_label') }}</th>
            <th>{{ t('type_label') }}</th>
            <th>{{ t('focus_area_label') }}</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="plan in sortedPlans" :key="plan.id || plan.draftUUID">
            <td>
              {{ DateHelper.shortMonthNumericYear(plan.planMonth, plan.planYear) }}
            </td>
            <td>{{ t(plan.planType) }}</td>
            <td>
              <span v-if="plan.focusAreaMetrics?.length">
                {{ plan.focusAreaMetrics.map((focusArea) => t(focusArea.focusArea)).join(', ') }}
              </span>
              <span v-if="!plan.focusAreaMetrics || plan.focusAreaMetrics?.length < 1">
                {{ t('no_focus_area_label') }}
              </span>
            </td>
            <td>
              <router-link
                :to="{
                  name: 'plans',
                  params: { employee: plan.planDsid },
                  query: { plan: plan.id }
                }"
              >
                {{ t('view_label') }}
              </router-link>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<style scoped>
.plans-header {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 4rem;
}

.plans-header h3 {
  color: rgb(0 0 0 / 85%);
  font-size: 22px;
  font-weight: 700;
  letter-spacing: -0.53px;
  line-height: 22px;
}

.clear {
  clear: both;
}

td,
th {
  padding: 0 33px;
  white-space: nowrap;
}

.planstable th {
  background-color: white;
  color: #000;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: -0.29px;
  line-height: 15px;
  opacity: 0.5;
}

.planstable tbody tr {
  border-radius: 8px;
  margin: 15px 0;
  background: #f8f8f8;
}

.planstable td {
  padding: 19px 33px;
  color: #3a3a3a;
  font-size: 14px;
  font-weight: 400;
  letter-spacing: -0.34px;
  line-height: 15px;
}

.plan-section {
  margin-top: 19px;
}

.standard-coaching-vl {
  padding-left: 11px;
  border-left: 3px solid lightgray;
  margin: 5px auto 22px 4px;
  color: rgb(0 0 0 / 85%);
  font-size: 34px;
  font-weight: 600;
  letter-spacing: 0.54px;
  line-height: 34px;
}

.side-color-ad {
  border-color: var(--additional-development-bg-color);
}

.side-color-ap {
  border-color: var(--action-plan-bg-color);
}

.side-color-dc {
  border-color: var(--documented-coaching-bg-color);
}

.side-color-np {
  border-color: var(--no-plan-bg-color);
}

.side-color-sc {
  border-color: var(--standard-coaching-bg-color);
}

.plans-title {
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 400;
  letter-spacing: 0.22px;
  line-height: 26px;
  opacity: 0.5;
}

.planstable {
  width: 97%;
  margin: 0 21px 0 27px;
  border-collapse: separate;
  border-spacing: 0 15px;
  table-layout: auto;
}

.planstable a {
  color: #007aff;
  font-size: 14px;
  font-weight: 400;
  letter-spacing: 0.22px;
  line-height: 15px;
  text-align: right;
  text-decoration: none;
}

.plans {
  width: 25%;
  height: 720px;
  border-right: 1px solid lightgray;
}

.coachingcards {
  display: flex;
  justify-content: space-between;
  color: rgb(0 0 0 / 85%);
  font-size: 10px;
  font-weight: 400;
  letter-spacing: 0.16px;
  line-height: 10px;
  opacity: 0.7;
}

.coachingplan-card {
  padding: 15px 12px 0 15px;
  border-radius: 8px;
  margin: 32px 28px 0 0;
  background: #fff;
  box-shadow: 0 0 9px 4px rgb(207 207 207 / 3%), 0 0 6px 2px rgb(20 20 20 / 7%);
}

.coachingplancard-title {
  padding: 10px 0 14.5px;
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 400;
  letter-spacing: 0.22px;
  line-height: 17px;
}

.coachingplancard-hr {
  border-bottom: 1px solid #979797;
  opacity: 0.25;
}

.coachingplancard-link {
  display: block;
  padding: 14.5px 0 15px;
  color: #007aff;
  font-size: 12px;
  font-weight: 400;
  letter-spacing: 0.19px;
  line-height: 12px;
  text-align: center;
  text-decoration: none;
}

.table-section {
  width: 75%;
}

.planstable tr td:nth-child(1) {
  border-bottom-left-radius: 8px;
  border-top-left-radius: 8px;
}

.planstable tr td:last-child {
  border-bottom-right-radius: 8px;
  border-top-right-radius: 8px;
  text-align: right;
}
</style>

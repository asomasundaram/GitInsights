<script setup lang="ts">
import { computed } from 'vue'
import DocText from '@/components/icons/sfsymbols/doc.text.vue'
import Book from '@/components/icons/sfsymbols/book.vue'
const props = defineProps({
  currentPath: String,
  icon: String,
  buttonFor: String
})

const isSelected = computed(() => {
  if (props.buttonFor === 'plans' && props.currentPath == 'plan_builder') return true
  return props.currentPath == props.buttonFor
})

const buttonText = computed(() => {
  // TODO: replace with localization
  let val
  switch (props.buttonFor) {
    case 'plans':
      val = 'Plans'
      break
    case 'tasks':
      val = 'Tasks'
      break
  }
  return val
})
</script>

<template>
  <button class="nav-button" :class="{ selected: isSelected }">
    <div class="icon">
      <bricks-icon color="secondary" size="extra-large">
        <DocText v-if="icon == 'doc.text'" class="icon" />
        <Book v-if="icon == 'book'" class="icon" />
      </bricks-icon>
    </div>
    <div class="text">
      {{ buttonText }}
    </div>
  </button>
</template>

<style scoped>
.nav-button {
  display: flex;
  width: 80px;
  height: 80px;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border: none;
  border-radius: 10px;
  margin-bottom: 10px;
  background-color: transparent;
  font-size: 14px;
  text-align: center;
}

.selected {
  background-color: #c6ddfd;
}

.icon {
  fill: #000;
}
</style>

<script setup lang="ts">
import { Employee } from '@/classes/Employee'
import TeamSidebarEntry from './TeamSidebarEntry.vue'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import { computed } from 'vue'

const props = defineProps({
  collapsed: Boolean,
  directs: Array<Employee>,
  sectionHeader: String,
  selectedEmployee: String
})

const sortedDirects = computed(() => {
  const sortedValues = props.directs?.sort((employee1: Employee, employee2: Employee) => {
    const firstAnalyst = EmployeeHelper.fullNameFor(employee1.dsid)
    const secondAnalyst = EmployeeHelper.fullNameFor(employee2.dsid)
    return firstAnalyst.localeCompare(secondAnalyst)
  })
  return sortedValues
})
</script>

<template>
  <div class="team-sidebar-section">
    <div class="team-sidebar-section-header" :class="{ collapsed }" v-if="sectionHeader !== ''">
      {{ sectionHeader }}
    </div>
    <div class="team-sidebar-section-employees">
      <button
        class="no-styles"
        v-for="direct of sortedDirects"
        :key="direct.dsid"
        @click="$emit('update-sidebar-selection', direct.dsid)"
      >
        <TeamSidebarEntry
          :collapsed="collapsed"
          :employee="direct"
          :selected="selectedEmployee == direct.dsid"
        />
      </button>
    </div>
  </div>
</template>

<style scoped>
.team-sidebar-section {
  width: 100%;
  padding-top: 15px;
}

button.no-styles {
  width: 100%;
  padding: 0;
  border: none;
  margin: 0;
  background: transparent;
}

button.no-styles:not(:last-of-type) {
  margin-bottom: 5px;
}

.team-sidebar-section-header.collapsed {
  display: none;
}
</style>

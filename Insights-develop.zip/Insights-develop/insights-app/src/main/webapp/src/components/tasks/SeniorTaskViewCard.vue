<script setup lang="ts">
import { computed, type PropType } from 'vue'
import { type TaskAggregate } from '@/classes/Plan'
import { useI18n } from 'vue-i18n'
import Avatar from '@/components/icons/Avatar.vue'
import EmployeeHelper from '@/helpers/EmployeeHelper'

const { t } = useI18n()

const props = defineProps({
  aggregateData: {
    type: Object as PropType<TaskAggregate>,
    required: true
  }
})

const managerData = computed(() => {
  const maestroPerson = EmployeeHelper.findEmployee(props.aggregateData.dsid)
  return maestroPerson
})
</script>

<template>
  <div class="tasks-cards-section">
    <div class="tasks-card">
      <div class="task-header">
        <Avatar :employee="managerData" slot="trigger"></Avatar>
        <p class="team-name">{{ aggregateData.firstName }} {{ aggregateData.lastName }}</p>
        <p class="team-role">{{ aggregateData.siteName }}</p>
        <p class="team-role">
          {{ t('total_headcount_label', { count: managerData.directs?.length || 0 }) }}
        </p>
      </div>

      <router-link
        :to="{
          name: 'tasks',
          params: { employee: aggregateData.dsid }
        }"
        class="view-link"
      >
        {{ t('view_label') }}
      </router-link>
    </div>
    <div class="task-status">
      <p class="task-no">{{ aggregateData.dueSoon }}</p>
      <p class="task-name">{{ t('due_soon_label') }}</p>
    </div>
    <div class="task-status">
      <p class="task-no">{{ aggregateData.overdue || 0 }}</p>
      <p class="task-name">{{ t('overdue_label') }}</p>
    </div>
    <div class="task-status">
      <p class="task-no">{{ aggregateData.closed }}</p>
      <p class="task-name">{{ t('complete_label') }}</p>
    </div>
  </div>
</template>

<style scoped>
.tasks-cards-section {
  position: relative;
  width: 301px;
  flex-basis: 23%;
  padding: 29px 29px 31px 31px;
  padding-bottom: 10px;
  border-radius: 8px;
  margin-top: 24px;
  margin-right: 23px;
  background: #fff;
  box-shadow: 0 0 9px 4px rgb(207 207 207 / 3%), 0 0 6px 2px rgb(20 20 20 / 7%);
}

.tasks-card {
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid rgb(151 151 151/ 50%);
}

.view-link {
  color: #007aff;
  font-size: 16px;
  font-weight: 400;
  letter-spacing: 0.26px;
  line-height: 26px;
  text-align: right;
  text-decoration: none;
}

.task-no {
  padding-right: 10.34px;
  color: rgb(0 0 0 / 85%);
  font-size: 24px;
  font-weight: 400;
  letter-spacing: 0.38px;
  line-height: 34px;
  text-align: center;
}

.task-name {
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 400;
  letter-spacing: 0.22px;
  line-height: 34px;
  opacity: 0.5;
}

.task-status {
  display: flex;
  padding-top: 7px;
  padding-bottom: 14px;
}

.team-name {
  padding-top: 7px;
  color: rgb(0 0 0 / 85%);
  font-size: 18px;
  font-weight: 500;
  letter-spacing: 0.29px;
  line-height: 26px;
}

.team-role {
  padding-bottom: 1px;
  color: rgb(0 0 0 / 85%);
  font-size: 12px;
  font-weight: 500;
  letter-spacing: 0.19px;
  line-height: 26px;
  opacity: 0.5;
}
</style>

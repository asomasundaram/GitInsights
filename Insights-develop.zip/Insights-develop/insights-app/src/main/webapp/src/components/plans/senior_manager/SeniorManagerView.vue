<script setup lang="ts">
import { computed, ref } from 'vue'
import { usePlansStore } from '@/stores/plans'
import { useSidebarStore } from '@/stores/sidebar'
import type { PlanAggregate } from '@/classes/Plan'
import EmployeeHelper from '@/helpers/EmployeeHelper'
import DateHelper from '@/helpers/DateHelper'
import SeniorManagerPlansCard from '@/components/plans/senior_manager/SeniorManagerPlansCard.vue'
import { useI18n } from 'vue-i18n'
import PlanHelper from '@/helpers/PlanHelper'
const plansStore = usePlansStore()
const sidebarStore = useSidebarStore()
const { t } = useI18n()

const isFetchingAggregates = ref(false)
const lastRefresh = ref(0)

const selectedMonth = computed(() => {
  // TODO: Make this dynamic
  const today = new Date()
  today.setDate(1)
  today.setHours(0, 0, 0, 0)
  const thisMonth = new Date(today)
  return DateHelper.shortFormat(thisMonth)
})

const planAggregates = computed(() => {
  const selectedManager = EmployeeHelper.findEmployee(sidebarStore.selectedManager)
  // Guard against no direct reports
  if (!selectedManager.directs || selectedManager.directs.length < 1) return []

  // Duplicate directs array to detach from selected manager object
  // Guard against no direct reports
  if (!selectedManager.directs || selectedManager.directs.length < 1) {
    return []
  }
  const directs = PlanHelper.cloneObject(selectedManager.directs)

  const aggregates = plansStore.planAggregatesFor(directs, selectedMonth.value)
  checkForRefresh(aggregates, directs)

  return aggregates
})

function checkForRefresh(aggregates: PlanAggregate[], directs: string[]) {
  console.log('SeniorManagerView.checkForRefresh: Checking if data needs refreshed...')
  // Check to see if any aggregates need to be refreshed
  const aggregateDsids = aggregates.map((agg: PlanAggregate) => agg.dsid)
  // console.log('SeniorManagerView.checkForRefresh: Existing Aggregates for:', aggregateDsids)

  const missingAggregates = directs.filter((direct: string) => !aggregateDsids.includes(direct))
  // // console.log('SeniorManagerView.checkForRefresh: Missing Aggregates for: ', missingAggregates)

  // const oldAggregateData = [] as string[]
  const fiveMinutesAgo = Date.now() - 5 * 60 * 1000

  if (lastRefresh.value > fiveMinutesAgo)
    return console.log('SeniorManagerView.checkForRefresh: Last refresh within 5 minutes')

  // console.log('SeniorManagerView.checkForRefresh: Old aggregate data', oldAggregateData)
  // const needsRefresh = [...missingAggregates, ...oldAggregateData]
  const needsRefresh = [...aggregateDsids, ...missingAggregates]
  if (needsRefresh.length == 0)
    return console.log('SeniorManagerView.checkForRefresh: No need to refresh')
  console.log('SeniorManagerView.checkForRefresh: Refreshing aggregates for:', needsRefresh)
  refreshAggregates(needsRefresh)
}

function refreshAggregates(dsids: string[]) {
  console.log('SeniorManagerView.refreshAggregates: Refreshing aggregates', dsids)
  if (!dsids || dsids.length == 0)
    return console.log('SeniorManagerView.refreshAggregates: No DSIDs to refresh')
  if (isFetchingAggregates.value)
    return console.log('SeniorManagerView.refreshAggregates: Already refreshing...')
  isFetchingAggregates.value = true

  plansStore.refreshPlanAggregatesFor(dsids, selectedMonth.value).then((response) => {
    lastRefresh.value = Date.now()
    console.log('SeniorManagerview.refreshAggregates: Aggregates refreshed')
    isFetchingAggregates.value = false
  })
}

const totalPlansForAllTeams = computed(() => {
  if (!planAggregates.value || planAggregates.value.length < 1) return 0
  // Convert aggregates to an array of totals
  const mappedTotals = planAggregates.value.map((aggregate) => parseInt(aggregate.totalPlans))
  // Add all values in the array up and return the value
  return mappedTotals.reduce((a, b) => a + b)
})

const closedPercentageForAllTeams = computed(() => {
  if (!planAggregates.value || planAggregates.value.length < 1) return '0%'
  // Convert aggregates to an array of totals
  const mappedCompleted = planAggregates.value.map((aggregate) =>
    parseInt(aggregate.completedPlans)
  )
  // Add all values in the array up and return the value
  const totalCompleted = mappedCompleted.reduce((a, b) => a + b)
  return Math.ceil((totalCompleted / totalPlansForAllTeams.value) * 100) + '%'
})

const planTypesForAllTeams = computed(() => {
  if (!planAggregates.value || planAggregates.value.length < 1) return {}
  const planTypeTotals = {}

  for (let aggregate of planAggregates.value) {
    for (let type in aggregate.planTypes) {
      if (!planTypeTotals[type]) planTypeTotals[type] = 0
      planTypeTotals[type] += parseInt(aggregate.planTypes[type])
    }
  }
  return planTypeTotals
})
</script>

<template>
  <div class="teamlead-view-header">
    <h1 class="teamlead-header-text">{{ t('my_team_label') }}</h1>

    <bricks-date-picker label="Date Picker" visual-style="floating"></bricks-date-picker>
  </div>
  <div class="teamlead-view-content">
    <div class="first-box">
      <div class="plans-box">
        <div class="totalplan-box">
          <p class="plan-count-title">{{ t('total_plans_label') }}</p>
          <p class="plan-count">{{ totalPlansForAllTeams }}</p>
        </div>
        <div class="closedplan-box">
          <p class="plan-count-title">{{ t('closed_label') }}</p>
          <p class="plan-count">{{ closedPercentageForAllTeams }}</p>
        </div>
      </div>
      <div class="plans-list">
        <div class="plans-list-details" v-for="(value, planType) of planTypesForAllTeams">
          <p class="plan-no">{{ value }}</p>
          <p class="plan-name">{{ t(planType) }}</p>
        </div>
      </div>
    </div>
    <SeniorManagerPlansCard v-for="aggregate of planAggregates" :aggregate-data="aggregate" />
  </div>
</template>

<style>
.teamlead-view-header {
  display: flex;
  justify-content: space-between;
}

.teamlead-item {
  position: relative;
  width: 301px;
  height: auto;
  padding: 30px 15px;
  padding-bottom: 8px;
  border-radius: 8px;
  margin-right: 23px;
  margin-bottom: 23px;
  background: #fff;
  box-shadow: 0 0 9px 4px rgb(207 207 207 / 3%), 0 0 6px 2px rgb(20 20 20 / 7%);
  white-space: nowrap;
}

.teamlead-header-text {
  color: rgb(0 0 0 / 85%);
  font-size: 34px;
  font-weight: 700;
  letter-spacing: -0.82px;
  line-height: 34px;
}

.teamlead-view-content {
  display: flex;
  flex-wrap: wrap;
  margin-top: 17px;
}

.plans-box {
  display: flex;
  padding-bottom: 60px;
  border-bottom: 1px solid rgb(151 151 151 / 50%);
}

.totalplan-box {
  width: 138px;
  border-radius: 8px;
  background: rgb(255 204 0 / 50%);
}

.plan-count {
  padding: 2px 22px 19px 19px;
  color: rgb(0 0 0 / 85%);
  font-size: 38px;
  font-weight: 600;
  letter-spacing: 0.61px;
  line-height: 44px;
}

.plan-count-title {
  padding: 19px 22px 2px 19px;
  color: rgb(59 59 59 / 85%);
  font-size: 20px;
  font-weight: 400;
  letter-spacing: -0.48px;
  line-height: 22px;
}

.closedplan-box {
  width: 138px;
  border-radius: 8px;
  margin-left: 9px;
  background: #9dca97;
}

.first-box {
  width: 306px;
  margin-right: 18px;
}

.plans-list {
  margin-left: 18px;
}

.plan-no {
  margin-top: 18px;
  margin-right: 23px;
  color: rgb(0 0 0 / 85%);
  font-size: 28px;
  font-weight: 600;
  letter-spacing: 0.45px;
  line-height: 44px;
}

.plan-name {
  margin-top: 29.5px;
  color: rgb(0 0 0 / 85%);
  font-size: 18px;
  font-weight: 400;
  letter-spacing: -0.43px;
  line-height: 22px;
  opacity: 0.5;
}

.team-name {
  color: rgb(0 0 0 / 85%);
  font-size: 18px;
  font-weight: 500;
  line-height: 26px;
}

.plans-list-details {
  display: flex;
  margin-bottom: 8px;
}

.closed-plan-title {
  margin-top: 19px;
  color: rgb(0 0 0 / 85%);
  font-size: 14px;
  font-weight: 400;
  letter-spacing: 0.22px;
  line-height: 26px;
  opacity: 0.5;
}
</style>

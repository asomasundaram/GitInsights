<script setup lang="ts">
import { ref, type PropType, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import type { Plan } from '@/classes/Plan'
import { usePlansStore } from '@/stores/plans'
import PlanHeaderDetails from './PlanHeaderDetails.vue'
import PlanBehaviorDetails from './PlanBehaviorDetails.vue'
import PlanCompetencyFocus from './PlanCompetencyFocus.vue'
import PlanSupportingTasks from '@/components/plan_view/PlanSupportingTasks.vue'
import { useI18n } from 'vue-i18n'
import PlanOpeningSummary from './PlanOpeningSummary.vue'
import PlanHelper from '@/helpers/PlanHelper'
import { useEmployeeStore } from '@/stores/employee'
import APIHelper from '@/helpers/APIHelper'

const { t } = useI18n()

const props = defineProps({
  planData: {
    type: Object as PropType<Plan>,
    required: true
  }
})

const route = useRoute()
const plansStore = usePlansStore()
const employeeStore = useEmployeeStore()
const planId = route.query.plan as string
const savePlanViewFlag = ref(false)
const tasksInEditMode = ref([] as String[])
const originalPlanData = ref(PlanHelper.cloneObject(props.planData))
const lastThreeMonths = ref([] as Plan[])

function isPlanSaved(value: boolean) {
  savePlanViewFlag.value = value
  if (value) tasksInEditMode.value = []
}
function emitChangeInTask(taskID: string, editMode: boolean) {
  if (editMode) {
    tasksInEditMode.value.push(taskID)
  } else if (tasksInEditMode.value.length && tasksInEditMode.value.includes(taskID)) {
    const filterTasksInEditMode = tasksInEditMode.value.filter((id) => id !== taskID)
    tasksInEditMode.value = filterTasksInEditMode
  }
  return
}

function cancelPlanUpdate(isCancelled: boolean) {
  savePlanViewFlag.value = isCancelled
  plansStore.updatePlan(props.planData.id, originalPlanData.value)
}
const userCanUpdatePlan = computed(() => {
  const currentUser = employeeStore.currentUser

  return ['level_30', 'level_20'].includes(currentUser.applicationRoleLevel)
})

onMounted(() => {
  // Fetch last 3 months from the plan's start date
  APIHelper.fetchRecentPlans(props.planData.planDsid, props.planData.planStartDate, 3).then(
    (plans) => {
      if (plans && plans.length > 0) lastThreeMonths.value = plans
    }
  )
})
</script>
<template>
  <PlanHeaderDetails
    :planData="planData"
    :lastThreeMonths="lastThreeMonths"
    :key="planData.planState"
    :individualTaskSaveFlag="savePlanViewFlag"
    @save-plan-view-flag="isPlanSaved"
    @cancel-plan-update="cancelPlanUpdate"
    :tasksInEditMode="tasksInEditMode"
    :user-can-update-plan="userCanUpdatePlan"
  />
  <bricks-accordion-group expand-all="true" expand-at-index="3">
    <bricks-accordion v-if="planData.planNotes && planData.planNotes != ''">
      <div slot="header">{{ t('opening_summary_label') }}</div>
      <div slot="body">
        <PlanOpeningSummary :planData="planData" />
      </div>
    </bricks-accordion>
    <bricks-accordion>
      <div slot="header">{{ t('behaviors_label') }}</div>
      <div slot="body">
        <PlanBehaviorDetails :planData="planData" />
      </div>
    </bricks-accordion>
    <bricks-accordion>
      <div slot="header">{{ t('aiml_competency_focus_label') }}</div>
      <div slot="body">
        <PlanCompetencyFocus :planData="planData" />
      </div>
    </bricks-accordion>
    <bricks-accordion>
      <div slot="header">{{ t('supporting_tasks_label') }}</div>
      <div slot="body">
        <PlanSupportingTasks
          :key="planData.planState"
          :planData="planData"
          :saveFlag="savePlanViewFlag"
          @update-task="emitChangeInTask"
          @task-update-success="isPlanSaved"
          :user-can-update-plan="userCanUpdatePlan"
        />
      </div>
    </bricks-accordion>
  </bricks-accordion-group>
</template>

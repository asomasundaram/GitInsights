<script setup lang="ts">
import AppContainer from '@/components/AppContainer.vue'
</script>

<template>
  <AppContainer />
</template>

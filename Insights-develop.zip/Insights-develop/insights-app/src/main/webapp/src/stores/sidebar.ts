import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { useEmployeeStore } from '@/stores/employee'
import { Employee } from '@/classes/Employee'

export const useSidebarStore = defineStore('sidebarStore', () => {
  const employeeStore = useEmployeeStore()
  const collapsed = ref(false)
  const selectedEmployee = ref('')
  const selectedManager = ref('')
  const directReports = ref([] as Employee[])

  // Possible statuses from Maestro are:
  // - Active
  // - Leave (Away)
  // - Invalid Record
  // - Left Apple
  // - Removed From Company
  // - Test Account
  // - Training
  // - Transferred
  const activeStatuses = ['Active', 'Training']

  const activeDirects = computed(() => {
    return directReports.value.filter((emp) => activeStatuses.includes(emp.status))
  })

  const inactiveDirects = computed(() => {
    return directReports.value.filter((emp) => !activeStatuses.includes(emp.status))
  })

  const setSelectedEmployee = (dsid: string) => {
    if (selectedEmployee.value == dsid) return
    selectedEmployee.value = dsid
  }

  function setSelectedManager(dsid: string) {
    if (selectedManager.value == dsid) return
    selectedManager.value = dsid
  }

  function setDirectReports(directs: Employee[]) {
    directs = directs.map((d: Employee) => new Employee(d))
    directReports.value = directs as Employee[]
  }

  function getAllDirectReportdDsIDs() {
    if (directReports.value.length === 0) return [] as string[]
    return directReports.value.map((d) => d.dsid)
  }

  return {
    activeDirects,
    collapsed,
    directReports,
    inactiveDirects,
    selectedEmployee,
    selectedManager,
    setDirectReports,
    setSelectedEmployee,
    setSelectedManager,
    getAllDirectReportdDsIDs
  }
})

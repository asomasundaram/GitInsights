import { defineStore } from 'pinia'
import { Plan, PlanAggregate, TaskAggregate } from '@/classes/Plan'
import type { Employee } from '@/classes/Employee'
import { ref, computed } from 'vue'
import DateHelper from '@/helpers/DateHelper'
import APIHelper from '@/helpers/APIHelper'

import type {
  InsightsBehavior,
  InsightsCompetencyFocus,
  InsightsFocusMetric,
  InsightsTask
} from '@/types/InsightsTypes'

export const usePlansStore = defineStore('plans', () => {
  const planAggregates = ref([] as PlanAggregate[])
  const taskAggregates = ref([] as TaskAggregate[])
  const plans = ref([] as Plan[])
  const isLoadingPlans = ref(true)

  const drafts = computed((): Plan[] => {
    if (plans.value.length < 1) return []
    return plans.value.filter((plan: Plan) => plan.planState == 'DRAFT')
  })

  const behaviorLibrary = ref([] as InsightsBehavior[])
  const competencyFocusLibrary = ref([] as InsightsCompetencyFocus[])
  const metrics = [
    'aiml_focusAreaMetric_tpt',
    'aiml_focusAreaMetric_timegrading',
    'aiml_focusAreaMetric_throughput',
    'aiml_focusAreaMetric_quality'
  ]
  const focusMetricLibrary = ref([] as InsightsFocusMetric[])
  const taskLibrary = ref([] as InsightsTask[])
  const planTypeLibrary = ref([] as string[])

  function createNewDraft(currentUser: Employee, selectedEmployee: string) {
    const creationTime = new Date()
    const msInMonth = 2592000000
    const oneMonthFromNow = new Date(creationTime.valueOf() + msInMonth)
    const draftData = {
      id: '',
      draftUUID: window.crypto.randomUUID(),
      businessUnitId: currentUser.businessUnitId,
      behaviors: [],
      planDsid: selectedEmployee,
      planMonth: DateHelper.realMonth(creationTime),
      planYear: DateHelper.numericYear(creationTime),
      competencyFocus: { comments: '', competencies: [] },
      createdBy: currentUser.dsid,
      focusAreaMetrics: [],
      lastModifiedBy: currentUser.dsid,
      lastModifiedTime: creationTime.getTime(),
      planEndDate: DateHelper.shortFormat(oneMonthFromNow),
      planNotes: '',
      planStartDate: DateHelper.shortFormat(creationTime),
      planState: 'DRAFT',
      planType: 'aiml_planType_standard_coaching',
      planTypeReason: '',
      tasks: []
    }
    const draft = new Plan(draftData)
    return draft
  }

  function addPlan(plan: Plan) {
    plans.value.push(plan)
  }

  function findPlan(uuid: string): Plan | undefined {
    return plans.value.find((plan: Plan) => plan.id == uuid)
  }

  function findDraft(uuid: string): Plan {
    const foundDraft: Plan | undefined = drafts.value.find(
      (draft: Plan) => (draft.id || draft.draftUUID) == uuid
    )

    return foundDraft as Plan
  }

  function updatePlanField(uuid: string, field: string, value: any) {
    console.log('PlansStore.updatePlanField', uuid, field, value)
    const newData = { [field]: value }
    updatePlan(uuid, newData)
  }

  function updatePlan(uuid: string, newValues: { [key: string]: any }, apiCall: boolean = false) {
    const updateTime = new Date()
    const draftIndex = plans.value.findIndex(
      (draft: Plan) => (draft.id || draft.draftUUID) === uuid
    )
    console.log('PlansStore.updatePlan: Draft Index', draftIndex)
    const existingDraft = plans.value[draftIndex]
    const newDraft = new Plan({
      ...existingDraft,
      ...newValues,
      lastModifiedTime: updateTime.getTime()
    })
    console.log('PlansStore.updatePlan: New Draft', newDraft)
    // Do nothing if Draft can't be found
    if (draftIndex < 0) return console.warn('PlansStore.updatePlan: Could not find draft', uuid)
    if (newValues.id && newDraft.draftUUID) {
      delete newDraft.draftUUID
    }

    plans.value.splice(draftIndex, 1, newDraft)
  }

  function activePlansForDsids(dsids: string[]) {
    return dsids.flatMap((dsid: string) => activePlansForDsid(dsid))
  }

  function activePlansForDsid(dsid: string) {
    return plansForDsid(dsid).filter((plan) => plan.planState == 'IN_PROGRESS')
  }

  function plansForDsid(dsid: string) {
    return plans.value.filter((plan) => plan.planDsid == dsid)
  }

  function moveDraftToInProgress(uuid: string) {
    updatePlan(uuid, { planState: 'IN_PROGRESS' })
  }

  function convertDraftUUIDtoID(uuid: string, newId: string) {
    updatePlan(uuid, { id: newId })
  }

  function setLibraryData(
    behaviors: InsightsBehavior[],
    competencyFocuses: InsightsCompetencyFocus[],
    focusMetrics: InsightsFocusMetric[],
    planTypes: string[],
    tasks: InsightsTask[]
  ) {
    behaviorLibrary.value = behaviors
    competencyFocusLibrary.value = competencyFocuses
    focusMetricLibrary.value = focusMetrics
    planTypeLibrary.value = planTypes
    taskLibrary.value = tasks
  }

  function setPlansFromAPI(planData: [{ planDsid: string; plansList: Plan[] }]) {
    const convertedPlans = planData.flatMap((pd) => pd.plansList.map((p) => new Plan(p)))
    // If the plan exists, replace it. Otherwise add it to the plans. We can
    // create the index array of `planIds` outside of the loop because we will
    // be adding any new plans to the end of the plans array, meaning the
    // original plans will keep their original index.
    const planIds = plans.value.map((plan) => plan.id)
    for (let plan of convertedPlans) {
      if (planIds.includes(plan.id)) {
        const planIndex = planIds.indexOf(plan.id)
        plans.value.splice(planIndex, 1, plan)
      } else {
        plans.value.push(plan)
      }
    }
  }

  function currentPlanFor(dsid: string) {
    const plansForDSID = plans.value.filter((plan) => plan.planDsid == dsid)
    const activePlans = plansForDSID.filter((plan) => plan.planState === 'IN_PROGRESS')

    if (!activePlans || activePlans.length < 1) return

    const newestPlan = activePlans.sort((a, b) => {
      const monthA = parseInt(a.planMonth as string)
      const monthB = parseInt(b.planMonth as string)
      return monthB - monthA
    })

    return newestPlan[0]
  }

  function lastThreeMonths(dsid: string | undefined) {
    if (!dsid) return []
    const filteredPlans = plansForDsid(dsid)
    const completedPlans = filteredPlans.filter((plan) => plan.planState === 'COMPLETED')
    const sortedPlans = completedPlans.sort((a, b) => {
       return new Date(`${a.planMonth}/01/${a.planYear}`).getTime() - new Date(`${b.planMonth}/01/${b.planYear}`).getTime() 
    }) 
    return sortedPlans.slice(-3)
  }

  function planTypeLength() {
    const plansByType = {} as { [key: string]: any[] }
    for (let plan of plans.value) {
      if (!plansByType[plan.planType]) plansByType[plan.planType] = []
      plansByType[plan.planType].push(plan)
    }
    return plansByType
  }

  function currentDraftFor(dsid: string) {
    const userDrafts = drafts.value.filter((draft) => {
      return draft.planDsid == dsid
    })

    if (!userDrafts) return

    const currentDrafts = userDrafts.sort(function (a, b) {
      var keyA = new Date(a.lastModifiedTime),
        keyB = new Date(b.lastModifiedTime)
      // Compare the 2 dates
      if (keyA < keyB) return -1
      if (keyA > keyB) return 1
      return 0
    })

    if (currentDrafts.length > 0) return currentDrafts[0]

    return
  }

  async function updatePlanData(planData: Plan) {
    return APIHelper.plans
      .updatePlan(planData)
      .then((planId: string | undefined) => {
        if (planId) updatePlan(planId, planData)
        return
      })
      .catch((error: Error) => {
        throw error
      })
  }

  function planAggregatesFor(dsids: string[], date?: string) {
    console.log('PlansStore.planAggregatesFor: Returning aggregates for DSIDs, Month', dsids, date)
    // Check for an existing aggregate
    const aggregates = planAggregates.value.filter((aggregate) => dsids.includes(aggregate.dsid))

    console.log('PlansStore.planAggregatesFor: Data?', aggregates)
    return aggregates
  }

  function taskAggregatesFor(dsids: string[], date?: string) {
    console.log('PlansStore.taskAggregatesFor: Returning aggregates for DSIDs, Month', dsids, date)
    // Check for an existing aggregate
    const aggregates = taskAggregates.value.filter((aggregate) => dsids.includes(aggregate.dsid))

    console.log('PlansStore.taskAggregatesFor: Data?', aggregates)
    return aggregates
  }

  async function refreshPlanAggregatesFor(dsids: string[], date?: string) {
    console.log(
      'PlansStore.refreshPlanAggregatesFor: Refreshing aggregates for Dsids, date',
      dsids,
      date
    )
    if (dsids.length < 1)
      return console.log('PlansStore.refreshPlanAggregatesFor: No DSIDS to refresh')
    return APIHelper.fetchPlanAggregatesFor(dsids, date)
      .then((aggregateData) => {
        console.log('PlanStore.refreshPlanAggregatesFor: Data returned', dsids, date, aggregateData)

        planAggregates.value = aggregateData
        console.log('PlansStore.refreshPlanAggregateData: new aggregates', planAggregates.value)
        return aggregateData
      })
      .catch((error) => {
        throw error
      })
  }

  async function refreshtaskAggregatesFor(dsids: string[], date?: string) {
    console.log(
      'PlansStore.refreshtaskAggregatesFor: Refreshing aggregates for Dsids, date',
      dsids,
      date
    )
    if (dsids.length < 1)
      return console.log('PlansStore.refreshtaskAggregatesFor: No DSIDS to refresh')
    return APIHelper.fetchTaskAggregatesFor(dsids, date)
      .then((aggregateData) => {
        console.log('PlanStore.refreshtaskAggregatesFor: Data returned', dsids, date, aggregateData)
        taskAggregates.value = aggregateData
        console.log('PlansStore.refreshtaskAggregateData: new aggregates', taskAggregates.value)
        return aggregateData
      })
      .catch((error) => {
        throw error
      })
  }

  return {
    addPlan,
    activePlansForDsids,
    behaviorLibrary,
    competencyFocusLibrary,
    convertDraftUUIDtoID,
    createNewDraft,
    currentDraftFor,
    currentPlanFor,
    lastThreeMonths,
    planTypeLength,
    drafts,
    findDraft,
    findPlan,
    focusMetricLibrary,
    isLoadingPlans,
    metrics,
    moveDraftToInProgress,
    plans,
    planAggregatesFor,
    plansForDsid,
    planTypeLibrary,
    refreshPlanAggregatesFor,
    setLibraryData,
    setPlansFromAPI,
    taskLibrary,
    updatePlan,
    updatePlanField,
    updatePlanData,
    refreshtaskAggregatesFor,
    planAggregates,
    taskAggregatesFor,
    taskAggregates
  }
})

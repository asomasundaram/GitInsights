import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { Employee } from '@/classes/Employee'
import type { DelegationHierarchy } from '@/types/InsightsTypes'

export const useEmployeeStore = defineStore('employeeStore', () => {
  const loggedInUser = ref('')
  const maskedUser = ref(null as string | null)
  const allEmployees = ref({} as { [key: number]: Employee })
  // Delegate hierarchy is stored as { managerDSID: [Employee DSIDs] }, and
  // employee data is stored in allEmployees to ensure we can use helper
  // functions such as `findEmployee` regardless of whether they are directs or
  // delegates. Ex:
  // {
  //   "1234567": ["90876", "765654"]
  // }
  const delegatedEmployees = ref({} as { [key: string]: string[] })

  const currentUser = computed(() => {
    const dsid = maskedUser.value ? maskedUser.value : loggedInUser.value
    let employeeInfo: Employee | undefined = allEmployees.value[dsid]
    return employeeInfo || unknownEmployee
  })

  // Caches employees so that we don't have to fetch them every time. We may
  // get rid of this in the future
  function cacheEmployees(employees: any[]) {
    for (let employee of employees) {
      employee instanceof Employee
        ? (allEmployees.value[employee.dsid] = employee)
        : (allEmployees.value[employee.dsid] = new Employee(employee))
    }
  }

  function setDirects(dsid: string, directReports: Employee[]) {
    const directDsids = directReports.map((direct: Employee) => direct.dsid)
    allEmployees.value[dsid].directs = directDsids
    cacheEmployees(directReports)
    console.log('Cached Employees', allEmployees.value)
  }

  function setEmployee(data: Employee) {
    allEmployees.value[data.dsid] = data
  }

  function setDelegation(delegationData: DelegationHierarchy) {
    if (!delegationData.managerData || delegationData.delegatesData.length < 1) return
    if (!allEmployees.value[delegationData.managerData.dsid])
      setEmployee(new Employee(delegationData.managerData))

    delegatedEmployees.value[delegationData.managerData.dsid] = []
    delegationData.delegatesData.forEach((delegate: Employee) => {
      if (!allEmployees.value[delegate.dsid]) setEmployee(new Employee(delegate))
      delegatedEmployees.value[delegationData.managerData.dsid].push(delegate.dsid)
    })
    console.log('EmployeeStore.setDelegation: New delegation data', delegatedEmployees.value)
  }
  function setLoggedInUser(dsid: string) {
    loggedInUser.value = dsid
  }

  function setMaskedUser(dsid: string) {
    maskedUser.value = dsid
  }

  function getDelegatedManagers() {
    const delegatedManagerDsids = Object.keys(delegatedEmployees.value)
    if (delegatedManagerDsids.length < 1) return []
    return delegatedManagerDsids
  }

  function getDelegatedEmployeesForManager(dsid: string) {
    if (!dsid || dsid == '') return []
    const delegatedEmployeeDsids = delegatedEmployees.value[dsid]
    return delegatedEmployeeDsids && delegatedEmployeeDsids.length ? delegatedEmployeeDsids : []
  }

  function clearMaskedUser() {
    maskedUser.value = null
  }

  function findEmployeeByDSID(dsid: string | undefined): Employee {
    if (!dsid) return unknownEmployee
    return (allEmployees.value[dsid] || unknownEmployee) as Employee
  }

  const unknownEmployee = new Employee({
    dsid: '',
    managerDsid: '',
    firstName: 'Unknown',
    lastName: 'Employee',
    emailAddress: 'na@apple.com',
    status: 'Active',
    roleId: '0',
    applicationRoleLevel: "level_0",
    roleName: 'Unknown',
    siteId: 'AUS',
    siteName: 'Austin',
    locale: 'Unknown',
    businessUnitId: 0
  })

  return {
    allEmployees,
    cacheEmployees,
    clearMaskedUser,
    currentUser,
    findEmployeeByDSID,
    getDelegatedManagers,
    getDelegatedEmployeesForManager,
    setDelegation,
    setEmployee,
    setLoggedInUser,
    setMaskedUser,
    setDirects,
    unknownEmployee
  }
})

# Insights
Insights web application for AIML
